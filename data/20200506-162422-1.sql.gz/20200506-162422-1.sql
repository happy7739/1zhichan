-- -----------------------------
-- MySQL Data Transfer
--
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : dolphin
--
-- Part : #1
-- Date : 2020-05-06 16:24:22
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `dp_admin_access`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_access`;
CREATE TABLE `dp_admin_access` (
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模型名称',
  `group` varchar(16) NOT NULL DEFAULT '' COMMENT '权限分组标识',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `nid` varchar(16) NOT NULL DEFAULT '' COMMENT '授权节点id',
  `tag` varchar(16) NOT NULL DEFAULT '' COMMENT '分组标签'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='统一授权表';


-- -----------------------------
-- Table structure for `dp_admin_action`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_action`;
CREATE TABLE `dp_admin_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '所属模块名',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '行为标题',
  `remark` varchar(128) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COMMENT='系统行为表';

-- -----------------------------
-- Records of `dp_admin_action`
-- -----------------------------
INSERT INTO `dp_admin_action` VALUES ('1', 'user', 'user_add', '添加用户', '添加用户', '', '[user|get_nickname] 添加了用户：[record|get_nickname]', '1', '1480156399', '1480163853');
INSERT INTO `dp_admin_action` VALUES ('2', 'user', 'user_edit', '编辑用户', '编辑用户', '', '[user|get_nickname] 编辑了用户：[details]', '1', '1480164578', '1480297748');
INSERT INTO `dp_admin_action` VALUES ('3', 'user', 'user_delete', '删除用户', '删除用户', '', '[user|get_nickname] 删除了用户：[details]', '1', '1480168582', '1480168616');
INSERT INTO `dp_admin_action` VALUES ('4', 'user', 'user_enable', '启用用户', '启用用户', '', '[user|get_nickname] 启用了用户：[details]', '1', '1480169185', '1480169185');
INSERT INTO `dp_admin_action` VALUES ('5', 'user', 'user_disable', '禁用用户', '禁用用户', '', '[user|get_nickname] 禁用了用户：[details]', '1', '1480169214', '1480170581');
INSERT INTO `dp_admin_action` VALUES ('6', 'user', 'user_access', '用户授权', '用户授权', '', '[user|get_nickname] 对用户：[record|get_nickname] 进行了授权操作。详情：[details]', '1', '1480221441', '1480221563');
INSERT INTO `dp_admin_action` VALUES ('7', 'user', 'role_add', '添加角色', '添加角色', '', '[user|get_nickname] 添加了角色：[details]', '1', '1480251473', '1480251473');
INSERT INTO `dp_admin_action` VALUES ('8', 'user', 'role_edit', '编辑角色', '编辑角色', '', '[user|get_nickname] 编辑了角色：[details]', '1', '1480252369', '1480252369');
INSERT INTO `dp_admin_action` VALUES ('9', 'user', 'role_delete', '删除角色', '删除角色', '', '[user|get_nickname] 删除了角色：[details]', '1', '1480252580', '1480252580');
INSERT INTO `dp_admin_action` VALUES ('10', 'user', 'role_enable', '启用角色', '启用角色', '', '[user|get_nickname] 启用了角色：[details]', '1', '1480252620', '1480252620');
INSERT INTO `dp_admin_action` VALUES ('11', 'user', 'role_disable', '禁用角色', '禁用角色', '', '[user|get_nickname] 禁用了角色：[details]', '1', '1480252651', '1480252651');
INSERT INTO `dp_admin_action` VALUES ('12', 'user', 'attachment_enable', '启用附件', '启用附件', '', '[user|get_nickname] 启用了附件：附件ID([details])', '1', '1480253226', '1480253332');
INSERT INTO `dp_admin_action` VALUES ('13', 'user', 'attachment_disable', '禁用附件', '禁用附件', '', '[user|get_nickname] 禁用了附件：附件ID([details])', '1', '1480253267', '1480253340');
INSERT INTO `dp_admin_action` VALUES ('14', 'user', 'attachment_delete', '删除附件', '删除附件', '', '[user|get_nickname] 删除了附件：附件ID([details])', '1', '1480253323', '1480253323');
INSERT INTO `dp_admin_action` VALUES ('15', 'admin', 'config_add', '添加配置', '添加配置', '', '[user|get_nickname] 添加了配置，[details]', '1', '1480296196', '1480296196');
INSERT INTO `dp_admin_action` VALUES ('16', 'admin', 'config_edit', '编辑配置', '编辑配置', '', '[user|get_nickname] 编辑了配置：[details]', '1', '1480296960', '1480296960');
INSERT INTO `dp_admin_action` VALUES ('17', 'admin', 'config_enable', '启用配置', '启用配置', '', '[user|get_nickname] 启用了配置：[details]', '1', '1480298479', '1480298479');
INSERT INTO `dp_admin_action` VALUES ('18', 'admin', 'config_disable', '禁用配置', '禁用配置', '', '[user|get_nickname] 禁用了配置：[details]', '1', '1480298506', '1480298506');
INSERT INTO `dp_admin_action` VALUES ('19', 'admin', 'config_delete', '删除配置', '删除配置', '', '[user|get_nickname] 删除了配置：[details]', '1', '1480298532', '1480298532');
INSERT INTO `dp_admin_action` VALUES ('20', 'admin', 'database_export', '备份数据库', '备份数据库', '', '[user|get_nickname] 备份了数据库：[details]', '1', '1480298946', '1480298946');
INSERT INTO `dp_admin_action` VALUES ('21', 'admin', 'database_import', '还原数据库', '还原数据库', '', '[user|get_nickname] 还原了数据库：[details]', '1', '1480301990', '1480302022');
INSERT INTO `dp_admin_action` VALUES ('22', 'admin', 'database_optimize', '优化数据表', '优化数据表', '', '[user|get_nickname] 优化了数据表：[details]', '1', '1480302616', '1480302616');
INSERT INTO `dp_admin_action` VALUES ('23', 'admin', 'database_repair', '修复数据表', '修复数据表', '', '[user|get_nickname] 修复了数据表：[details]', '1', '1480302798', '1480302798');
INSERT INTO `dp_admin_action` VALUES ('24', 'admin', 'database_backup_delete', '删除数据库备份', '删除数据库备份', '', '[user|get_nickname] 删除了数据库备份：[details]', '1', '1480302870', '1480302870');
INSERT INTO `dp_admin_action` VALUES ('25', 'admin', 'hook_add', '添加钩子', '添加钩子', '', '[user|get_nickname] 添加了钩子：[details]', '1', '1480303198', '1480303198');
INSERT INTO `dp_admin_action` VALUES ('26', 'admin', 'hook_edit', '编辑钩子', '编辑钩子', '', '[user|get_nickname] 编辑了钩子：[details]', '1', '1480303229', '1480303229');
INSERT INTO `dp_admin_action` VALUES ('27', 'admin', 'hook_delete', '删除钩子', '删除钩子', '', '[user|get_nickname] 删除了钩子：[details]', '1', '1480303264', '1480303264');
INSERT INTO `dp_admin_action` VALUES ('28', 'admin', 'hook_enable', '启用钩子', '启用钩子', '', '[user|get_nickname] 启用了钩子：[details]', '1', '1480303294', '1480303294');
INSERT INTO `dp_admin_action` VALUES ('29', 'admin', 'hook_disable', '禁用钩子', '禁用钩子', '', '[user|get_nickname] 禁用了钩子：[details]', '1', '1480303409', '1480303409');
INSERT INTO `dp_admin_action` VALUES ('30', 'admin', 'menu_add', '添加节点', '添加节点', '', '[user|get_nickname] 添加了节点：[details]', '1', '1480305468', '1480305468');
INSERT INTO `dp_admin_action` VALUES ('31', 'admin', 'menu_edit', '编辑节点', '编辑节点', '', '[user|get_nickname] 编辑了节点：[details]', '1', '1480305513', '1480305513');
INSERT INTO `dp_admin_action` VALUES ('32', 'admin', 'menu_delete', '删除节点', '删除节点', '', '[user|get_nickname] 删除了节点：[details]', '1', '1480305562', '1480305562');
INSERT INTO `dp_admin_action` VALUES ('33', 'admin', 'menu_enable', '启用节点', '启用节点', '', '[user|get_nickname] 启用了节点：[details]', '1', '1480305630', '1480305630');
INSERT INTO `dp_admin_action` VALUES ('34', 'admin', 'menu_disable', '禁用节点', '禁用节点', '', '[user|get_nickname] 禁用了节点：[details]', '1', '1480305659', '1480305659');
INSERT INTO `dp_admin_action` VALUES ('35', 'admin', 'module_install', '安装模块', '安装模块', '', '[user|get_nickname] 安装了模块：[details]', '1', '1480307558', '1480307558');
INSERT INTO `dp_admin_action` VALUES ('36', 'admin', 'module_uninstall', '卸载模块', '卸载模块', '', '[user|get_nickname] 卸载了模块：[details]', '1', '1480307588', '1480307588');
INSERT INTO `dp_admin_action` VALUES ('37', 'admin', 'module_enable', '启用模块', '启用模块', '', '[user|get_nickname] 启用了模块：[details]', '1', '1480307618', '1480307618');
INSERT INTO `dp_admin_action` VALUES ('38', 'admin', 'module_disable', '禁用模块', '禁用模块', '', '[user|get_nickname] 禁用了模块：[details]', '1', '1480307653', '1480307653');
INSERT INTO `dp_admin_action` VALUES ('39', 'admin', 'module_export', '导出模块', '导出模块', '', '[user|get_nickname] 导出了模块：[details]', '1', '1480307682', '1480307682');
INSERT INTO `dp_admin_action` VALUES ('40', 'admin', 'packet_install', '安装数据包', '安装数据包', '', '[user|get_nickname] 安装了数据包：[details]', '1', '1480308342', '1480308342');
INSERT INTO `dp_admin_action` VALUES ('41', 'admin', 'packet_uninstall', '卸载数据包', '卸载数据包', '', '[user|get_nickname] 卸载了数据包：[details]', '1', '1480308372', '1480308372');
INSERT INTO `dp_admin_action` VALUES ('42', 'admin', 'system_config_update', '更新系统设置', '更新系统设置', '', '[user|get_nickname] 更新了系统设置：[details]', '1', '1480309555', '1480309642');
INSERT INTO `dp_admin_action` VALUES ('43', 'cms', 'slider_delete', '删除滚动图片', '删除滚动图片', '', '[user|get_nickname] 删除了滚动图片：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('44', 'cms', 'slider_edit', '编辑滚动图片', '编辑滚动图片', '', '[user|get_nickname] 编辑了滚动图片：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('45', 'cms', 'slider_add', '添加滚动图片', '添加滚动图片', '', '[user|get_nickname] 添加了滚动图片：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('46', 'cms', 'document_delete', '删除文档', '删除文档', '', '[user|get_nickname] 删除了文档：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('47', 'cms', 'document_restore', '还原文档', '还原文档', '', '[user|get_nickname] 还原了文档：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('48', 'cms', 'nav_disable', '禁用导航', '禁用导航', '', '[user|get_nickname] 禁用了导航：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('49', 'cms', 'nav_enable', '启用导航', '启用导航', '', '[user|get_nickname] 启用了导航：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('50', 'cms', 'nav_delete', '删除导航', '删除导航', '', '[user|get_nickname] 删除了导航：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('51', 'cms', 'nav_edit', '编辑导航', '编辑导航', '', '[user|get_nickname] 编辑了导航：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('52', 'cms', 'nav_add', '添加导航', '添加导航', '', '[user|get_nickname] 添加了导航：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('53', 'cms', 'model_disable', '禁用内容模型', '禁用内容模型', '', '[user|get_nickname] 禁用了内容模型：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('54', 'cms', 'model_enable', '启用内容模型', '启用内容模型', '', '[user|get_nickname] 启用了内容模型：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('55', 'cms', 'model_delete', '删除内容模型', '删除内容模型', '', '[user|get_nickname] 删除了内容模型：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('56', 'cms', 'model_edit', '编辑内容模型', '编辑内容模型', '', '[user|get_nickname] 编辑了内容模型：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('57', 'cms', 'model_add', '添加内容模型', '添加内容模型', '', '[user|get_nickname] 添加了内容模型：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('58', 'cms', 'menu_disable', '禁用导航菜单', '禁用导航菜单', '', '[user|get_nickname] 禁用了导航菜单：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('59', 'cms', 'menu_enable', '启用导航菜单', '启用导航菜单', '', '[user|get_nickname] 启用了导航菜单：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('60', 'cms', 'menu_delete', '删除导航菜单', '删除导航菜单', '', '[user|get_nickname] 删除了导航菜单：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('61', 'cms', 'menu_edit', '编辑导航菜单', '编辑导航菜单', '', '[user|get_nickname] 编辑了导航菜单：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('62', 'cms', 'menu_add', '添加导航菜单', '添加导航菜单', '', '[user|get_nickname] 添加了导航菜单：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('63', 'cms', 'link_disable', '禁用友情链接', '禁用友情链接', '', '[user|get_nickname] 禁用了友情链接：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('64', 'cms', 'link_enable', '启用友情链接', '启用友情链接', '', '[user|get_nickname] 启用了友情链接：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('65', 'cms', 'link_delete', '删除友情链接', '删除友情链接', '', '[user|get_nickname] 删除了友情链接：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('66', 'cms', 'link_edit', '编辑友情链接', '编辑友情链接', '', '[user|get_nickname] 编辑了友情链接：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('67', 'cms', 'link_add', '添加友情链接', '添加友情链接', '', '[user|get_nickname] 添加了友情链接：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('68', 'cms', 'field_disable', '禁用模型字段', '禁用模型字段', '', '[user|get_nickname] 禁用了模型字段：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('69', 'cms', 'field_enable', '启用模型字段', '启用模型字段', '', '[user|get_nickname] 启用了模型字段：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('70', 'cms', 'field_delete', '删除模型字段', '删除模型字段', '', '[user|get_nickname] 删除了模型字段：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('71', 'cms', 'field_edit', '编辑模型字段', '编辑模型字段', '', '[user|get_nickname] 编辑了模型字段：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('72', 'cms', 'field_add', '添加模型字段', '添加模型字段', '', '[user|get_nickname] 添加了模型字段：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('73', 'cms', 'column_disable', '禁用栏目', '禁用栏目', '', '[user|get_nickname] 禁用了栏目：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('74', 'cms', 'column_enable', '启用栏目', '启用栏目', '', '[user|get_nickname] 启用了栏目：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('75', 'cms', 'column_delete', '删除栏目', '删除栏目', '', '[user|get_nickname] 删除了栏目：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('76', 'cms', 'column_edit', '编辑栏目', '编辑栏目', '', '[user|get_nickname] 编辑了栏目：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('77', 'cms', 'column_add', '添加栏目', '添加栏目', '', '[user|get_nickname] 添加了栏目：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('78', 'cms', 'advert_type_disable', '禁用广告分类', '禁用广告分类', '', '[user|get_nickname] 禁用了广告分类：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('79', 'cms', 'advert_type_enable', '启用广告分类', '启用广告分类', '', '[user|get_nickname] 启用了广告分类：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('80', 'cms', 'advert_type_delete', '删除广告分类', '删除广告分类', '', '[user|get_nickname] 删除了广告分类：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('81', 'cms', 'advert_type_edit', '编辑广告分类', '编辑广告分类', '', '[user|get_nickname] 编辑了广告分类：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('82', 'cms', 'advert_type_add', '添加广告分类', '添加广告分类', '', '[user|get_nickname] 添加了广告分类：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('83', 'cms', 'advert_disable', '禁用广告', '禁用广告', '', '[user|get_nickname] 禁用了广告：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('84', 'cms', 'advert_enable', '启用广告', '启用广告', '', '[user|get_nickname] 启用了广告：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('85', 'cms', 'advert_delete', '删除广告', '删除广告', '', '[user|get_nickname] 删除了广告：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('86', 'cms', 'advert_edit', '编辑广告', '编辑广告', '', '[user|get_nickname] 编辑了广告：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('87', 'cms', 'advert_add', '添加广告', '添加广告', '', '[user|get_nickname] 添加了广告：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('88', 'cms', 'document_disable', '禁用文档', '禁用文档', '', '[user|get_nickname] 禁用了文档：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('89', 'cms', 'document_enable', '启用文档', '启用文档', '', '[user|get_nickname] 启用了文档：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('90', 'cms', 'document_trash', '回收文档', '回收文档', '', '[user|get_nickname] 回收了文档：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('91', 'cms', 'document_edit', '编辑文档', '编辑文档', '', '[user|get_nickname] 编辑了文档：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('92', 'cms', 'document_add', '添加文档', '添加文档', '', '[user|get_nickname] 添加了文档：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('93', 'cms', 'slider_enable', '启用滚动图片', '启用滚动图片', '', '[user|get_nickname] 启用了滚动图片：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('94', 'cms', 'slider_disable', '禁用滚动图片', '禁用滚动图片', '', '[user|get_nickname] 禁用了滚动图片：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('95', 'cms', 'support_add', '添加客服', '添加客服', '', '[user|get_nickname] 添加了客服：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('96', 'cms', 'support_edit', '编辑客服', '编辑客服', '', '[user|get_nickname] 编辑了客服：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('97', 'cms', 'support_delete', '删除客服', '删除客服', '', '[user|get_nickname] 删除了客服：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('98', 'cms', 'support_enable', '启用客服', '启用客服', '', '[user|get_nickname] 启用了客服：[details]', '1', '1587373198', '1587373198');
INSERT INTO `dp_admin_action` VALUES ('99', 'cms', 'support_disable', '禁用客服', '禁用客服', '', '[user|get_nickname] 禁用了客服：[details]', '1', '1587373198', '1587373198');

-- -----------------------------
-- Table structure for `dp_admin_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_attachment`;
CREATE TABLE `dp_admin_attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '文件名',
  `module` varchar(32) NOT NULL DEFAULT '' COMMENT '模块名，由哪个模块上传的',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '文件路径',
  `thumb` varchar(255) NOT NULL DEFAULT '' COMMENT '缩略图路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件链接',
  `mime` varchar(128) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `ext` char(8) NOT NULL DEFAULT '' COMMENT '文件类型',
  `size` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT 'sha1 散列值',
  `driver` varchar(16) NOT NULL DEFAULT 'local' COMMENT '上传驱动',
  `download` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `width` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '图片宽度',
  `height` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '图片高度',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=364 DEFAULT CHARSET=utf8 COMMENT='附件表';

-- -----------------------------
-- Records of `dp_admin_attachment`
-- -----------------------------
INSERT INTO `dp_admin_attachment` VALUES ('1', '1', '7739.jpg', 'admin', 'uploads/images/20200421/9e0ed837c934fe9315f9f8b757a906b6.jpg', '', '', 'image/jpeg', 'jpg', '188395', '22aeec2886a769af32a21d3481a66b66', '0c9cd194a3d419d3ed9d7edf3d494b26d523b6b2', 'local', '0', '1587440650', '1587440650', '100', '1', '580', '800');
INSERT INTO `dp_admin_attachment` VALUES ('2', '1', '20150805172341_37185.jpg', 'admin', 'uploads/images/20200421/70dacf364fda6939ad3d9577090a7798.jpg', '', '', 'image/jpeg', 'jpg', '17716648', '05bdb32a87a359fdeb3b44ae2ed0edbd', 'b0774cf0f6194d1a09fd9978656f454f305f1611', 'local', '0', '1587448629', '1587448629', '100', '1', '135', '135');
INSERT INTO `dp_admin_attachment` VALUES ('3', '1', 'logo.jpg', 'admin', 'uploads/images/20200421/483c25437e24e30c252f18a156f14197.jpg', '', '', 'image/jpeg', 'jpg', '4603', '07bb87f7f4049cc97fbe76bfda232b24', '07ebb882aff49af4e40d2b401909df7ca2855526', 'local', '0', '1587448790', '1587448790', '100', '1', '164', '75');
INSERT INTO `dp_admin_attachment` VALUES ('4', '1', '20150805171237_20178.jpg', 'admin', 'uploads/images/20200421/4ba10f04cbd6135ce50038e97dc6d90f.jpg', '', '', 'image/jpeg', 'jpg', '79731', '8cbab216c91bae2e0d49244b2c06d1c9', 'f8d8d75a072c57700f83f1f617c29526757108e4', 'local', '0', '1587457522', '1587457522', '100', '1', '170', '215');
INSERT INTO `dp_admin_attachment` VALUES ('5', '1', '20150808234412_98692.jpg', 'admin', 'uploads/images/20200421/4d16c4988af7b47c49903707c958d381.jpg', '', '', 'image/jpeg', 'jpg', '281447', '045378259e4a37332c877f5db3733f23', '8e7a3ca07aa90fb482618d6930495c98a023671d', 'local', '0', '1587457766', '1587457766', '100', '1', '590', '418');
INSERT INTO `dp_admin_attachment` VALUES ('6', '1', '2.jpg', '', 'uploads/images/20200422/ac1f64d45a6ddbab1d26c96dd509a178.jpg', '', '', 'image/jpeg', 'jpg', '51789', 'f4e01be7eab675e38b395932189c8be0', '02876d7ccef7790e8374e4bd0c3e0465dd989370', 'local', '0', '1587531010', '1587531010', '100', '1', '910', '172');
INSERT INTO `dp_admin_attachment` VALUES ('7', '1', '1.jpg', '', 'uploads/images/20200422/5c518195870a051ed9ed4cc3305478ac.jpg', '', '', 'image/jpeg', 'jpg', '82507', 'dba562502b67f0995e5cc2d7f70c7d50', '0e148260592deb7a4f975a3672095ff321f884df', 'local', '0', '1587531011', '1587531011', '100', '1', '910', '171');
INSERT INTO `dp_admin_attachment` VALUES ('8', '1', '4.jpg', '', 'uploads/images/20200422/144847075dc1e2a3e38f109c194e4efc.jpg', '', '', 'image/jpeg', 'jpg', '73283', '932f63e4fd5da6e6a86d9b3d29c170f0', 'c95997fa0f9b0a20d9ed5e7d3e27307a281b4769', 'local', '0', '1587531011', '1587531011', '100', '1', '910', '171');
INSERT INTO `dp_admin_attachment` VALUES ('9', '1', '3.jpg', '', 'uploads/images/20200422/fac038fab92a3388c74762ff1ef54a72.jpg', '', '', 'image/jpeg', 'jpg', '67295', 'b2fd5154fedb30b8f19aeff7a68df724', '01c52f7dc6c85582bbb32c12cc0e76ff3586a2e9', 'local', '0', '1587531012', '1587531012', '100', '1', '910', '171');
INSERT INTO `dp_admin_attachment` VALUES ('10', '1', '5.jpg', '', 'uploads/images/20200422/9a10010b84d91cda7a2abae6889930da.jpg', '', '', 'image/jpeg', 'jpg', '88240', 'f4e3f341885c68e1cb1ab409d76c332d', 'b15507dc43565c9ef959c42dea7a140d91898350', 'local', '0', '1587531012', '1587531012', '100', '1', '910', '172');
INSERT INTO `dp_admin_attachment` VALUES ('11', '1', '6.jpg', '', 'uploads/images/20200422/5c5a3b20c587226f0a853fff885b0398.jpg', '', '', 'image/jpeg', 'jpg', '88129', 'e02a499901d392590c940f47724c0b70', 'd26693a77565571cbbf3455cdeed63467381eec3', 'local', '0', '1587531012', '1587531012', '100', '1', '910', '171');
INSERT INTO `dp_admin_attachment` VALUES ('12', '1', '7.jpg', '', 'uploads/images/20200422/3360a7936098ad747ab537b2fe816a1f.jpg', '', '', 'image/jpeg', 'jpg', '76837', '07fd16c5d8a5beeb3cc45c8242ce7b99', 'dda9930613795273473e2b5c090f1ceb43aa5b79', 'local', '0', '1587531013', '1587531013', '100', '1', '910', '171');
INSERT INTO `dp_admin_attachment` VALUES ('13', '1', '8.jpg', '', 'uploads/images/20200422/8093974d24262ded4eaecf8ea69b3325.jpg', '', '', 'image/jpeg', 'jpg', '95265', 'afb7899d73fc9fa65b96dc03b3fc575f', 'a364ce053c33c80d8cabbad07dff0164684380f7', 'local', '0', '1587531013', '1587531013', '100', '1', '910', '171');
INSERT INTO `dp_admin_attachment` VALUES ('14', '1', '9.jpg', '', 'uploads/images/20200422/3338ccc3a75b542202df37a49e5b3c89.jpg', '', '', 'image/jpeg', 'jpg', '73016', '529055dbc12ba3f3707fdbfd4a13a2d5', '0ceaca590da8424c6deb445250583f4ee07c4568', 'local', '0', '1587531014', '1587531014', '100', '1', '910', '172');
INSERT INTO `dp_admin_attachment` VALUES ('15', '1', '10.jpg', '', 'uploads/images/20200422/dd521072a700840687a1a841da5c61f2.jpg', '', '', 'image/jpeg', 'jpg', '68617', '1170110b21705750e21e2a0df3e93224', 'a771cad1200128c87e6757af98c7be8dac291b01', 'local', '0', '1587531014', '1587531014', '100', '1', '910', '171');
INSERT INTO `dp_admin_attachment` VALUES ('16', '1', '20150805183055_28163.jpg', 'admin', 'uploads/images/20200423/d22e11a2501127952d14c700bb7ac257.jpg', '', '', 'image/jpeg', 'jpg', '447146', '75ea88e082428f12bd4bfabb221b0f80', 'e3605929d3b43a0bda3d1f0dea2880d841ccbc4d', 'local', '0', '1587614791', '1587614791', '100', '1', '1677', '618');
INSERT INTO `dp_admin_attachment` VALUES ('17', '1', '20150805183536_84635.jpg', 'admin', 'uploads/images/20200423/229153c1e986a36085949a9fa0b756f4.jpg', '', '', 'image/jpeg', 'jpg', '957561', 'a8f9a43886b9b66ac392c584696fb9af', '5f83c3745572e82b83a3f19cbdc6760aef0d69e5', 'local', '0', '1587614871', '1587614871', '100', '1', '1920', '618');
INSERT INTO `dp_admin_attachment` VALUES ('18', '1', '20150805175939_92348.jpg', 'admin', 'uploads/images/20200423/d260330a8c42719106c580f07af89bbd.jpg', '', '', 'image/jpeg', 'jpg', '500904', '58bd768fadccd4da8c3c5e0b74c29924', '87446256301d233326d91d56da6366db6b7fd4d1', 'local', '0', '1587614938', '1587614938', '100', '1', '1920', '618');
INSERT INTO `dp_admin_attachment` VALUES ('19', '1', '20150805182014_90167.jpg', 'admin', 'uploads/images/20200423/9742f53dc58a65196f9ff2e3b1a7a8b5.jpg', '', '', 'image/jpeg', 'jpg', '354234', 'f49a53fd0563dc3b43819f78e1a30d4a', 'f4a1601a25a75a9dc8211ad7d82e8ad118c8f2f7', 'local', '0', '1587614977', '1587614977', '100', '1', '1920', '618');
INSERT INTO `dp_admin_attachment` VALUES ('20', '1', '14387706682.jpg', 'admin', 'uploads/images/20200423/ff6f8191eaeb3ec3ad740bbedee91858.jpg', '', '', 'image/jpeg', 'jpg', '467160', '649360bc6ab90a6e4ab70e664f5570c2', '4a921ddf44ae55c57ac23afd2e9be88105b00bde', 'local', '0', '1587624499', '1587624499', '100', '1', '659', '618');
INSERT INTO `dp_admin_attachment` VALUES ('21', '1', '14387706683.jpg', 'admin', 'uploads/images/20200423/5c555c42268b3b37ba11ca3fb7fef35d.jpg', '', '', 'image/jpeg', 'jpg', '103307', '97f8eabbe1f9c766749c26d02c14c9a8', '96429201b9eb7b350ed6bbde63f71c497693524c', 'local', '0', '1587624505', '1587624505', '100', '1', '800', '800');
INSERT INTO `dp_admin_attachment` VALUES ('22', '1', '14387709512.jpg', 'admin', 'uploads/images/20200423/67cff21277ae1fd92f95d01a762a37c3.jpg', '', '', 'image/jpeg', 'jpg', '642229', 'a302d84e6aa9c1114ef09ee95cb387fe', '88d5a97dd4ed2ffb669a8e04053e173d4a2cd07c', 'local', '0', '1587624743', '1587624743', '100', '1', '741', '618');
INSERT INTO `dp_admin_attachment` VALUES ('23', '1', '14387709512s.png', 'admin', 'uploads/images/20200423/4885accac322ecfde18e2d6902648c1d.png', '', '', 'image/png', 'png', '101842', '65fc753db8d2e83677c3937b03990241', '061eb09e547dcb5ec98783bdda4a9d9b07ec4c29', 'local', '0', '1587624792', '1587624792', '100', '1', '450', '618');
INSERT INTO `dp_admin_attachment` VALUES ('24', '1', '14387687911s.jpg', 'admin', 'uploads/images/20200423/c3c39aaffd4c9631ceb07a0d93ed4e87.jpg', '', '', 'image/jpeg', 'jpg', '511089', '4f8979c6a940c830080645ae249160b4', '3bee788fa94fe6288ee21f2cc37a6389cc9b73c4', 'local', '0', '1587624836', '1587624836', '100', '1', '677', '618');
INSERT INTO `dp_admin_attachment` VALUES ('25', '1', '14387687912s.jpg', 'admin', 'uploads/images/20200423/7dee6a72cbb5b45c65e1953e31b30f0b.jpg', '', '', 'image/jpeg', 'jpg', '338712', 'c56a0742d0f646e27fcc4df7501d7cfb', 'af3a974bbdf8e260d8dff96f14b9ae978f1c2ee9', 'local', '0', '1587624863', '1587624863', '100', '1', '681', '618');
INSERT INTO `dp_admin_attachment` VALUES ('26', '1', '14387700272.jpg', 'admin', 'uploads/images/20200423/9925857980179ab12bff3084416e4e86.jpg', '', '', 'image/jpeg', 'jpg', '714897', '4a0cab23b5592e1550ba6e20dcc3abe4', 'acb2fe22bf8fba42b872f04ccf234258ac4bec60', 'local', '0', '1587624911', '1587624911', '100', '1', '990', '618');
INSERT INTO `dp_admin_attachment` VALUES ('27', '1', '20161018141311_27658.png', 'admin', 'uploads/images/20200423/d10695374085b6525847ad1d7c807e9f.png', '', '', 'image/png', 'png', '162986', 'e77ff439897e9c60b108552ab4f032bf', '234dba5c69d79c721c4bd0fdacbf3823b0f4c218', 'local', '0', '1587631774', '1587631774', '100', '1', '290', '280');
INSERT INTO `dp_admin_attachment` VALUES ('28', '1', '20161018140954_49202.png', 'admin', 'uploads/images/20200423/3c463796e9cce9625d5e1885fd5994e2.png', '', '', 'image/png', 'png', '138855', 'f691c3b27f9e45b67b691be1f21d2d1b', '3a11ae881c815375ad28e24c8a307547ef84ae1d', 'local', '0', '1587631799', '1587631799', '100', '1', '290', '280');
INSERT INTO `dp_admin_attachment` VALUES ('29', '1', '20161018141128_66407.png', 'admin', 'uploads/images/20200423/8dacb10d2c72699ec7c8c273c1a1ad44.png', '', '', 'image/png', 'png', '131966', '8f747b18d355be7e976de8096470d97c', 'e3454ee6ea20637c20692d9a68f1a8b7960f12fa', 'local', '0', '1587631845', '1587631845', '100', '1', '290', '280');
INSERT INTO `dp_admin_attachment` VALUES ('30', '1', '20161018141235_94541.png', 'admin', 'uploads/images/20200423/766853af045a8629a704aa52bfaab59f.png', '', '', 'image/png', 'png', '157864', 'bb25edaa7bd48804d88f4ea917e8e645', '1952dba28af544242cb6615234bf4489726aa6d5', 'local', '0', '1587631886', '1587631886', '100', '1', '290', '280');
INSERT INTO `dp_admin_attachment` VALUES ('31', '1', '20150805165126_41429.png', 'admin', 'uploads/images/20200423/66d44622e65d0a8c8da7caeb6784642b.png', '', '', 'image/png', 'png', '105271', 'c3fe9b1b9b821f7d89e7552ac65de5a5', 'a7a626e10ada9e65f999e5cee5d506c5aa28dbb1', 'local', '0', '1587631917', '1587631917', '100', '1', '290', '264');
INSERT INTO `dp_admin_attachment` VALUES ('32', '1', '20161028144934_55537.jpg', 'admin', 'uploads/images/20200424/2a3ac4ef77cb25c1c2760f6096a0e646.jpg', '', '', 'image/jpeg', 'jpg', '468195', '6cf2de8683eccd2beca2a858111cae0f', 'b13a9ad232dfa4f3379ba8c30d7abf640c9b07b3', 'local', '0', '1587695718', '1587695718', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('33', '1', '20161028145000_64993.jpg', 'admin', 'uploads/images/20200424/2da4ba18298032c367597009402af577.jpg', '', '', 'image/jpeg', 'jpg', '605151', '6ab9e7440f564837388411183b4e0d69', 'c165c48cd4f2c4c8ed4ae408c23e3b2df1f92e7a', 'local', '0', '1587695760', '1587695760', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('34', '1', '20161028145030_47283.jpg', 'admin', 'uploads/images/20200424/2cb0145e5cbf7788ae627b72e56575e3.jpg', '', '', 'image/jpeg', 'jpg', '379277', '696f758955ffd6c0a9ca11d817abf05d', '148e0e172353c0237f335ed037ed195d242ea2d6', 'local', '0', '1587695794', '1587695794', '100', '1', '904', '599');
INSERT INTO `dp_admin_attachment` VALUES ('35', '1', '20161028145050_87530.jpg', 'admin', 'uploads/images/20200424/8875d3b304e41a9f590dc91dfd613f8d.jpg', '', '', 'image/jpeg', 'jpg', '315455', 'a36899f119e6b1b698cd639153645b42', '49417a4f821a6d8e427d83dc649342bdfe12b766', 'local', '0', '1587695820', '1587695820', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('36', '1', '20161028145114_15927.jpg', 'admin', 'uploads/images/20200424/983203032c45c0603499731b275c1858.jpg', '', '', 'image/jpeg', 'jpg', '297002', '9619ebff2a526ec2571932d23682c2a6', '151919ed1c794fb18db7c38d97708bc8c2982822', 'local', '0', '1587695852', '1587695852', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('37', '1', '20161028145133_64312.jpg', 'admin', 'uploads/images/20200424/55a8a2363e6faa951d54280079e6d0e2.jpg', '', '', 'image/jpeg', 'jpg', '379827', 'aca5ba8820358795ef085d57a415a89c', '70d80ade72ac88af578dcef2441c3db011394c30', 'local', '0', '1587695883', '1587695883', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('38', '1', '20161028145154_49337.jpg', 'admin', 'uploads/images/20200424/986b7889c30a0b8287735d3829afdb47.jpg', '', '', 'image/jpeg', 'jpg', '482044', '1cf09b74d3f375c3029199766d27d702', '35eef405904f6c064a52aef05571d8237c3130f9', 'local', '0', '1587695911', '1587695911', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('39', '1', '20161028145210_64672.jpg', 'admin', 'uploads/images/20200424/eb9457477fee791141ac218f26a54d6c.jpg', '', '', 'image/jpeg', 'jpg', '402768', '3707b3cfac92741be91245475ecf5f92', 'f6d0053a01e2669f4f7f0197fc44e63ae8bae847', 'local', '0', '1587695942', '1587695942', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('40', '1', '20161028145234_88552.jpg', 'admin', 'uploads/images/20200424/a1ed8edd66a3ac023f72ea9749ae9384.jpg', '', '', 'image/jpeg', 'jpg', '483837', 'ad534d99368ff6f04e2c33412684513a', '0bea33c53a1313e71ac97f555e6df8f1782502bb', 'local', '0', '1587695967', '1587695967', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('41', '1', '20161028145251_15597.jpg', 'admin', 'uploads/images/20200424/63b510e32324a872eef9cfa4e6d01f7c.jpg', '', '', 'image/jpeg', 'jpg', '253086', '6b9d6238981c4fa2e43863669eea7b44', '3a06496532e33494a22bb4dd41962197072fb190', 'local', '0', '1587695995', '1587695995', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('42', '1', '20191122164105_7031.jpg', 'admin', 'uploads/images/20200424/bf1d8f6386620924671e2445a30a7967.jpg', '', '', 'image/jpeg', 'jpg', '105043', '8fb72bf17acaba4bb69643e249d3496f', '419ed24c480d000d95431a81cb567a7e39daf35d', 'local', '0', '1587707887', '1587707887', '100', '1', '300', '230');
INSERT INTO `dp_admin_attachment` VALUES ('43', '1', '20191122163530_6562.jpg', 'admin', 'uploads/images/20200424/795860a2e568e39c49d6f456de0f0f24.jpg', '', '', 'image/jpeg', 'jpg', '196590', 'd575eb50083f554644116e2017515007', 'd787741a5af8fe73ac4e6fa06f160ccf1a12ed02', 'local', '0', '1587708837', '1587708837', '100', '1', '500', '300');
INSERT INTO `dp_admin_attachment` VALUES ('44', '1', '20191120155012_7656.jpg', 'admin', 'uploads/images/20200424/0a50d9220c8ebc87d92d68627cd9d846.jpg', '', '', 'image/jpeg', 'jpg', '32995', '5a0b883501849175d5e163ec83f2565d', 'bec61c9d0dab1486b96967b5843eb6d7de75ccfa', 'local', '0', '1587709158', '1587709158', '100', '1', '400', '300');
INSERT INTO `dp_admin_attachment` VALUES ('45', '1', '20191120154717_3125.jpg', 'admin', 'uploads/images/20200424/0748f0b4c80f65a51df5421216f09f5a.jpg', '', '', 'image/jpeg', 'jpg', '50320', 'd571351dfa2173db322cd92536d56ec2', '8963469b565baca1d2c1fe89220b186d5d017a5c', 'local', '0', '1587711996', '1587711996', '100', '1', '760', '374');
INSERT INTO `dp_admin_attachment` VALUES ('46', '1', '20191119154557_6093.jpg', 'admin', 'uploads/images/20200424/cfa86c298a57f691758761bfc9fd56b6.jpg', '', '', 'image/jpeg', 'jpg', '60174', 'd4b1dab02500386d419192bc20006bfa', 'a7023ad727f9950e6401790a80e7a7bff58586f6', 'local', '0', '1587712105', '1587712105', '100', '1', '400', '297');
INSERT INTO `dp_admin_attachment` VALUES ('47', '1', '20150805171221_42566.jpg', 'admin', 'uploads/images/20200424/6e83f1bfa680cc1d5984b4153684989e.jpg', '', '', 'image/jpeg', 'jpg', '62273', 'd36accbb1d031d7d754eb00278858eed', 'bbedd8922915fa9525f9e64f11c595e3764ae90f', 'local', '0', '1587714187', '1587714187', '100', '1', '170', '215');
INSERT INTO `dp_admin_attachment` VALUES ('48', '1', '20150805171310_93279.jpg', 'admin', 'uploads/images/20200424/37c89ca7a815dd694056952f37d031fd.jpg', '', '', 'image/jpeg', 'jpg', '67499', '71a98e314e8112bc4fc111dbd8e0b7a4', 'c7622eec4d94b0a77d3524b162031f77c9680d44', 'local', '0', '1587714315', '1587714315', '100', '1', '170', '215');
INSERT INTO `dp_admin_attachment` VALUES ('49', '1', '20150805171320_68304.jpg', 'admin', 'uploads/images/20200424/2950b56913198693aa35f7218cc3f652.jpg', '', '', 'image/jpeg', 'jpg', '57240', '04ac22f7f931fcfa8d68aa627701c361', 'e097a4d570d216e68e28bf20921d963556d5732e', 'local', '0', '1587714355', '1587714355', '100', '1', '170', '215');
INSERT INTO `dp_admin_attachment` VALUES ('50', '1', '20150808234425_75777.jpg', 'admin', 'uploads/images/20200424/9c483df3cc51ecdbe5455d81d17acf6d.jpg', '', '', 'image/jpeg', 'jpg', '425189', '2ad8e89e0d8043958231e1eda358dd8b', '30d6a1da6755191c9274751bd0068dcc1b9bbe47', 'local', '0', '1587718734', '1587718734', '100', '1', '590', '418');
INSERT INTO `dp_admin_attachment` VALUES ('51', '1', '20150808234103_52640.jpg', 'admin', 'uploads/images/20200424/479b34ebe480b802ca7e932468d9dcf2.jpg', '', '', 'image/jpeg', 'jpg', '462160', '3dfd60f86ac605b4afb2e7ccf0dac8f0', '30a8d010293950e2d269cd8160a25cdbb20aa21c', 'local', '0', '1587718862', '1587718862', '100', '1', '590', '418');
INSERT INTO `dp_admin_attachment` VALUES ('52', '1', '1.jpg', 'admin', 'uploads/images/20200425/fe4bb07bc248723da8198fbf9c74869c.jpg', '', '', 'image/jpeg', 'jpg', '98110', '80845322c9235e87001c45f5087904a8', '617f4229f8a1673c9ac9fad0faf1416480528dc3', 'local', '0', '1587785429', '1587785429', '100', '1', '910', '288');
INSERT INTO `dp_admin_attachment` VALUES ('53', '1', '2.jpg', 'admin', 'uploads/images/20200425/2d8241af6e5ebfed8440d3f4f933a383.jpg', '', '', 'image/jpeg', 'jpg', '92072', 'fe4e7bd83bc87ac597716990f165ecbb', '32ba11b93a5993beaf841b8ef6eaed329db9cb05', 'local', '0', '1587785450', '1587785450', '100', '1', '910', '287');
INSERT INTO `dp_admin_attachment` VALUES ('54', '1', '3.jpg', 'admin', 'uploads/images/20200425/37912e6538a58fd9b50c0d0a0b4b844f.jpg', '', '', 'image/jpeg', 'jpg', '129033', '08bfdc09135f67a4d53a46feff0e57bc', '7c109f69196692fa95a69820116a33b3922802a2', 'local', '0', '1587785465', '1587785465', '100', '1', '910', '288');
INSERT INTO `dp_admin_attachment` VALUES ('55', '1', '4.jpg', 'admin', 'uploads/images/20200425/04401668e50760dee90c36be0e0734d2.jpg', '', '', 'image/jpeg', 'jpg', '76149', '763ca4e3a3368f298de155aeea13875b', 'c7ceb691f98e64e7b6c611b9aec52f530433e4ba', 'local', '0', '1587785486', '1587785486', '100', '1', '910', '288');
INSERT INTO `dp_admin_attachment` VALUES ('56', '1', '5.jpg', 'admin', 'uploads/images/20200425/d40b49f67d733659bd0cac23cfef8652.jpg', '', '', 'image/jpeg', 'jpg', '141366', '11e95e6ff90e454b3a41376f576f97f0', '44dc3431544cc507a4f412a55e5898dd7afcdbdc', 'local', '0', '1587785501', '1587785501', '100', '1', '910', '288');
INSERT INTO `dp_admin_attachment` VALUES ('57', '1', '6.jpg', 'admin', 'uploads/images/20200425/b1439a4557bba39df50233c75eb39719.jpg', '', '', 'image/jpeg', 'jpg', '89709', 'e92c9fbb1feafb8030a22f7aa36a4045', 'ed1f0b1c89d877e25b3f00249ad6404c0779854c', 'local', '0', '1587785519', '1587785519', '100', '1', '910', '287');
INSERT INTO `dp_admin_attachment` VALUES ('58', '1', '7.jpg', 'admin', 'uploads/images/20200425/58f7d11d4bfb87700be34ab5da251a0a.jpg', '', '', 'image/jpeg', 'jpg', '150956', '12fcf917d1e4e3d05957ceca22d4b8b0', '1ac3718dc30251d41004d753472d347188b11464', 'local', '0', '1587785548', '1587785548', '100', '1', '910', '288');
INSERT INTO `dp_admin_attachment` VALUES ('59', '1', '8.jpg', 'admin', 'uploads/images/20200425/a0fb7934210aee9ad4795ebc770b5f0e.jpg', '', '', 'image/jpeg', 'jpg', '93045', 'fdabedb1ee1831aebf91e89542294693', '1f0f468b8f9a5ee6fe4d3b589527443a141ba733', 'local', '0', '1587785563', '1587785563', '100', '1', '910', '288');
INSERT INTO `dp_admin_attachment` VALUES ('60', '1', '9.jpg', 'admin', 'uploads/images/20200425/637051cfcc20f35f2f121655088ec627.jpg', '', '', 'image/jpeg', 'jpg', '143290', '4d31e1ad646a11a4a8fb0cb245e4cd2f', '77e29bbd169c1477d5000356e5d32326380284bd', 'local', '0', '1587785581', '1587785581', '100', '1', '910', '287');
INSERT INTO `dp_admin_attachment` VALUES ('61', '1', '10.jpg', 'admin', 'uploads/images/20200425/851ed01cd1891caa27e949c990d5ee68.jpg', '', '', 'image/jpeg', 'jpg', '73953', '2606d2abf5d6f663842e269b9d7f45cc', 'a4a3ffb68a5553bd6aca3f2a51d420150e00e2e3', 'local', '0', '1587785596', '1587785596', '100', '1', '910', '288');
INSERT INTO `dp_admin_attachment` VALUES ('62', '1', '1.jpg', 'admin', 'uploads/images/20200425/0a5b0191e94fecc4a9bd04264c6cffea.jpg', '', '', 'image/jpeg', 'jpg', '58238', '36bf826ba86034ba89d4a740f828876d', 'b29c5377ca365998d133cd1da2c2232222cf0f7a', 'local', '0', '1587786330', '1587786330', '100', '1', '910', '211');
INSERT INTO `dp_admin_attachment` VALUES ('63', '1', '2.jpg', 'admin', 'uploads/images/20200425/efd8c685f05ebb8fd43757e982713e5a.jpg', '', '', 'image/jpeg', 'jpg', '130978', '9603118d1042fefba8879364c668853d', 'a38af6f2682ec730c6cfc86b8e327e9c72c0c906', 'local', '0', '1587786351', '1587786351', '100', '1', '910', '211');
INSERT INTO `dp_admin_attachment` VALUES ('64', '1', '3.jpg', 'admin', 'uploads/images/20200425/a32f931f31e4c4d691d694a21c062efc.jpg', '', '', 'image/jpeg', 'jpg', '51585', 'b63f9c0e09946699ec1e1f17b98e63cf', 'ab7e12da9338390265432fcdffba6e5f0a1b0aa1', 'local', '0', '1587786374', '1587786374', '100', '1', '910', '211');
INSERT INTO `dp_admin_attachment` VALUES ('65', '1', '4.jpg', 'admin', 'uploads/images/20200425/61d0f28b5835ec325cf9bf9e37673f21.jpg', '', '', 'image/jpeg', 'jpg', '49072', '530ae01e0fbe4e1f4b82bd0c127db4d0', '248f5286b7e31f9b49d0179f372eb72c59198507', 'local', '0', '1587786392', '1587786392', '100', '1', '910', '211');
INSERT INTO `dp_admin_attachment` VALUES ('66', '1', '5.jpg', 'admin', 'uploads/images/20200425/279f0d4ac333042cee2ed05273fca063.jpg', '', '', 'image/jpeg', 'jpg', '184144', 'b50ea56b06b9da1ae7753bded632e013', 'c533aa9672a7c7f7733e69722b2d2e0a4d1237b7', 'local', '0', '1587786408', '1587786408', '100', '1', '910', '212');
INSERT INTO `dp_admin_attachment` VALUES ('67', '1', '6.jpg', 'admin', 'uploads/images/20200425/fff46b408e1e675ed9de4e4e506250a3.jpg', '', '', 'image/jpeg', 'jpg', '155726', 'afd25abf8c485c5b6bd6a861ecfa044b', '4816e38404b9e51739b642d2dc05e48bf13b792c', 'local', '0', '1587786423', '1587786423', '100', '1', '910', '211');
INSERT INTO `dp_admin_attachment` VALUES ('68', '1', '7.jpg', 'admin', 'uploads/images/20200425/64dff0473de4046f1779af57e6d5fcf3.jpg', '', '', 'image/jpeg', 'jpg', '139620', 'ea1fe4cb0bac952aeff14f308b7f145e', '59778a2d04f38c92f130bbc1673a34eaecf2ad25', 'local', '0', '1587786438', '1587786438', '100', '1', '910', '211');
INSERT INTO `dp_admin_attachment` VALUES ('69', '1', '8.jpg', 'admin', 'uploads/images/20200425/19dc6be85a3896f1d66eeb8bc99cbc15.jpg', '', '', 'image/jpeg', 'jpg', '86907', '73d8de4b1da73f48b4c1d96bad1c043f', 'e10eedfe997ae8423b6998cae35d6db9224f2544', 'local', '0', '1587786465', '1587786465', '100', '1', '910', '211');
INSERT INTO `dp_admin_attachment` VALUES ('70', '1', '9.jpg', 'admin', 'uploads/images/20200425/49113d45c232a8ee9acc62efa22413f3.jpg', '', '', 'image/jpeg', 'jpg', '83174', '57b9b827eb5cfa1c7457b9e3a42f18a2', 'e05eded3855cdfaa991fd55fb2ec3f620e24d357', 'local', '0', '1587786480', '1587786480', '100', '1', '910', '211');
INSERT INTO `dp_admin_attachment` VALUES ('71', '1', '10.jpg', 'admin', 'uploads/images/20200425/c01b09c2bf12b1feb402e6c31983b921.jpg', '', '', 'image/jpeg', 'jpg', '51894', '4e6aa16371a1e1ea41b769078b995e44', 'fa6ea652ba1fa69fb6348508825e828c6d5d914c', 'local', '0', '1587786494', '1587786494', '100', '1', '910', '211');
INSERT INTO `dp_admin_attachment` VALUES ('72', '1', '1.jpg', 'admin', 'uploads/images/20200427/abd0e00c7a47fc4a7dd34878e8f1f7bf.jpg', '', '', 'image/jpeg', 'jpg', '29179', '91ff3d4d7c370043bdead953713de758', 'e03e01124840143c700f2c87f2d2dfff65cd4c8f', 'local', '0', '1587952796', '1587952796', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('73', '1', '2.jpg', 'admin', 'uploads/images/20200427/4869dfe79b53579448e1022d897ceae8.jpg', '', '', 'image/jpeg', 'jpg', '65777', 'cdfecfd400fc7636b6517d7e11a30e2e', '720420bbd833c3fec04136c9eb863410b5c28d3f', 'local', '0', '1587952826', '1587952826', '100', '1', '910', '242');
INSERT INTO `dp_admin_attachment` VALUES ('74', '1', '3.jpg', 'admin', 'uploads/images/20200427/c6b63cfd4efe3106698172fca2e098d7.jpg', '', '', 'image/jpeg', 'jpg', '69516', 'fab99cdb1f3e96f6b6ea50b3f17f56a7', '2e1475227a5bbbe199d2860b9d925145e604a3b9', 'local', '0', '1587952842', '1587952842', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('75', '1', '4.jpg', 'admin', 'uploads/images/20200427/8850d1ea67e6aa1eec6956e65a4d5472.jpg', '', '', 'image/jpeg', 'jpg', '142069', '9bb3c46f95d143686ad2ed42d8a21f88', 'd7f02e70e730c707750fae3551494ea4d789896d', 'local', '0', '1587952964', '1587952964', '100', '1', '910', '242');
INSERT INTO `dp_admin_attachment` VALUES ('76', '1', '5.jpg', 'admin', 'uploads/images/20200427/9ee4d5c1fe4812ad057ea4304b9af434.jpg', '', '', 'image/jpeg', 'jpg', '45451', '295d8c58bfc99b65abc9e637c1d32bc6', 'c62683cbaf558ea13cc60464faa001e586f895c2', 'local', '0', '1587952993', '1587952993', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('77', '1', '6.jpg', 'admin', 'uploads/images/20200427/d4038c41505f133ecc7ed516ecef360c.jpg', '', '', 'image/jpeg', 'jpg', '46416', 'b62b896c0fd299deb5d8ff08885ab503', '7b636cfbf70e690a6f4d9585777551bf6df4cd3c', 'local', '0', '1587953072', '1587953072', '100', '1', '910', '177');
INSERT INTO `dp_admin_attachment` VALUES ('78', '1', '11.png', 'admin', 'uploads/images/20200427/a256a239a1150ff8ece0b8e4e773609d.png', '', '', 'image/png', 'png', '30943', '38c4f9deca82c99eff83ec1163b8c2aa', 'f4d4b888df345b75aa999e4c5a238907f7af4b49', 'local', '0', '1587953513', '1587953513', '100', '1', '349', '450');
INSERT INTO `dp_admin_attachment` VALUES ('79', '1', 'c1.png', 'admin', 'uploads/images/20200427/bd3a88cde665868881fd7373b4278553.png', '', '', 'image/png', 'png', '41500', 'be4c64aed8aad89aa597fbdd1f240bbb', '2c36861b300980a01f885f81f5065b7353443566', 'local', '0', '1587953759', '1587953759', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('80', '1', 'c2.png', 'admin', 'uploads/images/20200427/1995a8b419a402b84f725ab5e8d35763.png', '', '', 'image/png', 'png', '58829', '8fcbf7162f87ddaa02e07034fd1f4853', '8721225c2ef23bb21d1331578a479943785c09fc', 'local', '0', '1587953909', '1587953909', '100', '1', '349', '450');
INSERT INTO `dp_admin_attachment` VALUES ('81', '1', 'c3.png', 'admin', 'uploads/images/20200427/300ebb5d4f9ce3ed379b8d3a5721994b.png', '', '', 'image/png', 'png', '34211', '3e719ecd66f2ff6b3e7179ddb35ef142', 'b4f7c21239fc4e8c6596394a2ca9d8f0460b1c8e', 'local', '0', '1587953954', '1587953954', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('82', '1', 'c4.png', 'admin', 'uploads/images/20200427/a7442eb2942a927f5467a988426778e0.png', '', '', 'image/png', 'png', '219762', 'db7dfa6de98f82763f3dc4e533741dff', '327670371a124c5434309245fa16c1bac4b88f76', 'local', '0', '1587954079', '1587954079', '100', '1', '349', '450');
INSERT INTO `dp_admin_attachment` VALUES ('83', '1', 'c5.png', 'admin', 'uploads/images/20200427/bae4edbf8fe3b1f8be13cf1f3269ec7a.png', '', '', 'image/png', 'png', '39562', 'b96ae48f46f58312ad966e01169e0cc9', '1c275b60c374a8f120bb673ad5054d587017751c', 'local', '0', '1587954120', '1587954120', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('84', '1', 'c6.png', 'admin', 'uploads/images/20200427/4b3cb0d2ea485c926a35bf7616eda8e4.png', '', '', 'image/png', 'png', '210880', '6144c09c67f3f4e3fe443dc343105867', '5b338ac58023ab8124aef59fee2f42d25a4822c1', 'local', '0', '1587954138', '1587954138', '100', '1', '349', '450');
INSERT INTO `dp_admin_attachment` VALUES ('85', '1', 'c7.png', 'admin', 'uploads/images/20200427/56eec8cabd98cf149961691eaf5a8f46.png', '', '', 'image/png', 'png', '40195', '01b622f7e0ef6f49ec59c220bc172ccc', 'e5cb67fe218dca514c351991e05d7d93c283512c', 'local', '0', '1587954154', '1587954154', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('86', '1', 'c8.png', 'admin', 'uploads/images/20200427/2a46fbe7fe7f77e9f477ff9b4cec2c82.png', '', '', 'image/png', 'png', '354859', '86417545da871020a3f60fd75e7c3736', 'b93d89e6d9d79da1e07412016903521a89de06c6', 'local', '0', '1587954171', '1587954171', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('87', '1', 'g1.jpg', 'admin', 'uploads/images/20200427/23233b1d0210349f7d8a8272aaabd829.jpg', '', '', 'image/jpeg', 'jpg', '40595', '7cfc2332ddd716694e88670965f1d930', '595d225be15fbc4f5c4b3d38f39a28e0118d0c31', 'local', '0', '1587954291', '1587954291', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('88', '1', 'g2.jpg', 'admin', 'uploads/images/20200427/df2ad03400de9192e7ac8fbf1f451b0d.jpg', '', '', 'image/jpeg', 'jpg', '47624', 'cbbc17a2fee92c8e7458736189afc2c1', '38d0a21e69484a308628e9cf89a19fc7161066ac', 'local', '0', '1587954307', '1587954307', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('89', '1', 'g3.jpg', 'admin', 'uploads/images/20200427/34f94c56b96afe0cf6fab6acf251dd17.jpg', '', '', 'image/jpeg', 'jpg', '45411', '932658bb4dede4edb22d6171a575b074', '1c006c791835e448f1d59393eaa3a0f3d7affc17', 'local', '0', '1587954322', '1587954322', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('90', '1', 'g4.jpg', 'admin', 'uploads/images/20200427/8a6ff29c6679989cec9653e03e006497.jpg', '', '', 'image/jpeg', 'jpg', '40205', 'efcc56ddc8f851cc0fcc293fbe2be8aa', '78b9b5f34ae207c79f22e8162fafdc63bfc232c9', 'local', '0', '1587954336', '1587954336', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('91', '1', 'g5.jpg', 'admin', 'uploads/images/20200427/9e2e491b6d1166d47433605d9f457690.jpg', '', '', 'image/jpeg', 'jpg', '44886', 'a2321dccc0f0d1f8eb1fca892f0c0401', 'fe45bfa7183c1af7ad33641d905fac89d49c4764', 'local', '0', '1587954352', '1587954352', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('92', '1', '7.jpg', 'admin', 'uploads/images/20200427/e9f50965013c558de5bf13d7aa1be549.jpg', '', '', 'image/jpeg', 'jpg', '44081', '1ea3d3769038bf34d6ea798143cc10b6', '7d345946c4bec20684103e70861c15f2e1946e0b', 'local', '0', '1587954377', '1587954377', '100', '1', '910', '177');
INSERT INTO `dp_admin_attachment` VALUES ('93', '1', '8.jpg', 'admin', 'uploads/images/20200427/df3cf5d4e8f7e81cd6215352c88bc7cf.jpg', '', '', 'image/jpeg', 'jpg', '37689', '74ef020a19a9886090dc79016b8ecc1e', '9124a14968f1a464a8376db148e82156aea1775f', 'local', '0', '1587954398', '1587954398', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('94', '1', '9.jpg', 'admin', 'uploads/images/20200427/452453d9c89733d2c0521d04612c16b8.jpg', '', '', 'image/jpeg', 'jpg', '55912', '4c705f2c2aab75f6b2aeda95887e7269', '2e6af040d2b5c8630dd47e4e31a694fc816daad3', 'local', '0', '1587954417', '1587954417', '100', '1', '910', '177');
INSERT INTO `dp_admin_attachment` VALUES ('95', '1', '10.jpg', 'admin', 'uploads/images/20200427/acbdeb648f7e9068f6d2366d79657156.jpg', '', '', 'image/jpeg', 'jpg', '44235', 'c15a95402c3ab1e90c3ca462921611b2', 'cdb54bc250db627c2731e2245d90609b823dc16a', 'local', '0', '1587954432', '1587954432', '100', '1', '910', '177');
INSERT INTO `dp_admin_attachment` VALUES ('96', '1', '20170816164548_6933.jpg', 'admin', 'uploads/images/20200427/b85de703924334ea1ff31f9f31a0e0be.jpg', '', '', 'image/jpeg', 'jpg', '173262', 'ba8b35dfd36d62e535b213503b3a00af', '7a7a66935cc5a9aefe53500fbeec9bbdd875bdf3', 'local', '0', '1587967725', '1587967725', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('97', '1', '20170816164435_2871.jpg', 'admin', 'uploads/images/20200427/a71d762299b50bb00aea8ef85cd2d33d.jpg', '', '', 'image/jpeg', 'jpg', '199293', 'a46562bc051905a4a0e436e193859c21', '9d1b4b7612c1bf2b8e5a9ad008db83b7bf313b8e', 'local', '0', '1587967839', '1587967839', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('98', '1', '20170106112332_1917.jpg', 'admin', 'uploads/images/20200427/65ded2360517c74165934f4983c8939c.jpg', '', '', 'image/jpeg', 'jpg', '116331', '15eab80509d92fddd0908e7586306d44', '46a2a5342c38c4fb6c579133560e357798fc7eb1', 'local', '0', '1587968012', '1587968012', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('99', '1', '20170106112357_4592.jpg', 'admin', 'uploads/images/20200427/de824c4c1abcb974b5492a1b4587b4bb.jpg', '', '', 'image/jpeg', 'jpg', '132093', '599f71d64a0e7538fd674491be3f86ad', '0cffefc792439cb6bc71d324209c01da45b97825', 'local', '0', '1587968033', '1587968033', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('100', '1', '20170106112558_5631.jpg', 'admin', 'uploads/images/20200427/1e66c5f0cc878568ea77af0996837053.jpg', '', '', 'image/jpeg', 'jpg', '123485', 'bd8df1f93baa8b9f00c97c9772e0990a', 'e4538cddf4031a7241ff6dc9a817830dfeed4ea9', 'local', '0', '1587968045', '1587968045', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('101', '1', '20170106112622_4574.jpg', 'admin', 'uploads/images/20200427/069613f6044d981149db9423ce72eccb.jpg', '', '', 'image/jpeg', 'jpg', '123492', 'abdf531be850dee4bdf706ccab3e3b2b', '2395f47fa55c4fb64c34dbe58cee6227a880fe10', 'local', '0', '1587968058', '1587968058', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('102', '1', '20170106111912_7729.jpg', 'admin', 'uploads/images/20200427/9d7387a39a258c4bf0a6f13a4c380209.jpg', '', '', 'image/jpeg', 'jpg', '116868', 'e37d54e05d33726ff6ee9a3c0700d3e6', '5013180128e7491e1e6b00b5a43e4779ecd3a4ff', 'local', '0', '1587968215', '1587968215', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('103', '1', '20170106111941_3615.jpg', 'admin', 'uploads/images/20200427/9ec2a40a96533f05f0cff8a75abe15e6.jpg', '', '', 'image/jpeg', 'jpg', '141751', 'ecddcea18e8fa53e65aafa620760a95e', '3ff37b5ff301ea07ff028407954b4e4a084c95e2', 'local', '0', '1587968230', '1587968230', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('104', '1', '20170106112010_3822.jpg', 'admin', 'uploads/images/20200427/bf999331e19c22368c8d57013ff3100f.jpg', '', '', 'image/jpeg', 'jpg', '98474', '0be8f5483f58d3379754aa7d77f46456', 'b7e3e1c8c1e2a6500dffe7215ac66acff5d61cdb', 'local', '0', '1587968244', '1587968244', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('105', '1', '20170106112046_8563.jpg', 'admin', 'uploads/images/20200427/6c8845d1a9155aacb37c391705cbeb37.jpg', '', '', 'image/jpeg', 'jpg', '120282', '41825284dba0a2cb8a70a38cb7d668ba', '0d8f77ee366fd5ed94b3f52eb5cc8d09137ae486', 'local', '0', '1587968260', '1587968260', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('106', '1', '20170106112112_1407.jpg', 'admin', 'uploads/images/20200427/4d5e84b3e8b4b9057a40ad233194f34a.jpg', '', '', 'image/jpeg', 'jpg', '128901', 'f7865c5cfa33da370f4bac484cd3e465', '8a303580de10e9b4ca68a93f498c21a4357eaeb6', 'local', '0', '1587968275', '1587968275', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('107', '1', '20170106112146_0636.jpg', 'admin', 'uploads/images/20200427/74c24425a48cc4730a6d93139e581277.jpg', '', '', 'image/jpeg', 'jpg', '121061', '8f38858bab50443cdbeee7b085e95fd0', 'dfc47eb2087dba31f4e179174eb4ea7e01e0865e', 'local', '0', '1587968288', '1587968288', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('108', '1', '20170106112210_5170.jpg', 'admin', 'uploads/images/20200427/4d2591300957a545e287bddb17c51b7a.jpg', '', '', 'image/jpeg', 'jpg', '130980', 'aefd064de0532db90d9992d730196a94', '6fc4246df775e8a3e95ca58d04ad02356dfd19f1', 'local', '0', '1587968300', '1587968300', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('109', '1', '20170106112242_1628.jpg', 'admin', 'uploads/images/20200427/c34a68b3a30ee83223c8ac4d9948318e.jpg', '', '', 'image/jpeg', 'jpg', '367602', '5b076dcaa114eba4b4d840cc34483db7', '5172c888326403160d9fb09c96af7fe9674f75bb', 'local', '0', '1587968312', '1587968312', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('110', '1', '20170106112309_3614.jpg', 'admin', 'uploads/images/20200427/fb255110d5f439e9733d3b3cd83dba3f.jpg', '', '', 'image/jpeg', 'jpg', '123757', 'd5d263829784a901a072659dd480e93d', 'a2cda2e0d0e225729045f6029b6b54b001496845', 'local', '0', '1587968324', '1587968324', '100', '1', '768', '509');
INSERT INTO `dp_admin_attachment` VALUES ('111', '1', '1.jpg', 'admin', 'uploads/images/20200428/f75a647d846202df75996ff7fb9a97b1.jpg', '', '', 'image/jpeg', 'jpg', '56243', '62d2616ed407b7c6167f967457e589b0', 'e565fb2e97dc1d2a5f6cd07edb640f17db361fa9', 'local', '0', '1588036105', '1588036105', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('112', '1', '2.jpg', 'admin', 'uploads/images/20200428/3f7c9ebbb3de7bb28e754467e865514a.jpg', '', '', 'image/jpeg', 'jpg', '161171', '19d937e2e336effbbdef8b5ce5e4d2e7', 'ad47f1bb0364fd08c0cf4a417a4bef115d3fbb68', 'local', '0', '1588036124', '1588036124', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('113', '1', '3.jpg', 'admin', 'uploads/images/20200428/bf15cf8cfe82842ad542788974c4cdea.jpg', '', '', 'image/jpeg', 'jpg', '173019', 'c0914d0625033360bec741d9d8d0b39b', 'f5466b61e0beeb5eabdb0cf3862c443360741dcc', 'local', '0', '1588036144', '1588036144', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('114', '1', '4.jpg', 'admin', 'uploads/images/20200428/c4853f6ae1b81d33a607a10097763936.jpg', '', '', 'image/jpeg', 'jpg', '52668', '24af5f52be01f33693ac487c711f1941', 'a4d84ac7fa440fd837e57a8418c2d5b76b0eda1d', 'local', '0', '1588036168', '1588036168', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('115', '1', '5.jpg', 'admin', 'uploads/images/20200428/5883c2dfbe26fc8a165a511f85fe3fd9.jpg', '', '', 'image/jpeg', 'jpg', '49504', '39c8f1a0ba2db3b7cba265a12ba2f608', '3c6d83ed53b6d491a5c2e70f64c8352044dbe1fb', 'local', '0', '1588036187', '1588036187', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('116', '1', '6.jpg', 'admin', 'uploads/images/20200428/222868a4cb0af172f7038ae4a3f354dd.jpg', '', '', 'image/jpeg', 'jpg', '81301', 'a72e488dc8ed42358e0e46082cca236e', '31342ec4b2c8b3ca593d3b045d1dc3ab275247a9', 'local', '0', '1588036203', '1588036203', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('117', '1', '7.jpg', 'admin', 'uploads/images/20200428/7d86f1ebe6e7345bb648ba588720038e.jpg', '', '', 'image/jpeg', 'jpg', '69378', 'bf80c65300f1872005317747422e5c7b', 'cbbe460bbe2a6f681d0cccbc771bdca4f5493927', 'local', '0', '1588036220', '1588036220', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('118', '1', '8.jpg', 'admin', 'uploads/images/20200428/7123d9531bc8b6be0e63b4b4c9fdf510.jpg', '', '', 'image/jpeg', 'jpg', '80771', '08519fbcbccdcf648be2dc82ad5d3637', '565da161731000709c6b3a266f9c6d36ac33c320', 'local', '0', '1588036236', '1588036236', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('119', '1', '9.jpg', 'admin', 'uploads/images/20200428/6987e2480d2a971f75472b8bb9c2262e.jpg', '', '', 'image/jpeg', 'jpg', '82365', '17d4ac9b8dd6255fee66fcc360fdee6e', 'c1a9567ad68555ce089406a263f44b04984ceb33', 'local', '0', '1588036253', '1588036253', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('120', '1', '10.jpg', 'admin', 'uploads/images/20200428/ced7f0871e867296265d8791cf8965a3.jpg', '', '', 'image/jpeg', 'jpg', '75279', '326f82da86f72f812bd9a6bb472a0273', '542fd44f16211a67f9cd88467be65cd97de8b37d', 'local', '0', '1588036268', '1588036268', '100', '1', '910', '224');
INSERT INTO `dp_admin_attachment` VALUES ('121', '1', '1.jpg', 'admin', 'uploads/images/20200428/f1688a0eb3a81490d479041ebee702e1.jpg', '', '', 'image/jpeg', 'jpg', '28142', '07757fb5edb3e9d3d7baa4ca311846b5', '2fafcdbf05a574525bd8357ffd9446af8c082400', 'local', '0', '1588036398', '1588036398', '100', '1', '910', '239');
INSERT INTO `dp_admin_attachment` VALUES ('122', '1', '2.jpg', 'admin', 'uploads/images/20200428/0f7c8ca0349911ba72e09f45c351e32a.jpg', '', '', 'image/jpeg', 'jpg', '61539', 'd29bce6eb2a8152049c5fdab58de4750', '2b024b91f37989b0aed772ce35e6d88d7e47866b', 'local', '0', '1588036416', '1588036416', '100', '1', '910', '239');
INSERT INTO `dp_admin_attachment` VALUES ('123', '1', '3.jpg', 'admin', 'uploads/images/20200428/e859a20b0105e7e7c49dcc76b56da2b0.jpg', '', '', 'image/jpeg', 'jpg', '65988', '89adacdc74ce77b016739a8b8dc77a9d', '23e0232e28f83f9d853bc62d4f0ca919f287274f', 'local', '0', '1588036429', '1588036429', '100', '1', '910', '238');
INSERT INTO `dp_admin_attachment` VALUES ('124', '1', '4.jpg', 'admin', 'uploads/images/20200428/11ab5624e9c703cec272b618efe29d1d.jpg', '', '', 'image/jpeg', 'jpg', '77524', '7a84e8f5bf96368d6a56120ca8a1dd88', 'a0d6596b6bd5a02b29384e91494fe0be98d5c2ac', 'local', '0', '1588036443', '1588036443', '100', '1', '910', '239');
INSERT INTO `dp_admin_attachment` VALUES ('125', '1', '5.jpg', 'admin', 'uploads/images/20200428/6a1cea4fdb5ce3cbcf5897fa3e8e7b2c.jpg', '', '', 'image/jpeg', 'jpg', '46025', '28970fac5db3d19af7bdfbbcaac6d01d', '2175c4b842d0ade9b48a4e2af612d7b4bda55f24', 'local', '0', '1588036457', '1588036457', '100', '1', '910', '239');
INSERT INTO `dp_admin_attachment` VALUES ('126', '1', '6.jpg', 'admin', 'uploads/images/20200428/e76f4046344473d9db8f0851a1090e31.jpg', '', '', 'image/jpeg', 'jpg', '35293', '44223420042dd28083fbd0dfe93a0d4f', '9cafd3c10af30f76512ca7e89171ded54c854daf', 'local', '0', '1588036472', '1588036472', '100', '1', '910', '182');
INSERT INTO `dp_admin_attachment` VALUES ('127', '1', '7.jpg', 'admin', 'uploads/images/20200428/5d3fcdb35bf09cc0780cb60813344a7d.jpg', '', '', 'image/jpeg', 'jpg', '39387', '4800e8c1b2fd087c2a70664ecd476093', '2e61a8e1bbd3315410f1e1ebc841f1e75c2a623c', 'local', '0', '1588036488', '1588036488', '100', '1', '910', '182');
INSERT INTO `dp_admin_attachment` VALUES ('128', '1', '8.jpg', 'admin', 'uploads/images/20200428/779f9e42a052ef25eaa249ec3a2d3af4.jpg', '', '', 'image/jpeg', 'jpg', '38845', 'b80c9cbff423a73a3f725b21b1185ba5', '1230d0936fc1466c88cf4c5f5da78c11f8431d15', 'local', '0', '1588036504', '1588036504', '100', '1', '910', '181');
INSERT INTO `dp_admin_attachment` VALUES ('129', '1', '9.jpg', 'admin', 'uploads/images/20200428/c4992fc61c42a82282994967760cedbb.jpg', '', '', 'image/jpeg', 'jpg', '42053', '24d4dc9b172ef502b36109fcb9ad4fc8', '21bd008c883a21cd5a938d1afcc430bac586cc48', 'local', '0', '1588036541', '1588036541', '100', '1', '910', '182');
INSERT INTO `dp_admin_attachment` VALUES ('130', '1', '10.jpg', 'admin', 'uploads/images/20200428/e1303959bcf8bcb92741ea7b244f7813.jpg', '', '', 'image/jpeg', 'jpg', '21256', '7fd125819a82a63f8779c71ccf7ee526', '34663174f1c26c4d51d53e4578b743f833649508', 'local', '0', '1588036557', '1588036557', '100', '1', '910', '182');
INSERT INTO `dp_admin_attachment` VALUES ('131', '1', 'c1.png', 'admin', 'uploads/images/20200428/dbfbc354e4bc983d9fa7473a800ddf44.png', '', '', 'image/png', 'png', '52078', 'be89b6c39d51664e9ae2f22cd2568b12', 'ac431598fd217a95e8bb3e12bcb5d048d25793dd', 'local', '0', '1588036629', '1588036629', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('132', '1', 'c2.png', 'admin', 'uploads/images/20200428/62cd936003a89961965b4ca7dca6734d.png', '', '', 'image/png', 'png', '333011', '258c2ae327f5b343fd04954f76c38db7', '426215a5265117f47c4de51882006ee6694d00a4', 'local', '0', '1588036647', '1588036647', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('133', '1', 'c3.png', 'admin', 'uploads/images/20200428/cae83a4d9f2d73634a558ab01c926cd3.png', '', '', 'image/png', 'png', '41700', '8adb16f6f2e56bc313fbe21f4aca8dd2', 'dcd70ab5b0cebff0d1af80d710b5c1807b227ce0', 'local', '0', '1588036662', '1588036662', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('134', '1', 'c4.png', 'admin', 'uploads/images/20200428/bc9459dd763e9344d7ea227c5d84f181.png', '', '', 'image/png', 'png', '330343', '14a0188a9bff1c30c92cee3089719bcf', 'a59943693eb34dfb4d20f8afbb4496da5103562c', 'local', '0', '1588036676', '1588036676', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('135', '1', 'c5.png', 'admin', 'uploads/images/20200428/7631d8d419ae247a73e8229bacdda564.png', '', '', 'image/png', 'png', '43982', '22b3670a78946b5b4b662ba5faafebda', 'c5865382278af2f458e29d85c516921f90430b56', 'local', '0', '1588036697', '1588036697', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('136', '1', 'c6.png', 'admin', 'uploads/images/20200428/569b8d9d1b939450d801d16de1c20d25.png', '', '', 'image/png', 'png', '371716', 'c8890c4dfcff09688b673486ebf960f0', '22504236ffc0a8738d5a90fe473d5a21cb66a90c', 'local', '0', '1588036709', '1588036709', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('137', '1', 'c7.png', 'admin', 'uploads/images/20200428/74137bdb17e9d4c108ad37d9c0e81155.png', '', '', 'image/png', 'png', '45510', 'e8110da75bbb8f03b12cb7bcf2a617e8', '7a1700efa5f7e9806aeb25a8e51995ad20d1c5f0', 'local', '0', '1588036723', '1588036723', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('138', '1', 'c8.png', 'admin', 'uploads/images/20200428/95bdbcfec32c736a27216aec91869796.png', '', '', 'image/png', 'png', '267324', '79edf80a0c611281fc2e73276cc8182d', 'c68274bb87da73124f0c1bd17d819f6e7f75cc71', 'local', '0', '1588036737', '1588036737', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('139', '1', 'g1.jpg', 'admin', 'uploads/images/20200428/8bba1d61e1f79a7d5f9968214d31d478.jpg', '', '', 'image/jpeg', 'jpg', '33070', 'f034273d6c48b78b7181608b09f01ad4', '0221fab9f309ac62ad074c1c636b050c190c4648', 'local', '0', '1588036782', '1588036782', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('140', '1', 'g2.jpg', 'admin', 'uploads/images/20200428/9920f1a189613d794b0a39886632f563.jpg', '', '', 'image/jpeg', 'jpg', '31083', 'ceacdd51d09a9147c5194b3c925af6e5', '819fec2926e91d4f39f0767c1491f54ae80bd073', 'local', '0', '1588036805', '1588036805', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('141', '1', 'g3.jpg', 'admin', 'uploads/images/20200428/ecfce90deb03a05ad25379866821fffd.jpg', '', '', 'image/jpeg', 'jpg', '37028', 'c39da4918d26a613a6c17420e8947f84', '6065f3a787d85dc914ed67b03e2ddeeba8552ca8', 'local', '0', '1588036819', '1588036819', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('142', '1', 'g4.jpg', 'admin', 'uploads/images/20200428/8c1627e417537f949cbd55fd896f1ed0.jpg', '', '', 'image/jpeg', 'jpg', '55289', '230484f76d32641ae139312bede25640', '45d7628f399f82a2e6b77b818cb7cc3ee5ec7863', 'local', '0', '1588036832', '1588036832', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('143', '1', 'g5.jpg', 'admin', 'uploads/images/20200428/223b833156240a46721c1a8507c19c04.jpg', '', '', 'image/jpeg', 'jpg', '49644', '68495d03843d1a1f09e9dbfaceffd808', '7952cb58cbecd8be6260c845db5a1cf9d1c8a3f8', 'local', '0', '1588036846', '1588036846', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('144', '1', 'g6.jpg', 'admin', 'uploads/images/20200428/51713fbcc3fb634774207356edf759f7.jpg', '', '', 'image/jpeg', 'jpg', '49592', '255923c68d3e4715ab4d325fc42e898e', 'bce94b2301e6ae7c472e9daf9f4aefa78dacf794', 'local', '0', '1588036860', '1588036860', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('145', '1', 'g7.jpg', 'admin', 'uploads/images/20200428/040269aec3ee74b8f276271a0c791e8f.jpg', '', '', 'image/jpeg', 'jpg', '60527', '3d5e9b929eaadf7d715ede0920645b29', 'b1882610c61b5ca3d212e9b42c401118e9cbd462', 'local', '0', '1588036875', '1588036875', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('146', '1', '20180621152952_5297.jpg', 'admin', 'uploads/images/20200428/fea5021343189b33a99d235482799a3e.jpg', '', '', 'image/jpeg', 'jpg', '102648', '8fa33eeed4be1ab611f65dad3536e5c6', '680919f7fbe6c35f07976277b6677319506bd28e', 'local', '0', '1588038015', '1588038015', '100', '1', '780', '1000');
INSERT INTO `dp_admin_attachment` VALUES ('147', '1', '20171106142044_3935.jpg', 'admin', 'uploads/images/20200428/57e7829ec754c9ee71ff59b80d4b0948.jpg', '', '', 'image/jpeg', 'jpg', '248218', '1ddf62e1065eed75681a96abed071ebc', '332e84aaa9387e8c53554d02239d4d71949668c9', 'local', '0', '1588038131', '1588038131', '100', '1', '780', '700');
INSERT INTO `dp_admin_attachment` VALUES ('148', '1', '20171106140707_5966.jpg', 'admin', 'uploads/images/20200428/097244f945bfe06b380800f8ced16c3d.jpg', '', '', 'image/jpeg', 'jpg', '177962', 'f458ed30d52ae55f1369963893287ae0', 'cbe3ef9afc85fc4dc33c981848873fceb7161b2e', 'local', '0', '1588038566', '1588038566', '100', '1', '780', '524');
INSERT INTO `dp_admin_attachment` VALUES ('149', '1', '20171106140131_4091.jpg', 'admin', 'uploads/images/20200428/8d4f38187f1ad99af1f0f0096c77b237.jpg', '', '', 'image/jpeg', 'jpg', '262469', '76b0eaa2892de30c0e68858644c7e3ad', '5240f67911d200b83936a9edc404e8a28d9ccc16', 'local', '0', '1588039633', '1588039633', '100', '1', '780', '524');
INSERT INTO `dp_admin_attachment` VALUES ('150', '1', '20171106134943_2060.jpg', 'admin', 'uploads/images/20200428/72c93045a1bbc1b35ae126a8b777415a.jpg', '', '', 'image/jpeg', 'jpg', '231224', 'c092253f78bce00a67cd61ff75d3ab57', '189ec2b2ae366809f4a2bd690b6c53eac7b30421', 'local', '0', '1588039804', '1588039804', '100', '1', '780', '524');
INSERT INTO `dp_admin_attachment` VALUES ('151', '1', '20191225141032_1547.jpg', 'admin', 'uploads/images/20200428/8ec28f2157560364690336cd8fd602cf.jpg', '', '', 'image/jpeg', 'jpg', '649085', '94f57ab7904f8e186ce0a478b5e9beec', '177fc1647aeb8444db3fc94498c46b140b0231e9', 'local', '0', '1588039975', '1588039975', '100', '1', '780', '572');
INSERT INTO `dp_admin_attachment` VALUES ('152', '1', '20190927173943_2968.jpg', 'admin', 'uploads/images/20200428/537c5dec42fc90070005fb0d7035b190.jpg', '', '', 'image/jpeg', 'jpg', '150899', '74e26f94da5d5a481986cd43bf8d375a', '845f2dc7e9817eec24c7b191e316ac19d91f154a', 'local', '0', '1588040095', '1588040095', '100', '1', '1080', '1528');
INSERT INTO `dp_admin_attachment` VALUES ('153', '1', '20190731141934_2865.jpg', 'admin', 'uploads/images/20200428/0c48959ee879c3746f843c8987388a26.jpg', '', '', 'image/jpeg', 'jpg', '55227', 'bba209329c473564b158c07869970a1a', 'ca61b0e809773044211da9013bf7ddd1dfebb683', 'local', '0', '1588040208', '1588040208', '100', '1', '780', '796');
INSERT INTO `dp_admin_attachment` VALUES ('154', '1', '20190723164601_0018.jpg', 'admin', 'uploads/images/20200428/5eeb10f2222a9dd3062cc8bb641024e4.jpg', '', '', 'image/jpeg', 'jpg', '53811', 'b64b091e884c9a07e812c5018a5468e7', 'e7fbc14be04eafe336578d41b3d6332e62540a8f', 'local', '0', '1588040400', '1588040400', '100', '1', '780', '796');
INSERT INTO `dp_admin_attachment` VALUES ('155', '1', '20190723160127_7675.jpg', 'admin', 'uploads/images/20200428/c2c5e480ab3bd53459e6863fd5245ac1.jpg', '', '', 'image/jpeg', 'jpg', '415551', '7bcb97e1b001a9d7adc60798932af59d', '6863d010d9a2f7457853628a38cd1fb04726ef43', 'local', '0', '1588040540', '1588040540', '100', '1', '1242', '621');
INSERT INTO `dp_admin_attachment` VALUES ('156', '1', '1.jpg', 'admin', 'uploads/images/20200428/651650beab74c020fe857e87e5bdb494.jpg', '', '', 'image/jpeg', 'jpg', '34744', '930ae9ff5912d3778d6e8c3a9fe8c043', '9a8ec844fb20515173f699027c6f96c2c33c7ff5', 'local', '0', '1588055260', '1588055260', '100', '1', '910', '163');
INSERT INTO `dp_admin_attachment` VALUES ('157', '1', '2.jpg', 'admin', 'uploads/images/20200428/0b8b7dc7c83845c470790da9e71f0290.jpg', '', '', 'image/jpeg', 'jpg', '24971', 'a94ce38b3e207e427c04a80188cf29cb', 'd63e072f73af35e02d9e8077c2a265e36496104e', 'local', '0', '1588055431', '1588055431', '100', '1', '910', '53');
INSERT INTO `dp_admin_attachment` VALUES ('158', '1', '3.jpg', 'admin', 'uploads/images/20200428/f02bc4eeb09647d076fb03eda02b028c.jpg', '', '', 'image/jpeg', 'jpg', '41463', '9887bf6703699d089f3fb7c4c429d838', '15b3d33477053a089b06e56a5b47c8e45f983c91', 'local', '0', '1588055444', '1588055444', '100', '1', '910', '327');
INSERT INTO `dp_admin_attachment` VALUES ('159', '1', '4.jpg', 'admin', 'uploads/images/20200428/abe8432a81a86988de242eff0212bc1e.jpg', '', '', 'image/jpeg', 'jpg', '17776', '2e468603f9023faf18f55e57277884ce', '13a92d9b8826432841a5a2f14f739b7163ebef44', 'local', '0', '1588055458', '1588055458', '100', '1', '910', '59');
INSERT INTO `dp_admin_attachment` VALUES ('160', '1', '5.jpg', 'admin', 'uploads/images/20200428/5ef5da018050789dd45076d62cbb32c4.jpg', '', '', 'image/jpeg', 'jpg', '56502', 'd9de3a20d1c77e3f27889f6e8f0b06f1', 'b25c344cb0cea2b5aa5c1b71edb9f71f9cec7fe5', 'local', '0', '1588055473', '1588055473', '100', '1', '910', '162');
INSERT INTO `dp_admin_attachment` VALUES ('161', '1', '6.jpg', 'admin', 'uploads/images/20200428/9e28da75302e898ff5ae9ce4a73b1349.jpg', '', '', 'image/jpeg', 'jpg', '91306', '3ea756933d224f1b2cf129bcee8b22c5', '30442dfcc7ec3a22c582ca6b67ab42182f1c208d', 'local', '0', '1588055488', '1588055488', '100', '1', '910', '163');
INSERT INTO `dp_admin_attachment` VALUES ('162', '1', '7.jpg', 'admin', 'uploads/images/20200428/4a0ff23155074bc5f2df0f608a40dba5.jpg', '', '', 'image/jpeg', 'jpg', '86072', '7201d117d90c107e9b1bc8c887a35f27', 'd4efe139e61f986ee1016333623e9d6e09febb60', 'local', '0', '1588055510', '1588055510', '100', '1', '910', '163');
INSERT INTO `dp_admin_attachment` VALUES ('163', '1', '8.jpg', 'admin', 'uploads/images/20200428/d5cb7b0dc056ec7217dfde5594cfb0d2.jpg', '', '', 'image/jpeg', 'jpg', '90399', 'c8da8005edfb6c520a7caf672bae42ce', '318365580faa13f04f079d92d61a784b2046f9b0', 'local', '0', '1588055567', '1588055567', '100', '1', '910', '163');
INSERT INTO `dp_admin_attachment` VALUES ('164', '1', '9.jpg', 'admin', 'uploads/images/20200428/61de960bddbea66c32d19ff9483f7ece.jpg', '', '', 'image/jpeg', 'jpg', '43610', '453726382b23aca467c684b904eb4d9d', 'f6506d894e437ff788362c18d1b7d7580d1edbc1', 'local', '0', '1588055581', '1588055581', '100', '1', '910', '163');
INSERT INTO `dp_admin_attachment` VALUES ('165', '1', '10.jpg', 'admin', 'uploads/images/20200428/c95ca7177567230eefa2f3600331ac84.jpg', '', '', 'image/jpeg', 'jpg', '53285', '2610f8db9112a84a9b37884c2f87524f', '694fd8c253504824414a8dc768539d27b9da432f', 'local', '0', '1588055601', '1588055601', '100', '1', '910', '163');
INSERT INTO `dp_admin_attachment` VALUES ('166', '1', 'spbg.jpg', 'admin', 'uploads/images/20200428/e5d62ec4e240d122ddcb7b4eedd7c16d.jpg', '', '', 'image/jpeg', 'jpg', '62547', '61f289c07f4633f91a036d5c2a93426b', 'e68e3dccdb253db75d85ca342522ebecbff71e02', 'local', '0', '1588057244', '1588057244', '100', '1', '480', '327');
INSERT INTO `dp_admin_attachment` VALUES ('168', '1', 'sp.mp4', 'admin', 'uploads/files/20200428/650e913ad855e5cfc60f427b4f368ce7.mp4', '', '', 'video/mp4', 'mp4', '211655425', '60a93a3de2d5664042d1b0dfbca041a3', '87b75b46f3f925544e8b6d23b6dd3426f4f8776a', 'local', '0', '1588060641', '1588060641', '100', '1', '0', '0');
INSERT INTO `dp_admin_attachment` VALUES ('169', '1', '1.jpg', 'admin', 'uploads/images/20200428/771667a4a6a5eec686a1b908f0592ee3.jpg', '', '', 'image/jpeg', 'jpg', '46250', '4e96219d9a0e4894bc161b43c2083dbd', '7cc00b188dfa5db2c89b59edb047500ac7790fe2', 'local', '0', '1588063764', '1588063764', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('170', '1', '2.jpg', 'admin', 'uploads/images/20200428/fa524e24b36cac429629718f7c2f04ea.jpg', '', '', 'image/jpeg', 'jpg', '71597', '8c3537b3119f31794372ef161e35306a', 'eac9f2c97f19b4a65be737a1a516abff8579618a', 'local', '0', '1588063778', '1588063778', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('171', '1', '3.jpg', 'admin', 'uploads/images/20200428/f816ef164ac208b153c2c76a9a106fb9.jpg', '', '', 'image/jpeg', 'jpg', '73572', 'f0c44b7d92fa3c814226a56b90f24d16', '77b416aa793c10a3d1ec306eb4bfba21891a139f', 'local', '0', '1588063790', '1588063790', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('172', '1', '4.jpg', 'admin', 'uploads/images/20200428/607f8a91f1d523f55006f63589532cc9.jpg', '', '', 'image/jpeg', 'jpg', '87251', '803c98c51307afd4411d669977adbe53', '2b6d7655c1cf0d38088b52fdc75110a91ab1bb3c', 'local', '0', '1588063804', '1588063804', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('173', '1', '5.jpg', 'admin', 'uploads/images/20200428/a5f571f32923fe900d276827072f9f5c.jpg', '', '', 'image/jpeg', 'jpg', '122164', 'fb65bca424f767c0d81ffa1dc3851941', '9926883af94619c96cecf9998a89f5a5003fed51', 'local', '0', '1588063819', '1588063819', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('174', '1', '6.jpg', 'admin', 'uploads/images/20200428/b608a35f7bb0147e171f25bc5601dc26.jpg', '', '', 'image/jpeg', 'jpg', '69703', '7949053d1e83b2c672955f9ec68faf6f', 'd7c036e38b975dc7f71ca12628a319f65c2a4681', 'local', '0', '1588063836', '1588063836', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('175', '1', '7.jpg', 'admin', 'uploads/images/20200428/561590cd828f54f6acfa3fc43c0cdf8e.jpg', '', '', 'image/jpeg', 'jpg', '86065', '2b29c164969e6cf74e373597035fe567', 'a0840bfaa67d697ad7c65534519249e5d5ce0bcf', 'local', '0', '1588063851', '1588063851', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('176', '1', '8.jpg', 'admin', 'uploads/images/20200428/3cadf0bdd2b7dc657381f5a13fea4b95.jpg', '', '', 'image/jpeg', 'jpg', '83286', '4bd621284f71f0c87084e1b744f2ebf1', 'aeeb22483e3523701cc1cdfc0ab46ba733c9a698', 'local', '0', '1588063865', '1588063865', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('177', '1', '9.jpg', 'admin', 'uploads/images/20200428/6a142f6ca081e3aa0eb77a425e9fc3ca.jpg', '', '', 'image/jpeg', 'jpg', '51803', '46fc786b584759841af6014eafa55f6c', '08990e1337032bf68cc3c6c871833264be33a907', 'local', '0', '1588063878', '1588063878', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('178', '1', '10.jpg', 'admin', 'uploads/images/20200428/7c9a342fabc39d784d11b59f196f36e1.jpg', '', '', 'image/jpeg', 'jpg', '63276', 'a0aaab7df2dfea274d9b0f2a96055862', 'c061ad442293733784054b7e8fd9f0a600c6d0b7', 'local', '0', '1588063890', '1588063890', '100', '1', '910', '193');
INSERT INTO `dp_admin_attachment` VALUES ('179', '1', '1.jpg', 'admin', 'uploads/images/20200428/f5ab67da2ba2cb8adcdf201f00f3d6ed.jpg', '', '', 'image/jpeg', 'jpg', '25328', '9e0ef308e26166c0ab947679a56b3e4c', 'ac797d8580afef666c7393b20ebe88c427acb4f4', 'local', '0', '1588063950', '1588063950', '100', '1', '910', '137');
INSERT INTO `dp_admin_attachment` VALUES ('180', '1', '2.jpg', 'admin', 'uploads/images/20200428/b3b80414ae279f7a78aaf37a6789abca.jpg', '', '', 'image/jpeg', 'jpg', '35481', '365de281d459c5619b1ddf91fbea854a', '57edbf9f0a93ee1d9fc97dbf4107ce90e830221f', 'local', '0', '1588063965', '1588063965', '100', '1', '910', '137');
INSERT INTO `dp_admin_attachment` VALUES ('181', '1', '3.jpg', 'admin', 'uploads/images/20200428/28a6dd629db3ba2a961ee4ccb147ad3e.jpg', '', '', 'image/jpeg', 'jpg', '37200', '64da2c63f3cb5554137d05733dadd420', 'd77c6c1c7b6c17db68200d81f82fbae31001de30', 'local', '0', '1588063978', '1588063978', '100', '1', '910', '136');
INSERT INTO `dp_admin_attachment` VALUES ('182', '1', '4.jpg', 'admin', 'uploads/images/20200428/59c9c16dd0974503ae497d89e7d034cd.jpg', '', '', 'image/jpeg', 'jpg', '38496', '91b89717fe8bc989f99b600bddc03952', '1f648d4edc91d08acc2011a141e371fbd02e0f61', 'local', '0', '1588063991', '1588063991', '100', '1', '910', '137');
INSERT INTO `dp_admin_attachment` VALUES ('183', '1', '5.jpg', 'admin', 'uploads/images/20200428/48f53df0847691fa616a917a21706667.jpg', '', '', 'image/jpeg', 'jpg', '36105', 'b7d3bd3032a36071ebd556972df1ec64', 'a3e7ee6f915055160169d90d8da6d8ba220b8c95', 'local', '0', '1588064006', '1588064006', '100', '1', '910', '137');
INSERT INTO `dp_admin_attachment` VALUES ('184', '1', '6.jpg', 'admin', 'uploads/images/20200428/a6a70eed4f2d439f88eb69a7e62d881e.jpg', '', '', 'image/jpeg', 'jpg', '43479', 'f423039ad8bc41d9c97349737be24364', '8b51b2eed37bfe455202bd424a6e6fce0092b7e6', 'local', '0', '1588064020', '1588064020', '100', '1', '910', '137');
INSERT INTO `dp_admin_attachment` VALUES ('185', '1', '7.jpg', 'admin', 'uploads/images/20200428/fc6425221ec4dc6a27aa23588f0573fe.jpg', '', '', 'image/jpeg', 'jpg', '34691', '4759b4d6f5946033426309ddfb9505b0', 'a71006465b662e542709c10698156458393a4f97', 'local', '0', '1588064035', '1588064035', '100', '1', '910', '137');
INSERT INTO `dp_admin_attachment` VALUES ('186', '1', '8.jpg', 'admin', 'uploads/images/20200428/378d33bb4e71be7d7c6b6253126a0b05.jpg', '', '', 'image/jpeg', 'jpg', '29393', '582b7aa643cbbffce7829eeba2fcb110', '4a87b11346bed24cd372fbb0ac7b247b7e018fe5', 'local', '0', '1588064048', '1588064048', '100', '1', '910', '136');
INSERT INTO `dp_admin_attachment` VALUES ('187', '1', '9.jpg', 'admin', 'uploads/images/20200428/81336e8621e8c12a7ee1a37d62e9ed8e.jpg', '', '', 'image/jpeg', 'jpg', '34828', '7cc71ee829470c27dc1b1133a1c2fb7e', '0769d4e4f46ca4cbd6e13e94309f14b6414d2318', 'local', '0', '1588064062', '1588064062', '100', '1', '910', '137');
INSERT INTO `dp_admin_attachment` VALUES ('188', '1', '10.jpg', 'admin', 'uploads/images/20200428/802debfb2a25e80a5830c674895eb38e.jpg', '', '', 'image/jpeg', 'jpg', '20549', '166ef6df13fc8ee53db1f5a5eb44f1d2', '864618106492db118f7e295606b63d6190a5b7d6', 'local', '0', '1588064075', '1588064075', '100', '1', '910', '137');
INSERT INTO `dp_admin_attachment` VALUES ('189', '1', '1.jpg', 'admin', 'uploads/images/20200429/ab04534070376e47830ebcfb26600b79.jpg', '', '', 'image/jpeg', 'jpg', '38884', '36debaa59b523500fa9afdd72e5b9021', '02dc3ee32c699032409232e79e9bb162f0f0b8fa', 'local', '0', '1588132620', '1588132620', '100', '1', '910', '213');
INSERT INTO `dp_admin_attachment` VALUES ('190', '1', '2.jpg', 'admin', 'uploads/images/20200429/e36acd7ffbf299aab040a89863e03e9f.jpg', '', '', 'image/jpeg', 'jpg', '58412', '062732c038108685ff9a7dfcfb737a84', '946c29ce9ea28b427c3b9ce80f1fdcdfdd10430d', 'local', '0', '1588132769', '1588132769', '100', '1', '910', '213');
INSERT INTO `dp_admin_attachment` VALUES ('191', '1', '3.jpg', 'admin', 'uploads/images/20200429/ef1603d329d034c6618d87cddd72b0fd.jpg', '', '', 'image/jpeg', 'jpg', '40277', '6ca5e58cc1b0ed3e824897dc31ad1729', 'b6e2d99ecb5ca8e1b6d18dd8be2acfe64287efe7', 'local', '0', '1588132781', '1588132781', '100', '1', '910', '134');
INSERT INTO `dp_admin_attachment` VALUES ('192', '1', '4.jpg', 'admin', 'uploads/images/20200429/fa402b299d3d96c307967c0e8ac992b7.jpg', '', '', 'image/jpeg', 'jpg', '25445', '8fb3c8da0dcf138fd3a4aa2efd32b1a5', 'ad612e43c64fa81590a91f1813ee789fdf7924c7', 'local', '0', '1588132797', '1588132797', '100', '1', '910', '364');
INSERT INTO `dp_admin_attachment` VALUES ('193', '1', '5.jpg', 'admin', 'uploads/images/20200429/5a9f095d32ce96bb289ae3023215388b.jpg', '', '', 'image/jpeg', 'jpg', '36283', 'd7184715b623b42ceed5cbf24d7fa347', '0a037fde0b67487401fd21e7a287a72e5c98ff85', 'local', '0', '1588135507', '1588135507', '100', '1', '910', '189');
INSERT INTO `dp_admin_attachment` VALUES ('194', '1', '6.jpg', 'admin', 'uploads/images/20200429/55fa8ff545c4578c968b1e64a66f3a6d.jpg', '', '', 'image/jpeg', 'jpg', '94772', 'cda91ae03e7968cec309a40d9d2c2601', 'e87352acd2ccc81837e2c489c141d29d941701cf', 'local', '0', '1588135523', '1588135523', '100', '1', '910', '319');
INSERT INTO `dp_admin_attachment` VALUES ('195', '1', '7.jpg', 'admin', 'uploads/images/20200429/d010f90dc825c693aac26985e131838f.jpg', '', '', 'image/jpeg', 'jpg', '13786', '9760472683f9ff57665e6a923705e34d', 'ca45e209ce7e67110a1a0e262e1180a4895b63d1', 'local', '0', '1588135536', '1588135536', '100', '1', '910', '58');
INSERT INTO `dp_admin_attachment` VALUES ('196', '1', '8.jpg', 'admin', 'uploads/images/20200429/c014993737cb8bfa263eb971fb2aa8a3.jpg', '', '', 'image/jpeg', 'jpg', '31477', '029950f0958c601f9ac093dc9c012e9e', '8cd585069e09fb9dfa1031488e406a5e82f49528', 'local', '0', '1588135554', '1588135554', '100', '1', '910', '212');
INSERT INTO `dp_admin_attachment` VALUES ('197', '1', '9.jpg', 'admin', 'uploads/images/20200429/15535ff42e2de091c8bde1617164be6f.jpg', '', '', 'image/jpeg', 'jpg', '122161', '09b79710c1dd123d4bc0ef66e34330d9', '33212b057c5e4137e89c2dac6788ae80b89027f5', 'local', '0', '1588135570', '1588135570', '100', '1', '910', '213');
INSERT INTO `dp_admin_attachment` VALUES ('198', '1', '10.jpg', 'admin', 'uploads/images/20200429/c6f8f372e1ccc4f8c783d5289d2fa63d.jpg', '', '', 'image/jpeg', 'jpg', '49678', '76e59646b7f996ba85dae7073726f676', '8aba84c99d8cbe6d8e8ea1ce107da1032ee9773a', 'local', '0', '1588135582', '1588135582', '100', '1', '910', '213');
INSERT INTO `dp_admin_attachment` VALUES ('199', '1', '20170113142454_4375.jpg', 'admin', 'uploads/images/20200429/78054c35ab121567bd3c2993f312219e.jpg', '', '', 'image/jpeg', 'jpg', '46972', '9c3eb5ef3d4da81899ab5009c4628e85', '78925f34bd25952d1565667cb81d7d59025dbad7', 'local', '0', '1588137540', '1588137540', '100', '1', '298', '214');
INSERT INTO `dp_admin_attachment` VALUES ('200', '1', '20170113143727_5625.jpg', 'admin', 'uploads/images/20200429/67b41077209d95bac1fe5f610dca560a.jpg', '', '', 'image/jpeg', 'jpg', '55157', '0d4d219d28d623a5e9466c07718d3e90', '0bef2b07970a1df07b1a67d66d7a3093064c5c9b', 'local', '0', '1588139676', '1588139676', '100', '1', '298', '214');
INSERT INTO `dp_admin_attachment` VALUES ('201', '1', '20170113145615_1562.jpg', 'admin', 'uploads/images/20200429/053ff432801c1490012aac9881d794de.jpg', '', '', 'image/jpeg', 'jpg', '53350', '05082b86b4dc7952f8beef66bbb69c35', '9865b659b084b1f6472bacef1a644f140d17d1e7', 'local', '0', '1588139751', '1588139751', '100', '1', '298', '214');
INSERT INTO `dp_admin_attachment` VALUES ('202', '1', '20170113150140_1093.jpg', 'admin', 'uploads/images/20200429/72e7cfd3889749644fb5c6af5777e157.jpg', '', '', 'image/jpeg', 'jpg', '55201', '76dff0f26c1dbff51a6d72cef93d9443', '7f868257fc560771a77bac2a09912210711c9e39', 'local', '0', '1588140652', '1588140652', '100', '1', '298', '214');
INSERT INTO `dp_admin_attachment` VALUES ('203', '1', '20170113150603_2500.jpg', 'admin', 'uploads/images/20200429/3ce30af91a8f085757fb001783cf4ccb.jpg', '', '', 'image/jpeg', 'jpg', '49471', 'a4a8e574854bf9833df4513015b54eaf', 'bf90e39d1c11731f67da5402851157e68f8d08d9', 'local', '0', '1588140728', '1588140728', '100', '1', '298', '214');
INSERT INTO `dp_admin_attachment` VALUES ('204', '1', '20170113151557_7343.jpg', 'admin', 'uploads/images/20200429/f426e763e316164848789c0dbb813532.jpg', '', '', 'image/jpeg', 'jpg', '49286', '521d198d3719a61c9ca5e44b67e93dc8', 'd6df643ac3efb085581bc9f0e3e0ccab6ea6dae3', 'local', '0', '1588140771', '1588140771', '100', '1', '298', '214');
INSERT INTO `dp_admin_attachment` VALUES ('205', '1', '1.jpg', 'admin', 'uploads/images/20200429/b150639af4ede79f857a00e61cbf589d.jpg', '', '', 'image/jpeg', 'jpg', '46503', '99bfebadf1d0c79f7c3894cefe266cbb', '075b6fe7cfb56bcda1c04989d874bb88e0574c87', 'local', '0', '1588151431', '1588151431', '100', '1', '910', '176');
INSERT INTO `dp_admin_attachment` VALUES ('206', '1', '5.jpg', 'admin', 'uploads/images/20200429/b6c2beee0bb44b3206a1ea9cc4e4a78b.jpg', '', '', 'image/jpeg', 'jpg', '119802', '709bef042c8cfe703d2b043092bc19ef', '682f07cf91368d915a10ba284c75d8672894fdf2', 'local', '0', '1588151542', '1588151542', '100', '1', '910', '494');
INSERT INTO `dp_admin_attachment` VALUES ('207', '1', 'transparent.gif', 'admin', 'uploads/images/20200429/7e41652a7a76d7347a701954d8dcab30.gif', '', '', 'image/gif', 'gif', '43', '325472601571f31e1bf00674c368d335', '2daeaa8b5f19f0bc209d976c02bd6acb51b00b0a', 'local', '0', '1588151953', '1588151953', '100', '1', '1', '1');
INSERT INTO `dp_admin_attachment` VALUES ('208', '1', '1.jpg', 'admin', 'uploads/images/20200430/afe5f0d706870047012adc5e6e29e2b7.jpg', '', '', 'image/jpeg', 'jpg', '27436', '016fc9f217e18ed86ad484a21b761967', 'f80170a9b40d099033c57461824abd557014b9f7', 'local', '0', '1588215058', '1588215058', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('209', '1', '2.jpg', 'admin', 'uploads/images/20200430/a3fcbc3cc765b965bcc2fabf40ee88cd.jpg', '', '', 'image/jpeg', 'jpg', '66699', '015cc807a8ebc5c9cc80dbc83096f6c3', '799ff765176d6a52e71b1024edaa915688bd3e7b', 'local', '0', '1588215077', '1588215077', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('210', '1', '3.jpg', 'admin', 'uploads/images/20200430/f77edb13b6e738194269c1128432470e.jpg', '', '', 'image/jpeg', 'jpg', '76017', '5d83f87b0c9ae43629a832d5d28ec177', '0a1fa06218999fddb4fef1a5990ce30097820b80', 'local', '0', '1588215099', '1588215099', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('211', '1', '4.jpg', 'admin', 'uploads/images/20200430/9a2d3e9185899450e1439f2520f15348.jpg', '', '', 'image/jpeg', 'jpg', '77450', '969c71be4beda7ab7186e1bff91cf83c', 'f8f35da779d014b7ebab959b21590f139ab78ffa', 'local', '0', '1588215112', '1588215112', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('212', '1', '5.jpg', 'admin', 'uploads/images/20200430/bcd86607f53f9929d5853256f3ec7eeb.jpg', '', '', 'image/jpeg', 'jpg', '47615', '78e2d1028779d01dfd95ade4f6f67409', 'fedf149ddeb7260edfba2dfd806ed290fe2ed56c', 'local', '0', '1588215128', '1588215128', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('213', '1', '6.jpg', 'admin', 'uploads/images/20200430/2562a6385ad235a42d1407fe5cb37d8e.jpg', '', '', 'image/jpeg', 'jpg', '37983', '461f92ad20bc009058fcd6b5bab83c62', '1e40b818a67569ac1110ae495c1ca71e65765c61', 'local', '0', '1588215143', '1588215143', '100', '1', '910', '183');
INSERT INTO `dp_admin_attachment` VALUES ('214', '1', '7.jpg', 'admin', 'uploads/images/20200430/26071f577fdc5d0d7f283fef00580a1f.jpg', '', '', 'image/jpeg', 'jpg', '38602', 'f65a31d887dd6b56956560ae0d9e9d11', 'e3a4fbc340c804b0d33350b822753b950541efd2', 'local', '0', '1588215158', '1588215158', '100', '1', '910', '183');
INSERT INTO `dp_admin_attachment` VALUES ('215', '1', '8.jpg', 'admin', 'uploads/images/20200430/db2a0539f8d5d5f754b8e784c7b223ba.jpg', '', '', 'image/jpeg', 'jpg', '50935', '95e0bdeb661baf086a13d30eb1f06dfb', '8822f530df69c888a62dd2747e1d3d73aec756f7', 'local', '0', '1588215175', '1588215175', '100', '1', '910', '183');
INSERT INTO `dp_admin_attachment` VALUES ('216', '1', '9.jpg', 'admin', 'uploads/images/20200430/46504a98e4690db8411f03f6b01c8d19.jpg', '', '', 'image/jpeg', 'jpg', '60789', 'de90ac71d34a43611b4f67928b32ad8a', 'c3a0464d03283e5cc3b16d1b81d59fd34d16b266', 'local', '0', '1588215192', '1588215192', '100', '1', '910', '183');
INSERT INTO `dp_admin_attachment` VALUES ('217', '1', '10.jpg', 'admin', 'uploads/images/20200430/d2282800cc2630df76ce762c4ed5e7cc.jpg', '', '', 'image/jpeg', 'jpg', '41525', '95cc5eb52b774d01f2769fa979046c26', '224e8d9b8b027a418597ce3a6bd9aa38c1e47aea', 'local', '0', '1588215211', '1588215211', '100', '1', '910', '183');
INSERT INTO `dp_admin_attachment` VALUES ('218', '1', 'c1.png', 'admin', 'uploads/images/20200430/06d379bb1bd70dc1e4dded83ce89706a.png', '', '', 'image/png', 'png', '41850', 'b0d2dbce8ae380525437cef45c851c90', '9d5a3ff6cea69d24eb63cad6f460af7048ca3388', 'local', '0', '1588215305', '1588215305', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('219', '1', 'c2.png', 'admin', 'uploads/images/20200430/098583cdbfc799999127fc407159d464.png', '', '', 'image/png', 'png', '353531', '2989f505146a0a711d42c9f812abcca3', 'ad171a41bab6239643693eabf752109d5f880ac9', 'local', '0', '1588215321', '1588215321', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('220', '1', 'c3.png', 'admin', 'uploads/images/20200430/4e39d4a6111da9134abc83c95a58ad13.png', '', '', 'image/png', 'png', '35773', 'c5c735efd96b178cec1852fbe27c2b85', '2ad4438c8cfacae1991a2886147661dbc808a451', 'local', '0', '1588215341', '1588215341', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('221', '1', 'c4.png', 'admin', 'uploads/images/20200430/e2bb019ecc61731ebfe876dbd8146ab2.png', '', '', 'image/png', 'png', '372277', 'cceb688e58577defeb532314d81915e3', 'f9ae3468e361c2d90ae34910fe33000ffa8559e1', 'local', '0', '1588215364', '1588215364', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('222', '1', 'c5.png', 'admin', 'uploads/images/20200430/99fab8dca1710273213e3a5c80355403.png', '', '', 'image/png', 'png', '43904', '137796dc8eccb69793bd61ce04d3514e', 'b303b14d5f759e71168b8fbcb9c5092431e4baaa', 'local', '0', '1588215381', '1588215381', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('223', '1', 'c6.png', 'admin', 'uploads/images/20200430/ddceb359ebc6e15eb2d2356c53856359.png', '', '', 'image/png', 'png', '370669', '5faff52c64ef7a97c5a3fe74e1dac3e0', '2dfc9c54fe76246a5e85dbd7b655151a8682f833', 'local', '0', '1588215396', '1588215396', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('224', '1', 'c7.png', 'admin', 'uploads/images/20200430/46b218e09dfaf585ab3b317a506f485b.png', '', '', 'image/png', 'png', '34972', '40ec5cef13b8e29b1b44baf8a9f2d0cb', 'c5921871aa5f5aaee1227ec83c259165ffa488cc', 'local', '0', '1588215411', '1588215411', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('225', '1', 'c8.png', 'admin', 'uploads/images/20200430/c4159bbb96fb38b981266255f83e7f04.png', '', '', 'image/png', 'png', '447477', '470f044b400522b123026f1324162f8a', '1b6a516ba3aba9a0a89b8ec7439354caf39f145d', 'local', '0', '1588215427', '1588215427', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('226', '1', 'g1.jpg', 'admin', 'uploads/images/20200430/de9f8147fa0c8d54d22f9c9df30a800e.jpg', '', '', 'image/jpeg', 'jpg', '48694', 'f8208e9b16221a6b341576a1401060a7', '8485a730cc0239e409531e3aad382cc42d1ad9b8', 'local', '0', '1588215481', '1588215481', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('227', '1', 'g2.jpg', 'admin', 'uploads/images/20200430/947b6db9f37b550d45f2a42684ecc6b5.jpg', '', '', 'image/jpeg', 'jpg', '46446', '3467a62c4cbe9682860f55f3a91d78f8', 'c7ee0e1517bb8a10d5494096a526889ac2b22e39', 'local', '0', '1588215500', '1588215500', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('228', '1', 'g3.jpg', 'admin', 'uploads/images/20200430/19c90de4939673acb481b6712ada9e20.jpg', '', '', 'image/jpeg', 'jpg', '50868', '3a4bcc1638def499da886cccfca8ad00', '357ef130242b54f6568dfb4be80d3e5941bd4ee3', 'local', '0', '1588215516', '1588215516', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('229', '1', 'g4.jpg', 'admin', 'uploads/images/20200430/2a7ab6a28b62696521369d6c671012f2.jpg', '', '', 'image/jpeg', 'jpg', '40007', 'd8413350cdb0c63c920cb7f7a5800929', 'e86286326d8cd8c8bca73c1c5aac75ff15f35343', 'local', '0', '1588215531', '1588215531', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('230', '1', 'g5.jpg', 'admin', 'uploads/images/20200430/56b04110ad5407e4efccbc9bbac569f5.jpg', '', '', 'image/jpeg', 'jpg', '41171', 'dd0f86da61db00b31a62985a28bb017e', 'c3fce472a1e3b7fb4df01bdcd7c152206b559960', 'local', '0', '1588215545', '1588215545', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('231', '1', 'g6.jpg', 'admin', 'uploads/images/20200430/fe006830c3264f6c0ea2fcd646651f14.jpg', '', '', 'image/jpeg', 'jpg', '53301', '6c0321bf01c5f688f0a8d464f8e35b39', 'fcc107aa14ed39654a02db78129b5da9bd20edd9', 'local', '0', '1588215560', '1588215560', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('232', '1', 'g7.jpg', 'admin', 'uploads/images/20200430/9b9021b1c1989ecf30718cab6b82e448.jpg', '', '', 'image/jpeg', 'jpg', '49672', 'e0781559adb8027accba4de7d6bc312e', '650078956a5117fec7f1bfd1840a210ee281c169', 'local', '0', '1588215574', '1588215574', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('233', '1', 'g8.jpg', 'admin', 'uploads/images/20200430/f9031259fe7611b554db9cf12477432b.jpg', '', '', 'image/jpeg', 'jpg', '53531', '953c11697d2e4d65fbcfb9d2d8d481e9', 'f0ad5fd4bc737631a7e21d8ee3ecc302c87b1c9a', 'local', '0', '1588215589', '1588215589', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('234', '1', 'g9.jpg', 'admin', 'uploads/images/20200430/157abf728eb7e623484a5ba79ee81811.jpg', '', '', 'image/jpeg', 'jpg', '57529', 'ebff34bb33443902cbc234b5932c18eb', 'e0249b4ab137214874c788553a6b559050edd442', 'local', '0', '1588215603', '1588215603', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('235', '1', '1.jpg', 'admin', 'uploads/images/20200430/016d77a81515f08949c529e66c681bac.jpg', '', '', 'image/jpeg', 'jpg', '26585', 'fa94115f94cad04a219a37ed8bf2b0e8', '701aef4f6c6ed52167a778c8dcee43e6e171b683', 'local', '0', '1588215633', '1588215633', '100', '1', '910', '238');
INSERT INTO `dp_admin_attachment` VALUES ('236', '1', '2.jpg', 'admin', 'uploads/images/20200430/7a79227e937e45e9a1bf84e70ab1d923.jpg', '', '', 'image/jpeg', 'jpg', '74444', '16aa960407482c467f5e217a7193286a', '6f94595bd2f6edba103147b84fbc8b7fb7f37ce9', 'local', '0', '1588215650', '1588215650', '100', '1', '910', '238');
INSERT INTO `dp_admin_attachment` VALUES ('237', '1', '3.jpg', 'admin', 'uploads/images/20200430/290500e8600c43bb5d2ca4a13bff98c8.jpg', '', '', 'image/jpeg', 'jpg', '82540', '643b8a4c1dd2d11347721131e28b7093', 'a40e8113d0db713950a7bcb8de4e0927dc8dbf5f', 'local', '0', '1588215665', '1588215665', '100', '1', '910', '238');
INSERT INTO `dp_admin_attachment` VALUES ('238', '1', '4.jpg', 'admin', 'uploads/images/20200430/5bdaf10d9529f0f827c806383266fa5b.jpg', '', '', 'image/jpeg', 'jpg', '70878', 'c56c5ce8de9f6101fd4b71a234b6722c', '887d460a5057e092ed90f5e084911ef782857d7b', 'local', '0', '1588215682', '1588215682', '100', '1', '910', '238');
INSERT INTO `dp_admin_attachment` VALUES ('239', '1', '5.jpg', 'admin', 'uploads/images/20200430/1deaa730add833108aaae4e51930148e.jpg', '', '', 'image/jpeg', 'jpg', '45836', '34c3aa23176060fdc28119dcec2b9aac', '600d9d39a6a2be4838157c7b2010066239e17b0a', 'local', '0', '1588215697', '1588215697', '100', '1', '910', '238');
INSERT INTO `dp_admin_attachment` VALUES ('240', '1', '6.jpg', 'admin', 'uploads/images/20200430/4d3487a6af75670781f5116fa3677404.jpg', '', '', 'image/jpeg', 'jpg', '36348', '4767bd34b488b8b6be662ae2615813c3', '665c4d34022e58fa98858c5efba0119e01fab0a6', 'local', '0', '1588215714', '1588215714', '100', '1', '910', '184');
INSERT INTO `dp_admin_attachment` VALUES ('241', '1', '7.jpg', 'admin', 'uploads/images/20200430/078e25efaaf8058ae59e50d62356f41c.jpg', '', '', 'image/jpeg', 'jpg', '34066', '72bedd4459b533b97a22a2c9e9316a22', 'd6bcb4d4e8beca8972dfda07df0d916acc91271e', 'local', '0', '1588215732', '1588215732', '100', '1', '910', '183');
INSERT INTO `dp_admin_attachment` VALUES ('242', '1', '8.jpg', 'admin', 'uploads/images/20200430/ab0b802173fb7d8e679c4b2e6ab7282b.jpg', '', '', 'image/jpeg', 'jpg', '44383', '4a5006b26a6bd83fc2ac5d9ab3b8cbed', 'de67a161c33c09d44777726a63ed73b37b481f16', 'local', '0', '1588215750', '1588215750', '100', '1', '910', '184');
INSERT INTO `dp_admin_attachment` VALUES ('243', '1', '9.jpg', 'admin', 'uploads/images/20200430/b03b1e432e3f5b159b232b2494294491.jpg', '', '', 'image/jpeg', 'jpg', '46353', 'b71f4892f088d31ed50cd37555e9f08c', '68e338d1f846c78262ecc6eb9faff78d54ab5a26', 'local', '0', '1588215767', '1588215767', '100', '1', '910', '183');
INSERT INTO `dp_admin_attachment` VALUES ('244', '1', '10.jpg', 'admin', 'uploads/images/20200430/0bfbe723bd8c8821bc61dd2e6b792132.jpg', '', '', 'image/jpeg', 'jpg', '41111', '9fd83d748fc735e4ff33473d4eaa9f39', '030c6ccf554c56dcfe96b7b5b84939b41c4708f6', 'local', '0', '1588215797', '1588215797', '100', '1', '910', '184');
INSERT INTO `dp_admin_attachment` VALUES ('245', '1', 'c1.png', 'admin', 'uploads/images/20200430/4c47010ea93023233950da471e79793f.png', '', '', 'image/png', 'png', '40879', '5e82d0484ce1f1144de35fab35ebb9df', 'cca2fac0245020b001379d80a38ad54e4bab8608', 'local', '0', '1588215856', '1588215856', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('246', '1', 'c2.png', 'admin', 'uploads/images/20200430/1684ece9c750ea9235742ea2e49c6c4e.png', '', '', 'image/png', 'png', '282931', '14dc9fc7993d6890688056b9b11d470f', '63353e2ed50aff4764f546499be0a6887136ec84', 'local', '0', '1588215877', '1588215877', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('247', '1', 'c3.png', 'admin', 'uploads/images/20200430/0146543becf76d7d89df43f476059907.png', '', '', 'image/png', 'png', '40143', 'dd7000a65279c3fd08f9b52fd90fc11e', '8a5da25575f17fbeb147c32941e0ac07ce83b642', 'local', '0', '1588215917', '1588215917', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('248', '1', 'c4.png', 'admin', 'uploads/images/20200430/852e5c042c8cb0f56bea770f564e3550.png', '', '', 'image/png', 'png', '212385', '6a60b0569842ac55ecc431d0f6f65d56', '9211c9ec46b15c970b32bcfaebac5c5ed378992c', 'local', '0', '1588215938', '1588215938', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('249', '1', 'c5.png', 'admin', 'uploads/images/20200430/611e5b959dd431608e44cff2b212cc87.png', '', '', 'image/png', 'png', '37335', 'afb817c6463352561254f70e2409df5e', 'cb500c9efd3faf66a4a4b4aacc07357952ee0c84', 'local', '0', '1588215959', '1588215959', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('250', '1', 'c7.png', 'admin', 'uploads/images/20200430/7fe0b0031cdb0ed3c913609b1870cdfd.png', '', '', 'image/png', 'png', '39076', 'cc5cb45d423971d828e307b6b5e0d963', 'f78982427a74d97d7447105d33d622c442b79c94', 'local', '0', '1588215983', '1588215983', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('251', '1', 'c6.png', 'admin', 'uploads/images/20200430/2dd0549a7492b4a5238651a84db61c0c.png', '', '', 'image/png', 'png', '164075', 'f0b58636c24cf839adc77e3a03d8a7e7', 'dfff7b9683f21437a650d83cf21c234dec56a644', 'local', '0', '1588216012', '1588216012', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('252', '1', 'c8.png', 'admin', 'uploads/images/20200430/6976fb6499f433230decb77a798de4a4.png', '', '', 'image/png', 'png', '309611', '6b2263c5dcd1c557532f4096c2721846', 'bdb5673d431c639c0d174c711d0c697027f9f270', 'local', '0', '1588216049', '1588216049', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('253', '1', 'g1.jpg', 'admin', 'uploads/images/20200430/7bbe3b27a49faf154d4fd578da4618cb.jpg', '', '', 'image/jpeg', 'jpg', '30466', 'f898edabecc862c9c90507e3128d77ea', '31e5d45b5a5b201c17e2b9396f1b1dbf321e726f', 'local', '0', '1588216098', '1588216098', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('254', '1', 'g2.jpg', 'admin', 'uploads/images/20200430/88b9fc14d64ef2f3012674a56fed385c.jpg', '', '', 'image/jpeg', 'jpg', '28195', '6c47ef9e38a1cec9044bf6e762cd1d1c', 'ce42a9723075a9556503f1cbf03c30fcbf25061c', 'local', '0', '1588216113', '1588216113', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('255', '1', 'g3.jpg', 'admin', 'uploads/images/20200430/a4dbb9a5ba9b5f22dda292d603e3aedf.jpg', '', '', 'image/jpeg', 'jpg', '28600', '55ae91146c967bc1451ba6433169d85e', '70755f4e9a7cfebeb5cbb2069997b0973ba5d7c9', 'local', '0', '1588216126', '1588216126', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('256', '1', 'g4.jpg', 'admin', 'uploads/images/20200430/dce216d565a72a608e1c7b118f18c52b.jpg', '', '', 'image/jpeg', 'jpg', '28838', 'e8c14625f9126639071ec7097971d552', '0641c9b5c558e8945428fa21deef7acb312a10f0', 'local', '0', '1588216139', '1588216139', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('257', '1', 'g5.jpg', 'admin', 'uploads/images/20200430/906f2278714698777a6845e94ddaaef2.jpg', '', '', 'image/jpeg', 'jpg', '34651', '6551c172866b3ba1410f2d5e0faa717d', 'cc73537315ee3558cc10dabf1267d8822b6cb83a', 'local', '0', '1588216154', '1588216154', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('258', '1', '1.jpg', 'admin', 'uploads/images/20200430/bde54ff834cff3ff3dc22f6f37c637d5.jpg', '', '', 'image/jpeg', 'jpg', '27687', '8297684526bed0aa90751b852e112e0a', '3eed32b96b29d7f5bd744dedab925b7cc3d2cd58', 'local', '0', '1588216210', '1588216210', '100', '1', '910', '242');
INSERT INTO `dp_admin_attachment` VALUES ('259', '1', '2.jpg', 'admin', 'uploads/images/20200430/70fee485fbde8c4dbfd68949046f6fb0.jpg', '', '', 'image/jpeg', 'jpg', '77977', '871d15f557cedc00721dffa811f48275', '51bff8de97489d6a468dd4f06e9691c1436cb1de', 'local', '0', '1588216228', '1588216228', '100', '1', '910', '242');
INSERT INTO `dp_admin_attachment` VALUES ('260', '1', '3.jpg', 'admin', 'uploads/images/20200430/7d54ec6ea1d72951d3ee038f4b0da507.jpg', '', '', 'image/jpeg', 'jpg', '78825', '61fa65334c50ec03f38d55650a6b50dc', '11aa36703d17b8f7d11dfcd9914ed91fd5e0e3de', 'local', '0', '1588216241', '1588216241', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('261', '1', '4.jpg', 'admin', 'uploads/images/20200430/73a85d1eee9be88cb97a554f9c6d0d02.jpg', '', '', 'image/jpeg', 'jpg', '77021', '1308eaecf37ea11b1499bbe90e4ead1e', 'c581b0370077561e06e6582b543101ef1ff388ee', 'local', '0', '1588216255', '1588216255', '100', '1', '910', '242');
INSERT INTO `dp_admin_attachment` VALUES ('262', '1', '5.jpg', 'admin', 'uploads/images/20200430/69967ff3b3d932097afea2b9647afa81.jpg', '', '', 'image/jpeg', 'jpg', '45763', 'a8bde80c196aac388bee076aae94f584', '467949d795a647ac5798093565ad8bde9905fe33', 'local', '0', '1588216272', '1588216272', '100', '1', '910', '242');
INSERT INTO `dp_admin_attachment` VALUES ('263', '1', '6.jpg', 'admin', 'uploads/images/20200430/8066b4755f851bd5dff66b4f2f34493f.jpg', '', '', 'image/jpeg', 'jpg', '42686', 'a47e2a7b2508e6be92098a867a57baad', '20e2d9b2013e3f934ebb0993da68841956f04da4', 'local', '0', '1588216288', '1588216288', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('264', '1', '7.jpg', 'admin', 'uploads/images/20200430/6c4f5a197b74f7879ba2f9146b5fbc14.jpg', '', '', 'image/jpeg', 'jpg', '40547', '10a3b07e58cc92c9b4e0198721283f77', 'c64bcedec1cfb34f68f50f58ac168ffd6ab85d7b', 'local', '0', '1588216303', '1588216303', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('265', '1', '8.jpg', 'admin', 'uploads/images/20200430/714d77d09a851b0da5c10f9ea22c0be9.jpg', '', '', 'image/jpeg', 'jpg', '45662', 'e45cf1604937ddcc4644900bfb6e5054', '6bcc6ebcd21bd9287cd0390cc769178ba682754a', 'local', '0', '1588216317', '1588216317', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('266', '1', '9.jpg', 'admin', 'uploads/images/20200430/28cfb0f6a7e3fab029def06d0b773ff1.jpg', '', '', 'image/jpeg', 'jpg', '55049', 'b0abbaf3b795d46014bb20b0191369b7', 'eba45addb49d15471c8df1b67acf4285002e0303', 'local', '0', '1588216333', '1588216333', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('267', '1', '10.jpg', 'admin', 'uploads/images/20200430/f9786622e19aa4485d9d4f393e762612.jpg', '', '', 'image/jpeg', 'jpg', '31801', '88917dceb80c8161293f6ff25086f863', 'eb8a34369f5fa5fa00bdffcbf3f751b8dcfde7c4', 'local', '0', '1588216346', '1588216346', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('268', '1', 'c1.png', 'admin', 'uploads/images/20200430/9ac51974145af25b3432d8c50924b1ea.png', '', '', 'image/png', 'png', '41452', '1cde29cd84fb616f1adff9c107b46257', '701e15af19fa3f64bfa31c7d8ed78d1c080a4950', 'local', '0', '1588216395', '1588216395', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('269', '1', 'c2.png', 'admin', 'uploads/images/20200430/3d071ed4ccd51a4747bb7cf0ac4c4541.png', '', '', 'image/png', 'png', '249952', 'ac9961595f98be842510009f0eb3647f', '3c64dd8051c07b54e4981f2a6a9d489ed64df0df', 'local', '0', '1588216408', '1588216408', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('270', '1', 'c3.png', 'admin', 'uploads/images/20200430/795a3f95f0707dcea59e31b32e8532e5.png', '', '', 'image/png', 'png', '34124', 'a4a683dc519cc14fa5d31037cfb676a1', '14fb07609af0498f4ec7fc6698122796217321e6', 'local', '0', '1588216421', '1588216421', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('271', '1', 'c4.png', 'admin', 'uploads/images/20200430/1d9300dc79a5c215cbba801f2e281fd1.png', '', '', 'image/png', 'png', '260075', 'a5938c3fa3e289b70cf065c15bb49673', '4fd30e05a2069ba155d4e3768f4e93595c987d48', 'local', '0', '1588216434', '1588216434', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('272', '1', 'c5.png', 'admin', 'uploads/images/20200430/4f268eb6514778ff68422dc600cfbe73.png', '', '', 'image/png', 'png', '38395', '42d0aa83ee124bfb0d842a9476090402', '892e7973afd1122970f629b0cb27e7851d1d076b', 'local', '0', '1588216447', '1588216447', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('273', '1', 'c6.png', 'admin', 'uploads/images/20200430/44f863c5bb52d77ef4f3f6458091eaaa.png', '', '', 'image/png', 'png', '333913', '290f639c606bbaf34d08d716bd57ab94', '908428addced3a3255bd49c800e4cb01073db3c4', 'local', '0', '1588216462', '1588216462', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('274', '1', 'c7.png', 'admin', 'uploads/images/20200430/7dc704069d2ac9a917a8f5ec3ef8489f.png', '', '', 'image/png', 'png', '42701', '9bca12226ce406f96f5fc7441e13af1b', 'aa1b5baf3888a4ef67300c819405b3bfcc66e0aa', 'local', '0', '1588216478', '1588216478', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('275', '1', 'c8.png', 'admin', 'uploads/images/20200430/8d570e6f79d3df8f65e993bfb433bc2c.png', '', '', 'image/png', 'png', '261792', '23f2e5af6e680f0499a3f32560c76c60', 'f4b5627cef5b68933c83d53217ccd3b67487465a', 'local', '0', '1588216493', '1588216493', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('276', '1', 'g1.jpg', 'admin', 'uploads/images/20200430/adfb1e86ddf116a78b7a7d7a7cad3857.jpg', '', '', 'image/jpeg', 'jpg', '45612', '29b9d87a5b909a8bde2d05fd7f8ed2e6', '9deb32273dc55e8cb507b7f642892cccac6c5c52', 'local', '0', '1588216529', '1588216529', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('277', '1', 'g2.jpg', 'admin', 'uploads/images/20200430/029b2c0895bfa794355d8b897c70ad79.jpg', '', '', 'image/jpeg', 'jpg', '46447', 'eceebbf76fbf16caf5e5b495c7925cc4', '4f60ffee2849950e1fcbcefd503d124977a80779', 'local', '0', '1588216544', '1588216544', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('278', '1', 'g3.jpg', 'admin', 'uploads/images/20200430/54e0a3b91003897478ec8decb9221006.jpg', '', '', 'image/jpeg', 'jpg', '38909', '851f2c5d62dd45fa102d9d0fcd946916', '7740878005fed9208cfbd95516f86d0241f4adc0', 'local', '0', '1588216560', '1588216560', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('279', '1', 'g4.jpg', 'admin', 'uploads/images/20200430/f93de39f401093854b54b774a4e7ae21.jpg', '', '', 'image/jpeg', 'jpg', '49505', '36840421bcada92ee287be5ad1b7ed53', '1b95952b23a464685be8f30b320a273f2bac5861', 'local', '0', '1588216573', '1588216573', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('280', '1', 'g5.jpg', 'admin', 'uploads/images/20200430/9c1c549f180e68184600fdfd50ccf1b2.jpg', '', '', 'image/jpeg', 'jpg', '41831', '237503120601d18d07c2d4be0645c9c5', '3be20b1642fa23c162d461d18a54ef47d2864eda', 'local', '0', '1588216586', '1588216586', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('281', '1', '1.jpg', 'admin', 'uploads/images/20200430/549d484f7e4e81a683dbe1894539072f.jpg', '', '', 'image/jpeg', 'jpg', '26329', 'b26f4ff4c65723603db56e7b8f469601', 'f2aef6525e7cc31a8d28458172329053e97c7f8f', 'local', '0', '1588216677', '1588216677', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('282', '1', '2.jpg', 'admin', 'uploads/images/20200430/1744bf13e833315cfce3522fe4ee22f1.jpg', '', '', 'image/jpeg', 'jpg', '53467', 'c7792033d02e7825c53d52009fed7819', 'ae46c3cfe0cf4a6d3e62bde94ef1c5f553f603fb', 'local', '0', '1588216701', '1588216701', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('283', '1', '3.jpg', 'admin', 'uploads/images/20200430/75d0b8632bb01fa44dfec3d18e350b32.jpg', '', '', 'image/jpeg', 'jpg', '68089', 'f68a982278b47a6c4ddb9d1a23936516', '06e10e07c25373f2948d307ed6252c9acee209c0', 'local', '0', '1588216715', '1588216715', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('284', '1', '4.jpg', 'admin', 'uploads/images/20200430/c2cd42cf349ba5f048faf9c5e09790ea.jpg', '', '', 'image/jpeg', 'jpg', '79036', '35536f3627d4cabce41d7f3cbf4fcda1', '6cc1850abca4bb045b5648a8c689e00aed7e7cde', 'local', '0', '1588216727', '1588216727', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('285', '1', '5.jpg', 'admin', 'uploads/images/20200430/572a09c2279a61a185ae4517d9686d81.jpg', '', '', 'image/jpeg', 'jpg', '47561', '06fcaf50c9a438d6724ec3c740bfd560', '83cd75fdf9c447db8647c87e441b528f2eba4134', 'local', '0', '1588216740', '1588216740', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('286', '1', '6.jpg', 'admin', 'uploads/images/20200430/4b39237465a3a1c9fd528b29477aee53.jpg', '', '', 'image/jpeg', 'jpg', '37878', '9bfeda0df0a99243943d48c4d63dc117', '61a5b68e7e502796c54a3c6ac1da21f33121cd52', 'local', '0', '1588216758', '1588216758', '100', '1', '910', '181');
INSERT INTO `dp_admin_attachment` VALUES ('287', '1', '7.jpg', 'admin', 'uploads/images/20200430/57cce3a2da13fdff54157d403cac909d.jpg', '', '', 'image/jpeg', 'jpg', '34436', 'd16e17398c4b0e047a5b22c59aa94655', 'e7c9cbb02bf879f91c20b7da9ebd99cc864af8d1', 'local', '0', '1588216780', '1588216780', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('288', '1', '8.jpg', 'admin', 'uploads/images/20200430/c30c26a8a7b89fdbaf6b89cfbc08e16f.jpg', '', '', 'image/jpeg', 'jpg', '32221', '6f6c8acb3b000dd821d1af32ef74e9ad', '44c3d0b2f03c62372072cef34ecc2d39b1e6f25f', 'local', '0', '1588216797', '1588216797', '100', '1', '910', '181');
INSERT INTO `dp_admin_attachment` VALUES ('289', '1', '9.jpg', 'admin', 'uploads/images/20200430/2a6d314979a4c375104290378fefea01.jpg', '', '', 'image/jpeg', 'jpg', '40810', 'da93c89664b21b68198e1c506ccc5354', 'e5726306f6410c493830d4f008963b663f815e96', 'local', '0', '1588216811', '1588216811', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('290', '1', '10.jpg', 'admin', 'uploads/images/20200430/0db2d17b5fd36bb627810c7841a51903.jpg', '', '', 'image/jpeg', 'jpg', '32022', '484ac8ad0446d6494f1df2f517668c1e', 'fb416b41ffb50bddbfe89ff228b033ea9045a21a', 'local', '0', '1588216838', '1588216838', '100', '1', '910', '181');
INSERT INTO `dp_admin_attachment` VALUES ('291', '1', 'g1.jpg', 'admin', 'uploads/images/20200430/f72e031c28543420453ccdd6ee2f2373.jpg', '', '', 'image/jpeg', 'jpg', '31973', 'cdf0b95ebe122f7ad777d6893c538576', '6b8916d68f082fc055b2488af3dd642bf5990b40', 'local', '0', '1588216926', '1588216926', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('292', '1', 'g2.jpg', 'admin', 'uploads/images/20200430/9586f8a9ff4d1d6f7e6c5a133fcebfd6.jpg', '', '', 'image/jpeg', 'jpg', '34736', '8530d44dff85da383d1bb30c92087fba', '51dbcdc3fd7db5a5807e71c6ff78e9b2fb966ac0', 'local', '0', '1588216941', '1588216941', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('293', '1', 'g3.jpg', 'admin', 'uploads/images/20200430/d5d8925d7dd071711d9a4e905b08c3db.jpg', '', '', 'image/jpeg', 'jpg', '34849', '01869bc7989a70bdf0845741f6c3f6a1', 'aafc75b6c9aad8d523b0fcf7d8698b35fdf72a33', 'local', '0', '1588216954', '1588216954', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('294', '1', 'g4.jpg', 'admin', 'uploads/images/20200430/242552f206aa56ea5ff7ad44513db8b0.jpg', '', '', 'image/jpeg', 'jpg', '30687', 'c94f021f1448353221a1e087a6597a07', '7ee9322e308742138ea43406c4b4f750540ef627', 'local', '0', '1588216968', '1588216968', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('295', '1', 'g5.jpg', 'admin', 'uploads/images/20200430/5a06033a2e68608f4a1d29bbbd2c2ae0.jpg', '', '', 'image/jpeg', 'jpg', '34573', 'e7aee4a050f147684efaa67f077fc866', '9a17f7f8104f60c347f6d68e23c5ec6a5e9d9095', 'local', '0', '1588216983', '1588216983', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('296', '1', 'g6.jpg', 'admin', 'uploads/images/20200430/7c3a0e1d0de5720a5d344351d37f92b9.jpg', '', '', 'image/jpeg', 'jpg', '29459', '373e4eda4191b08ad673f486dac744fc', 'cbefb2fa705e6abdb417b283684ef607ad4540be', 'local', '0', '1588216996', '1588216996', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('297', '1', '1.jpg', 'admin', 'uploads/images/20200430/b2a88f0da931650c6d1f3ec55e5a058e.jpg', '', '', 'image/jpeg', 'jpg', '31004', 'faf644d9060ea6d5eea8db5f016dead3', '1678b4be44e6a3a4f0190a394a2cea9a753cab63', 'local', '0', '1588217122', '1588217122', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('298', '1', '2.jpg', 'admin', 'uploads/images/20200430/ab41914ce5381d2011bccf9f48148212.jpg', '', '', 'image/jpeg', 'jpg', '53357', 'e023f0967af83c42901e84adb9d8b669', 'd95ccdc7e6f4aeb48edb0bb5046b6ec70af94f1e', 'local', '0', '1588217139', '1588217139', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('299', '1', '3.jpg', 'admin', 'uploads/images/20200430/5c17befd2f37eebdcaa09bde07e5ff46.jpg', '', '', 'image/jpeg', 'jpg', '68059', '5098b4be9d0cfd8092b445cc3414ef23', '1a1cb785f699537ac709df24eb40070bf200cbc9', 'local', '0', '1588217153', '1588217153', '100', '1', '910', '239');
INSERT INTO `dp_admin_attachment` VALUES ('300', '1', '4.jpg', 'admin', 'uploads/images/20200430/ee3909525a91e8609ab5114f5222ab81.jpg', '', '', 'image/jpeg', 'jpg', '76952', '414209c08a117c7ddd96fbaad530979f', 'a402e854c348f29be777493bc99c5ad52b6b7b9b', 'local', '0', '1588217172', '1588217172', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('301', '1', '5.jpg', 'admin', 'uploads/images/20200430/7c5951b1a6b4144d3b08569c1dc97ec9.jpg', '', '', 'image/jpeg', 'jpg', '50037', '0fe85278d32623d29cf756707425b765', 'a3e684eb56e777f5a53c99a4c3834a18e6cf77b6', 'local', '0', '1588217187', '1588217187', '100', '1', '910', '240');
INSERT INTO `dp_admin_attachment` VALUES ('302', '1', '6.jpg', 'admin', 'uploads/images/20200430/7eeeac0cac213070c9ee9e16eafc0f1b.jpg', '', '', 'image/jpeg', 'jpg', '31251', '3f6b391a5354efacd670f7ce371716fb', '5030bc6a5637202c82f9ad8a38d1b524de60cded', 'local', '0', '1588217204', '1588217204', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('303', '1', '7.jpg', 'admin', 'uploads/images/20200430/1876f362b013067b5235a2b6554f08af.jpg', '', '', 'image/jpeg', 'jpg', '38696', '5966cfdd622c767856d91fc22f19726d', 'ef74d8c4c53ea217b0c2f5e94d62bd3c92219d7c', 'local', '0', '1588217220', '1588217220', '100', '1', '910', '181');
INSERT INTO `dp_admin_attachment` VALUES ('304', '1', '8.jpg', 'admin', 'uploads/images/20200430/adf697de4835a23d6fc0760a200dbb93.jpg', '', '', 'image/jpeg', 'jpg', '39021', '70a13af37370029390c08eee0f31b4b4', '750c6bf4705fb7c54c9f428445b02de79ad64938', 'local', '0', '1588217237', '1588217237', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('305', '1', '9.jpg', 'admin', 'uploads/images/20200430/3201922e69364f506be64b5061fdf58f.jpg', '', '', 'image/jpeg', 'jpg', '37388', '55110ca9032277ba79369f4e9ed0a7c7', 'fb1c8b067a5edcf12ff63d4f9b3d10d66b5402c1', 'local', '0', '1588217251', '1588217251', '100', '1', '910', '181');
INSERT INTO `dp_admin_attachment` VALUES ('306', '1', '10.jpg', 'admin', 'uploads/images/20200430/d20d2358f99dd177d07f6dbf56c1e07d.jpg', '', '', 'image/jpeg', 'jpg', '25262', '02249c3f0372884fcc449b38a548e799', '922fe9eec524089aa554cc7d5fa4b1b37daf955f', 'local', '0', '1588217276', '1588217276', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('307', '1', 'c1.png', 'admin', 'uploads/images/20200430/d57646f171751aac3cbb591a5acda364.png', '', '', 'image/png', 'png', '37096', '6665a1349fa52a43c397680b1306e848', 'e2b27a71c5e1c6947a5889f24d1e75de6a59ec87', 'local', '0', '1588217359', '1588217359', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('308', '1', 'c2.jpg', 'admin', 'uploads/images/20200430/a2a0fb6c48a3ca73cbe6c49d6301618a.jpg', '', '', 'image/jpeg', 'jpg', '58763', 'b143800308f07cbe508116fe547dad59', 'b6a625027d36e10451fac2d4f9d6d8122d1d0d9d', 'local', '0', '1588217375', '1588217375', '100', '1', '455', '589');
INSERT INTO `dp_admin_attachment` VALUES ('309', '1', 'c3.png', 'admin', 'uploads/images/20200430/a66acf7a94e3cd94d938c1a921ae8f14.png', '', '', 'image/png', 'png', '45772', '664fe1829f40c8e38715ce68f982e6df', 'ff7676df31d27f22efed81362565bc32eb30dbc2', 'local', '0', '1588217389', '1588217389', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('310', '1', 'c4.jpg', 'admin', 'uploads/images/20200430/6ad032f6d32a74d048c9f850f1a404a1.jpg', '', '', 'image/jpeg', 'jpg', '65979', 'a53c03ec9f3433b2f2c2835174f7253e', '306356bec2ab60fe8beb6d0c501216ec25ec9d54', 'local', '0', '1588217405', '1588217405', '100', '1', '455', '589');
INSERT INTO `dp_admin_attachment` VALUES ('311', '1', 'c5.png', 'admin', 'uploads/images/20200430/c2ac5f26035b85d62352a7aaf3dadb8b.png', '', '', 'image/png', 'png', '39858', '7e736d517171438d9965947c16391d80', '01574aef14e5bef56c63f507c474795b3e89894f', 'local', '0', '1588217418', '1588217418', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('312', '1', 'c6.jpg', 'admin', 'uploads/images/20200430/e205a281daa99a029c5c7e60d429e2bf.jpg', '', '', 'image/jpeg', 'jpg', '62085', '32bc8e147b4e9184577de30dc6269f6b', '6efcccd422cc0040e149df06eb36b09e1de2d838', 'local', '0', '1588217437', '1588217437', '100', '1', '455', '589');
INSERT INTO `dp_admin_attachment` VALUES ('313', '1', 'c7.png', 'admin', 'uploads/images/20200430/148c42f1f2850786b2258c2669624116.png', '', '', 'image/png', 'png', '37262', '6b17abff1b98e47c3a43319b01a5ffdc', 'd14d6ae6e3398b36f6c0b22f130c19ae30b8c2fa', 'local', '0', '1588217451', '1588217451', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('314', '1', 'c8.jpg', 'admin', 'uploads/images/20200430/6026796d6e8f974ba39de8d34d6dbbd1.jpg', '', '', 'image/jpeg', 'jpg', '69912', 'e5578be9146ded26b05d1706c21e0aa0', '5f4986664bcdd31669102bc1b2c9c3ffec52d79f', 'local', '0', '1588217465', '1588217465', '100', '1', '455', '589');
INSERT INTO `dp_admin_attachment` VALUES ('315', '1', 'g1.jpg', 'admin', 'uploads/images/20200430/24189eba0713161c8aeea5210b9546db.jpg', '', '', 'image/jpeg', 'jpg', '40583', '258313a5a853cf6fafae6150296a4a2b', 'e6647e73b4a14f62af3ce912e4b8b928b3549e56', 'local', '0', '1588217501', '1588217501', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('316', '1', 'g2.jpg', 'admin', 'uploads/images/20200430/97dc07ae4338118a35afbb62d2e0b459.jpg', '', '', 'image/jpeg', 'jpg', '37518', '829d1ac39b12213b9b3ff1b94f18a120', '5f57836a662b5fa1c6d32e2ff729071717f2a1e7', 'local', '0', '1588217516', '1588217516', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('317', '1', 'g3.jpg', 'admin', 'uploads/images/20200430/10b683150f5ac25568d2679a61f62b48.jpg', '', '', 'image/jpeg', 'jpg', '42111', 'af92071c3911f4c9e7ed76cb292ac763', '1c9532923f6bb6aef9bf3feef8550ba90f0887a6', 'local', '0', '1588217530', '1588217530', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('318', '1', 'g4.jpg', 'admin', 'uploads/images/20200430/571e3ebfd6070b052edb168a7f752aff.jpg', '', '', 'image/jpeg', 'jpg', '45337', '3ef3599722a39aaa67907d1521ca1414', 'de8f50b5dc0096c89fc5130c8f2c1b3193e2d976', 'local', '0', '1588217542', '1588217542', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('319', '1', '1.jpg', 'admin', 'uploads/images/20200430/ce50159e6cdf0c12f923ba382f3d53b5.jpg', '', '', 'image/jpeg', 'jpg', '31382', 'a6eccffa042a19b2ced1bcf26d323af4', 'fcfd087545ca2d4b0769fab1b5ca624db3933908', 'local', '0', '1588217623', '1588217623', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('320', '1', '2.jpg', 'admin', 'uploads/images/20200430/15be4edf66ff28c3b32b66c8cdd5f9ac.jpg', '', '', 'image/jpeg', 'jpg', '60348', 'b4e181c76c39bbfd44d7271847f56adb', '45dd59446c01ccabee7bfcf1fbbb7309344e6c89', 'local', '0', '1588217640', '1588217640', '100', '1', '910', '242');
INSERT INTO `dp_admin_attachment` VALUES ('321', '1', '3.jpg', 'admin', 'uploads/images/20200430/8ebcad6b3308f4b95077c36f8715d604.jpg', '', '', 'image/jpeg', 'jpg', '76891', '8cdf35fcfcf67c3a4f7ebd6fda31c304', 'faa41574b25f2bea0db65c470bdc4ef45d711967', 'local', '0', '1588217654', '1588217654', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('322', '1', '4.jpg', 'admin', 'uploads/images/20200430/c1524cf03dcefb6814c4736d9e6db5fc.jpg', '', '', 'image/jpeg', 'jpg', '74139', '2941738dcd297755e74a13a30469aea4', 'c373f55ba72063bebbea9bec16d5d5a1930633b4', 'local', '0', '1588217668', '1588217668', '100', '1', '910', '242');
INSERT INTO `dp_admin_attachment` VALUES ('323', '1', '5.jpg', 'admin', 'uploads/images/20200430/5ce3f687af8cc2dcd875faa509f57964.jpg', '', '', 'image/jpeg', 'jpg', '45435', 'ffd7e2ab549579d57cff63380250b4db', '27ab21e4b0b38b86c76459225b91cc68320ef3f9', 'local', '0', '1588217683', '1588217683', '100', '1', '910', '241');
INSERT INTO `dp_admin_attachment` VALUES ('324', '1', '6.jpg', 'admin', 'uploads/images/20200430/00df61078f71a6d5fd10bf2670dfb527.jpg', '', '', 'image/jpeg', 'jpg', '44681', '66bae5795b181449bb206c62a6b03d3b', '069884cd53d81f75da0610a859028392726019e7', 'local', '0', '1588217699', '1588217699', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('325', '1', '7.jpg', 'admin', 'uploads/images/20200430/719d7e7c01d3456089552dce4605acbc.jpg', '', '', 'image/jpeg', 'jpg', '46478', 'df2b869bf226791ad6ebe264cd26f10c', '325fe6dce05f4b0a5545a651ec2658cadefc0637', 'local', '0', '1588217810', '1588217810', '100', '1', '910', '179');
INSERT INTO `dp_admin_attachment` VALUES ('326', '1', '8.jpg', 'admin', 'uploads/images/20200430/ddc98df21f9903c82d84830809abf1c8.jpg', '', '', 'image/jpeg', 'jpg', '38415', '33ba4e703141d85263b7ed85e04d0567', 'f1cb3aea798412a6ee20640f45ff7a940d0a3a4e', 'local', '0', '1588217829', '1588217829', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('327', '1', '9.jpg', 'admin', 'uploads/images/20200430/59591aada87512a52c664062809f86b0.jpg', '', '', 'image/jpeg', 'jpg', '47000', '96b964546a9205f2d4383272622f5a88', '31e7479eb25cfab2c737db3aac7b938420a0340c', 'local', '0', '1588217845', '1588217845', '100', '1', '910', '179');
INSERT INTO `dp_admin_attachment` VALUES ('328', '1', '10.jpg', 'admin', 'uploads/images/20200430/670beab594cfa264dee50ec084920ee4.jpg', '', '', 'image/jpeg', 'jpg', '23092', '40518744cc8545bb0f6292153d18d353', '645751c865e132ed49ee022407d964d576dbc837', 'local', '0', '1588217861', '1588217861', '100', '1', '910', '180');
INSERT INTO `dp_admin_attachment` VALUES ('329', '1', 'c1.png', 'admin', 'uploads/images/20200430/f4d0f1d27b6f2ae08d36bb62b4cd43e2.png', '', '', 'image/png', 'png', '39064', 'caeda3d528fc5b683ccbebf30266de2e', '09ace94a322012bef9f73262150f27e686016218', 'local', '0', '1588217902', '1588217902', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('330', '1', 'c2.jpg', 'admin', 'uploads/images/20200430/54c352190eeee462ada47fae94dc0f1c.jpg', '', '', 'image/jpeg', 'jpg', '65583', '9041a4c84a863196134dd79d68d72fa0', '6f4ffd4cdf12ad393a82c20b3a5ed86f3cfb6b5e', 'local', '0', '1588217916', '1588217916', '100', '1', '455', '589');
INSERT INTO `dp_admin_attachment` VALUES ('331', '1', 'c3.png', 'admin', 'uploads/images/20200430/6c3c211ce51b9dac695e1e3556d99b8d.png', '', '', 'image/png', 'png', '39835', 'd439eb6312d0fc700694c3455f7eeb3d', '637c4216e0debfebe1dc530658a5b1083b852e65', 'local', '0', '1588217930', '1588217930', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('332', '1', 'c4.jpg', 'admin', 'uploads/images/20200430/92dce789f57f35a15d7adfd427484ad0.jpg', '', '', 'image/jpeg', 'jpg', '66072', 'a5ec8976db9fc1bd39e2b087e5b389eb', 'a8248814e31274d8b11e5efae5196d93530f7e2d', 'local', '0', '1588217944', '1588217944', '100', '1', '455', '589');
INSERT INTO `dp_admin_attachment` VALUES ('333', '1', 'c5.png', 'admin', 'uploads/images/20200430/242a756529b0966f505996e2ab974882.png', '', '', 'image/png', 'png', '38616', '7509c66681ada316f07635bf1fe68fc3', 'ae731c2052df540b61d2a65a0338d03cdea07ffe', 'local', '0', '1588217960', '1588217960', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('334', '1', 'c6.jpg', 'admin', 'uploads/images/20200430/da5ca38ced4df8123ef0a9aa4fbcaf27.jpg', '', '', 'image/jpeg', 'jpg', '66545', '3f0827e7566a244d63e00964b9ed5f3b', '15f0dc247f89c220f009fa5d92a1ec8e1c205188', 'local', '0', '1588217975', '1588217975', '100', '1', '455', '589');
INSERT INTO `dp_admin_attachment` VALUES ('335', '1', 'c7.png', 'admin', 'uploads/images/20200430/5ea327277f7398cc77f43423f1363276.png', '', '', 'image/png', 'png', '48328', '4d4ccc785b8e249fb3f28b3c52ae294f', '61536cd8499701b6abaeac889a289cb2131539cd', 'local', '0', '1588217990', '1588217990', '100', '1', '455', '586');
INSERT INTO `dp_admin_attachment` VALUES ('336', '1', 'c8.jpg', 'admin', 'uploads/images/20200430/4fa33eef419dc906a3dc90a048a9865e.jpg', '', '', 'image/jpeg', 'jpg', '70677', 'ab053e4294ed193f249745da152d1879', '5ef69e46c5d8d748748c8d739d6b184f75170682', 'local', '0', '1588218003', '1588218003', '100', '1', '455', '589');
INSERT INTO `dp_admin_attachment` VALUES ('337', '1', 'g1.jpg', 'admin', 'uploads/images/20200430/3612592cac7dee8fea0c378be08c8e10.jpg', '', '', 'image/jpeg', 'jpg', '31333', '6b806dd7b65c21c330748a653f3689f3', 'bca8abaf8f1f2e41705dff1b3b62d3ec29eda913', 'local', '0', '1588218038', '1588218038', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('338', '1', 'g2.jpg', 'admin', 'uploads/images/20200430/72d15abaeec6b4dca1fdb15655a881eb.jpg', '', '', 'image/jpeg', 'jpg', '33152', '9d9facc4e8a53639825533534609ef7d', '092ca7470a3829ec77ff0258b9a086977b6736cc', 'local', '0', '1588218053', '1588218053', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('339', '1', 'g3.jpg', 'admin', 'uploads/images/20200430/fe3e98a75fc296e320ae9d43961f494f.jpg', '', '', 'image/jpeg', 'jpg', '32934', '939524295efe32981d3be22caa14eeb4', '20a4acb0cc06fdf7bc71e783e84ef9e8b4ee170f', 'local', '0', '1588218067', '1588218067', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('340', '1', 'g4.jpg', 'admin', 'uploads/images/20200430/eafe517d09a8d1121cbcfb8fec7c0666.jpg', '', '', 'image/jpeg', 'jpg', '32582', '7e8c37c42e437d2323bc842202427a8e', '62e249257bd334596502afa2b3565d236f21799f', 'local', '0', '1588218080', '1588218080', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('341', '1', 'g5.jpg', 'admin', 'uploads/images/20200430/2a7ceec6a8c35136eebb532b4988a81b.jpg', '', '', 'image/jpeg', 'jpg', '33346', '1a06d4eb7c1f141af3329b98c0f87e9b', '03408d80de306ac0c309d510251d085501c72ee0', 'local', '0', '1588218094', '1588218094', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('342', '1', 'g6.jpg', 'admin', 'uploads/images/20200430/6af51c97d6f6ee1d21eaa5af954671d7.jpg', '', '', 'image/jpeg', 'jpg', '30951', '6fa1a4c25b96b6468382559d8fbc9de8', '4867442c579e16d69a655841cd9e0d7327624f39', 'local', '0', '1588218107', '1588218107', '100', '1', '268', '379');
INSERT INTO `dp_admin_attachment` VALUES ('343', '1', '1.jpg', 'admin', 'uploads/images/20200430/47d6603300bb77f74a2e7d326bf97034.jpg', '', '', 'image/jpeg', 'jpg', '42116', '1aea4099af84a21afe8320b101d2ceb4', '3eea8ec629446740ff04f05025bd1ce26e92c7c8', 'local', '0', '1588223305', '1588223305', '100', '1', '910', '214');
INSERT INTO `dp_admin_attachment` VALUES ('344', '1', '2.jpg', 'admin', 'uploads/images/20200430/eb44bbf91349eb51e2bbeb32cdaf9749.jpg', '', '', 'image/jpeg', 'jpg', '77009', '0974faaff90f030460d410c930aa9eb0', 'da66a8fc35e992674aa53010378b1258e5a3e2c2', 'local', '0', '1588223321', '1588223321', '100', '1', '910', '213');
INSERT INTO `dp_admin_attachment` VALUES ('345', '1', '3.jpg', 'admin', 'uploads/images/20200430/71a51d0845786c3a59639954e9c3c147.jpg', '', '', 'image/jpeg', 'jpg', '84524', 'e2abc39d445fad49d0679533795ca551', 'a925c0776bc017abb66878d50eef63da68c028c1', 'local', '0', '1588223334', '1588223334', '100', '1', '910', '214');
INSERT INTO `dp_admin_attachment` VALUES ('346', '1', '4.jpg', 'admin', 'uploads/images/20200430/d8eb74babc0de946d0c24eb2c9f7e038.jpg', '', '', 'image/jpeg', 'jpg', '69151', '7c6ce409801006a766b6c0ca972b9f30', '0df52d0f5d6159ab70aa3300c1aad0503c7506ac', 'local', '0', '1588223347', '1588223347', '100', '1', '910', '213');
INSERT INTO `dp_admin_attachment` VALUES ('347', '1', '5.jpg', 'admin', 'uploads/images/20200430/cf7019f2a7eea49e220837b6ca8a0aaf.jpg', '', '', 'image/jpeg', 'jpg', '85788', '6af58fc6abfe824658c97492b65a6980', 'c71c9982344721c09e16f02f5857dda1ba100eaa', 'local', '0', '1588223362', '1588223362', '100', '1', '910', '214');
INSERT INTO `dp_admin_attachment` VALUES ('348', '1', '6.jpg', 'admin', 'uploads/images/20200430/527e1d4ac54106c0b01e72f9ed17736e.jpg', '', '', 'image/jpeg', 'jpg', '81534', '7f5c89c4e51d9974e8e65c4fe9107466', '2879766da1b03205bfc18ae33c65e4431f021ea3', 'local', '0', '1588223376', '1588223376', '100', '1', '910', '213');
INSERT INTO `dp_admin_attachment` VALUES ('349', '1', '7.jpg', 'admin', 'uploads/images/20200430/ab954759fe81e121d9776f25b7c201bf.jpg', '', '', 'image/jpeg', 'jpg', '67636', 'acb2aa9bce3a0697abb9e10b6d0dd6f2', '46d0c3403c2b40044d2dbda31a533eac234fe6c6', 'local', '0', '1588223390', '1588223390', '100', '1', '910', '214');
INSERT INTO `dp_admin_attachment` VALUES ('350', '1', '8.jpg', 'admin', 'uploads/images/20200430/fb15281ffe5fcd937c807ecf2a0def99.jpg', '', '', 'image/jpeg', 'jpg', '85125', '4cbe01850e8cc43a1aba88558fde08ef', 'a709c43a60e23f7d5356e7a5fdeff4d8db967b6d', 'local', '0', '1588223405', '1588223405', '100', '1', '910', '213');
INSERT INTO `dp_admin_attachment` VALUES ('351', '1', '9.jpg', 'admin', 'uploads/images/20200430/f17a3e97bfadce093e6672304ce6d50b.jpg', '', '', 'image/jpeg', 'jpg', '83169', '0bd0f794a698fd654c0b9c077301e396', 'a783b1a689897fc92f27397d892693462f0b116a', 'local', '0', '1588223417', '1588223417', '100', '1', '910', '214');
INSERT INTO `dp_admin_attachment` VALUES ('352', '1', '10.jpg', 'admin', 'uploads/images/20200430/fc21a74c22151da164c3f17dd1810f8a.jpg', '', '', 'image/jpeg', 'jpg', '135784', '9f13e14a4a87bdbd7ec090cfb5aed0fc', '7de5db3624c9bde0f1566dd2b118bd7a9ae4a24c', 'local', '0', '1588223432', '1588223432', '100', '1', '910', '213');
INSERT INTO `dp_admin_attachment` VALUES ('353', '1', '11.jpg', 'admin', 'uploads/images/20200430/b940193be09218d78c38f390a5c7b775.jpg', '', '', 'image/jpeg', 'jpg', '50562', '84ec3b354946d7a09059bbc629a307fc', '0feacde3fb926c9662660cbaeb211bb68ae4a7be', 'local', '0', '1588223455', '1588223455', '100', '1', '910', '214');
INSERT INTO `dp_admin_attachment` VALUES ('354', '1', '1.jpg', 'admin', 'uploads/images/20200430/e4a62cc69d65e67a10dd1e871e069b34.jpg', '', '', 'image/jpeg', 'jpg', '47884', '30622492a157a43a5d7238aceaf1f402', '62a9fa175fbe37c07ccb0445c43e6bc75f5184f7', 'local', '0', '1588223480', '1588223480', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('355', '1', '2.jpg', 'admin', 'uploads/images/20200430/cb4e778e43a6773ec0f6c5c846192017.jpg', '', '', 'image/jpeg', 'jpg', '37118', '441e29644b78a88795d0b93562c5ee0f', '0c613784c7def20a5b034401527c866dfaabde5c', 'local', '0', '1588223499', '1588223499', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('356', '1', '3.jpg', 'admin', 'uploads/images/20200430/22dcf65ba51f8a87c182d1434f262c4d.jpg', '', '', 'image/jpeg', 'jpg', '65677', 'df2498d630854bb66fffb7a37745b836', '279920422fb76dbb6499c0e59efef09eb9ab805a', 'local', '0', '1588223516', '1588223516', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('357', '1', '4.jpg', 'admin', 'uploads/images/20200430/4217771b60e58296540c1ce937e5fd39.jpg', '', '', 'image/jpeg', 'jpg', '64309', '809c7823fe0e6612795b22cffe886419', '6ee5cb070057f04112ae54f72aa8abc4a2762ce3', 'local', '0', '1588223536', '1588223536', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('358', '1', '5.jpg', 'admin', 'uploads/images/20200430/1a446e62d7ef7a6d1cad60e622fb7290.jpg', '', '', 'image/jpeg', 'jpg', '56159', '46c186e5b692372a7c0c019109f6e672', '5f10848be614ed3d8ccb2d2926c8c29943c86e8e', 'local', '0', '1588223552', '1588223552', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('359', '1', '6.jpg', 'admin', 'uploads/images/20200430/8234525a1f299c60cc283c875dbab92e.jpg', '', '', 'image/jpeg', 'jpg', '53246', '8111eef57272b14e008b93a2a811ab6e', 'e94267b09133e3680d092ee2388fcc9cbfab5267', 'local', '0', '1588223568', '1588223568', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('360', '1', '7.jpg', 'admin', 'uploads/images/20200430/e5ff80d03f740cfa3f36fcf65621289f.jpg', '', '', 'image/jpeg', 'jpg', '65519', '79fd2d1a5c8a8d61c2f4be364a2d9623', 'c3bc05fbb37679906ed697ebf8941fd5498bdc5d', 'local', '0', '1588223914', '1588223914', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('361', '1', '8.jpg', 'admin', 'uploads/images/20200430/2864284e8165e3f1c943aa67c5a94316.jpg', '', '', 'image/jpeg', 'jpg', '45110', '5d04655180167a203eea01824d699af7', 'a1b259547e196432673b3514a3bb74d6e9268e52', 'local', '0', '1588223932', '1588223932', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('362', '1', '9.jpg', 'admin', 'uploads/images/20200430/7944d39310f1e7bd39f7bd060547cca9.jpg', '', '', 'image/jpeg', 'jpg', '58356', 'dc70cf161507f784cdbff89bb3fe3305', '068d52987ba132e61894dbb2ecc252444f2d4a1d', 'local', '0', '1588223945', '1588223945', '100', '1', '910', '178');
INSERT INTO `dp_admin_attachment` VALUES ('363', '1', '10.jpg', 'admin', 'uploads/images/20200430/3d535e3ff4837e0a760741ff145512ca.jpg', '', '', 'image/jpeg', 'jpg', '54973', '9b9d8c64aab092f22b8b15414fc7a6a4', '8f5ba452cfe0738da998df16fc16b81744ed0354', 'local', '0', '1588223965', '1588223965', '100', '1', '910', '178');

-- -----------------------------
-- Table structure for `dp_admin_config`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_config`;
CREATE TABLE `dp_admin_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '标题',
  `group` varchar(32) NOT NULL DEFAULT '' COMMENT '配置分组',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型',
  `value` text NOT NULL COMMENT '配置值',
  `options` text NOT NULL COMMENT '配置项',
  `tips` varchar(256) NOT NULL DEFAULT '' COMMENT '配置提示',
  `ajax_url` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框ajax地址',
  `next_items` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框的下级下拉框名，多个以逗号隔开',
  `param` varchar(32) NOT NULL DEFAULT '' COMMENT '联动下拉框请求参数名',
  `format` varchar(32) NOT NULL DEFAULT '' COMMENT '格式，用于格式文本',
  `table` varchar(32) NOT NULL DEFAULT '' COMMENT '表名，只用于快速联动类型',
  `level` tinyint(2) unsigned NOT NULL DEFAULT '2' COMMENT '联动级别，只用于快速联动类型',
  `key` varchar(32) NOT NULL DEFAULT '' COMMENT '键字段，只用于快速联动类型',
  `option` varchar(32) NOT NULL DEFAULT '' COMMENT '值字段，只用于快速联动类型',
  `pid` varchar(32) NOT NULL DEFAULT '' COMMENT '父级id字段，只用于快速联动类型',
  `ak` varchar(32) NOT NULL DEFAULT '' COMMENT '百度地图appkey',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- -----------------------------
-- Records of `dp_admin_config`
-- -----------------------------
INSERT INTO `dp_admin_config` VALUES ('1', 'web_site_status', '站点开关', 'base', 'switch', '1', '', '站点关闭后将不能访问，后台可正常登录', '', '', '', '', '', '2', '', '', '', '', '1475240395', '1477403914', '1', '1');
INSERT INTO `dp_admin_config` VALUES ('2', 'web_site_title', '站点标题', 'base', 'text', '海豚PHP', '', '调用方式：<code>config(\'web_site_title\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475240646', '1477710341', '2', '1');
INSERT INTO `dp_admin_config` VALUES ('3', 'web_site_slogan', '站点标语', 'base', 'text', '海豚PHP，极简、极速、极致', '', '站点口号，调用方式：<code>config(\'web_site_slogan\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475240994', '1477710357', '3', '1');
INSERT INTO `dp_admin_config` VALUES ('4', 'web_site_logo', '站点LOGO', 'base', 'image', '', '', '', '', '', '', '', '', '2', '', '', '', '', '1475241067', '1475241067', '4', '1');
INSERT INTO `dp_admin_config` VALUES ('5', 'web_site_description', '站点描述', 'base', 'textarea', '', '', '网站描述，有利于搜索引擎抓取相关信息', '', '', '', '', '', '2', '', '', '', '', '1475241186', '1475241186', '6', '1');
INSERT INTO `dp_admin_config` VALUES ('6', 'web_site_keywords', '站点关键词', 'base', 'text', '海豚PHP、PHP开发框架、后台框架', '', '网站搜索引擎关键字', '', '', '', '', '', '2', '', '', '', '', '1475241328', '1475241328', '7', '1');
INSERT INTO `dp_admin_config` VALUES ('7', 'web_site_copyright', '版权信息', 'base', 'text', 'Copyright © 2015-2017 DolphinPHP All rights reserved.', '', '调用方式：<code>config(\'web_site_copyright\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475241416', '1477710383', '8', '1');
INSERT INTO `dp_admin_config` VALUES ('8', 'web_site_icp', '备案信息', 'base', 'text', '', '', '调用方式：<code>config(\'web_site_icp\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475241441', '1477710441', '9', '1');
INSERT INTO `dp_admin_config` VALUES ('9', 'web_site_statistics', '站点统计', 'base', 'textarea', '', '', '网站统计代码，支持百度、Google、cnzz等，调用方式：<code>config(\'web_site_statistics\')</code>', '', '', '', '', '', '2', '', '', '', '', '1475241498', '1477710455', '10', '1');
INSERT INTO `dp_admin_config` VALUES ('10', 'config_group', '配置分组', 'system', 'array', 'base:基本\r\nsystem:系统\r\nupload:上传\r\ndevelop:开发\r\ndatabase:数据库', '', '', '', '', '', '', '', '2', '', '', '', '', '1475241716', '1477649446', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('11', 'form_item_type', '配置类型', 'system', 'array', 'text:单行文本\r\ntextarea:多行文本\r\nstatic:静态文本\r\npassword:密码\r\ncheckbox:复选框\r\nradio:单选按钮\r\ndate:日期\r\ndatetime:日期+时间\r\nhidden:隐藏\r\nswitch:开关\r\narray:数组\r\nselect:下拉框\r\nlinkage:普通联动下拉框\r\nlinkages:快速联动下拉框\r\nimage:单张图片\r\nimages:多张图片\r\nfile:单个文件\r\nfiles:多个文件\r\nueditor:UEditor 编辑器\r\nwangeditor:wangEditor 编辑器\r\neditormd:markdown 编辑器\r\nckeditor:ckeditor 编辑器\r\nicon:字体图标\r\ntags:标签\r\nnumber:数字\r\nbmap:百度地图\r\ncolorpicker:取色器\r\njcrop:图片裁剪\r\nmasked:格式文本\r\nrange:范围\r\ntime:时间', '', '', '', '', '', '', '', '2', '', '', '', '', '1475241835', '1495853193', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('12', 'upload_file_size', '文件上传大小限制', 'upload', 'text', '0', '', '0为不限制大小，单位：kb', '', '', '', '', '', '2', '', '', '', '', '1475241897', '1477663520', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('13', 'upload_file_ext', '允许上传的文件后缀', 'upload', 'tags', 'doc,docx,xls,xlsx,ppt,pptx,pdf,wps,txt,rar,zip,gz,bz2,7z,mp4', '', '多个后缀用逗号隔开，不填写则不限制类型', '', '', '', '', '', '2', '', '', '', '', '1475241975', '1477649489', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('14', 'upload_image_size', '图片上传大小限制', 'upload', 'text', '0', '', '0为不限制大小，单位：kb', '', '', '', '', '', '2', '', '', '', '', '1475242015', '1477663529', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('15', 'upload_image_ext', '允许上传的图片后缀', 'upload', 'tags', 'gif,jpg,jpeg,bmp,png,ico', '', '多个后缀用逗号隔开，不填写则不限制类型', '', '', '', '', '', '2', '', '', '', '', '1475242056', '1587449025', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('16', 'list_rows', '分页数量', 'system', 'number', '20', '', '每页的记录数', '', '', '', '', '', '2', '', '', '', '', '1475242066', '1476074507', '101', '1');
INSERT INTO `dp_admin_config` VALUES ('17', 'system_color', '后台配色方案', 'system', 'radio', 'modern', 'default:Default\r\namethyst:Amethyst\r\ncity:City\r\nflat:Flat\r\nmodern:Modern\r\nsmooth:Smooth', '', '', '', '', '', '', '2', '', '', '', '', '1475250066', '1477316689', '102', '1');
INSERT INTO `dp_admin_config` VALUES ('18', 'develop_mode', '开发模式', 'develop', 'radio', '1', '0:关闭\r\n1:开启', '', '', '', '', '', '', '2', '', '', '', '', '1476864205', '1476864231', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('19', 'app_trace', '显示页面Trace', 'develop', 'radio', '1', '0:否\r\n1:是', '', '', '', '', '', '', '2', '', '', '', '', '1476866355', '1476866355', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('21', 'data_backup_path', '数据库备份根路径', 'database', 'text', '../data/', '', '路径必须以 / 结尾', '', '', '', '', '', '2', '', '', '', '', '1477017745', '1477018467', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('22', 'data_backup_part_size', '数据库备份卷大小', 'database', 'text', '20971520', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '', '', '', '', '', '2', '', '', '', '', '1477017886', '1477017886', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('23', 'data_backup_compress', '数据库备份文件是否启用压缩', 'database', 'radio', '1', '0:否\r\n1:是', '压缩备份文件需要PHP环境支持 <code>gzopen</code>, <code>gzwrite</code>函数', '', '', '', '', '', '2', '', '', '', '', '1477017978', '1477018172', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('24', 'data_backup_compress_level', '数据库备份文件压缩级别', 'database', 'radio', '9', '1:最低\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '', '', '', '', '', '2', '', '', '', '', '1477018083', '1477018083', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('25', 'top_menu_max', '顶部导航模块数量', 'system', 'text', '10', '', '设置顶部导航默认显示的模块数量', '', '', '', '', '', '2', '', '', '', '', '1477579289', '1477579289', '103', '1');
INSERT INTO `dp_admin_config` VALUES ('26', 'web_site_logo_text', '站点LOGO文字', 'base', 'image', '', '', '', '', '', '', '', '', '2', '', '', '', '', '1477620643', '1477620643', '5', '1');
INSERT INTO `dp_admin_config` VALUES ('27', 'upload_image_thumb', '缩略图尺寸', 'upload', 'text', '', '', '不填写则不生成缩略图，如需生成 <code>300x300</code> 的缩略图，则填写 <code>300,300</code> ，请注意，逗号必须是英文逗号', '', '', '', '', '', '2', '', '', '', '', '1477644150', '1477649513', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('28', 'upload_image_thumb_type', '缩略图裁剪类型', 'upload', 'radio', '1', '1:等比例缩放\r\n2:缩放后填充\r\n3:居中裁剪\r\n4:左上角裁剪\r\n5:右下角裁剪\r\n6:固定尺寸缩放', '该项配置只有在启用生成缩略图时才生效', '', '', '', '', '', '2', '', '', '', '', '1477646271', '1477649521', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('29', 'upload_thumb_water', '添加水印', 'upload', 'switch', '0', '', '', '', '', '', '', '', '2', '', '', '', '', '1477649648', '1477649648', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('30', 'upload_thumb_water_pic', '水印图片', 'upload', 'image', '', '', '只有开启水印功能才生效', '', '', '', '', '', '2', '', '', '', '', '1477656390', '1477656390', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('31', 'upload_thumb_water_position', '水印位置', 'upload', 'radio', '9', '1:左上角\r\n2:上居中\r\n3:右上角\r\n4:左居中\r\n5:居中\r\n6:右居中\r\n7:左下角\r\n8:下居中\r\n9:右下角', '只有开启水印功能才生效', '', '', '', '', '', '2', '', '', '', '', '1477656528', '1477656528', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('32', 'upload_thumb_water_alpha', '水印透明度', 'upload', 'text', '50', '', '请输入0~100之间的数字，数字越小，透明度越高', '', '', '', '', '', '2', '', '', '', '', '1477656714', '1477661309', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('33', 'wipe_cache_type', '清除缓存类型', 'system', 'checkbox', 'TEMP_PATH', 'TEMP_PATH:应用缓存\r\nLOG_PATH:应用日志\r\nCACHE_PATH:项目模板缓存', '清除缓存时，要删除的缓存类型', '', '', '', '', '', '2', '', '', '', '', '1477727305', '1477727305', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('34', 'captcha_signin', '后台验证码开关', 'system', 'switch', '0', '', '后台登录时是否需要验证码', '', '', '', '', '', '2', '', '', '', '', '1478771958', '1478771958', '99', '1');
INSERT INTO `dp_admin_config` VALUES ('35', 'home_default_module', '前台默认模块', 'system', 'select', 'index', '', '前台默认访问的模块，该模块必须有Index控制器和index方法', '', '', '', '', '', '0', '', '', '', '', '1486714723', '1486715620', '104', '1');
INSERT INTO `dp_admin_config` VALUES ('36', 'minify_status', '开启minify', 'system', 'switch', '0', '', '开启minify会压缩合并js、css文件，可以减少资源请求次数，如果不支持minify，可关闭', '', '', '', '', '', '0', '', '', '', '', '1487035843', '1487035843', '99', '1');
INSERT INTO `dp_admin_config` VALUES ('37', 'upload_driver', '上传驱动', 'upload', 'radio', 'local', 'local:本地', '图片或文件上传驱动', '', '', '', '', '', '0', '', '', '', '', '1501488567', '1501490821', '100', '1');
INSERT INTO `dp_admin_config` VALUES ('38', 'system_log', '系统日志', 'system', 'switch', '1', '', '是否开启系统日志功能', '', '', '', '', '', '0', '', '', '', '', '1512635391', '1512635391', '99', '1');
INSERT INTO `dp_admin_config` VALUES ('39', 'asset_version', '资源版本号', 'develop', 'text', '20200420', '', '可通过修改版号强制用户更新静态文件', '', '', '', '', '', '0', '', '', '', '', '1522143239', '1522143239', '100', '1');

-- -----------------------------
-- Table structure for `dp_admin_hook`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_hook`;
CREATE TABLE `dp_admin_hook` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子来自哪个插件',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子描述',
  `system` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统钩子',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='钩子表';

-- -----------------------------
-- Records of `dp_admin_hook`
-- -----------------------------
INSERT INTO `dp_admin_hook` VALUES ('1', 'admin_index', '', '后台首页', '1', '1468174214', '1477757518', '1');
INSERT INTO `dp_admin_hook` VALUES ('2', 'plugin_index_tab_list', '', '插件扩展tab钩子', '1', '1468174214', '1468174214', '1');
INSERT INTO `dp_admin_hook` VALUES ('3', 'module_index_tab_list', '', '模块扩展tab钩子', '1', '1468174214', '1468174214', '1');
INSERT INTO `dp_admin_hook` VALUES ('4', 'page_tips', '', '每个页面的提示', '1', '1468174214', '1468174214', '1');
INSERT INTO `dp_admin_hook` VALUES ('5', 'signin_footer', '', '登录页面底部钩子', '1', '1479269315', '1479269315', '1');
INSERT INTO `dp_admin_hook` VALUES ('6', 'signin_captcha', '', '登录页面验证码钩子', '1', '1479269315', '1479269315', '1');
INSERT INTO `dp_admin_hook` VALUES ('7', 'signin', '', '登录控制器钩子', '1', '1479386875', '1479386875', '1');
INSERT INTO `dp_admin_hook` VALUES ('8', 'upload_attachment', '', '附件上传钩子', '1', '1501493808', '1501493808', '1');
INSERT INTO `dp_admin_hook` VALUES ('9', 'page_plugin_js', '', '页面插件js钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('10', 'page_plugin_css', '', '页面插件css钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('11', 'signin_sso', '', '单点登录钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('12', 'signout_sso', '', '单点退出钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('13', 'user_add', '', '添加用户钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('14', 'user_edit', '', '编辑用户钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('15', 'user_delete', '', '删除用户钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('16', 'user_enable', '', '启用用户钩子', '1', '1503633591', '1503633591', '1');
INSERT INTO `dp_admin_hook` VALUES ('17', 'user_disable', '', '禁用用户钩子', '1', '1503633591', '1503633591', '1');

-- -----------------------------
-- Table structure for `dp_admin_hook_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_hook_plugin`;
CREATE TABLE `dp_admin_hook_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子id',
  `plugin` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标识',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='钩子-插件对应表';

-- -----------------------------
-- Records of `dp_admin_hook_plugin`
-- -----------------------------
INSERT INTO `dp_admin_hook_plugin` VALUES ('1', 'admin_index', 'SystemInfo', '1477757503', '1477757503', '1', '1');
INSERT INTO `dp_admin_hook_plugin` VALUES ('2', 'admin_index', 'DevTeam', '1477755780', '1477755780', '2', '1');

-- -----------------------------
-- Table structure for `dp_admin_icon`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_icon`;
CREATE TABLE `dp_admin_icon` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '图标名称',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图标css地址',
  `prefix` varchar(32) NOT NULL DEFAULT '' COMMENT '图标前缀',
  `font_family` varchar(32) NOT NULL DEFAULT '' COMMENT '字体名',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='图标表';


-- -----------------------------
-- Table structure for `dp_admin_icon_list`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_icon_list`;
CREATE TABLE `dp_admin_icon_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `icon_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属图标id',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '图标标题',
  `class` varchar(255) NOT NULL DEFAULT '' COMMENT '图标类名',
  `code` varchar(128) NOT NULL DEFAULT '' COMMENT '图标关键词',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='详细图标列表';


-- -----------------------------
-- Table structure for `dp_admin_log`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_log`;
CREATE TABLE `dp_admin_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` longtext NOT NULL COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=173 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `dp_admin_log`
-- -----------------------------
INSERT INTO `dp_admin_log` VALUES ('1', '30', '1', '2130706433', 'admin_menu', '237', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(前台管理),节点链接()', '1', '1587363321');
INSERT INTO `dp_admin_log` VALUES ('2', '30', '1', '2130706433', 'admin_menu', '238', '超级管理员 添加了节点：所属模块(admin),所属节点ID(237),节点标题(导航栏),节点链接(admin/menu/add)', '1', '1587363424');
INSERT INTO `dp_admin_log` VALUES ('3', '30', '1', '2130706433', 'admin_menu', '239', '超级管理员 添加了节点：所属模块(admin),所属节点ID(237),节点标题(Banner图),节点链接(admin/menu/add)', '1', '1587363508');
INSERT INTO `dp_admin_log` VALUES ('4', '42', '1', '2130706433', 'admin_config', '0', '超级管理员 更新了系统设置：分组(system)', '1', '1587364674');
INSERT INTO `dp_admin_log` VALUES ('5', '42', '1', '2130706433', 'admin_config', '0', '超级管理员 更新了系统设置：分组(develop)', '1', '1587367575');
INSERT INTO `dp_admin_log` VALUES ('6', '34', '1', '2130706433', 'admin_menu', '70', '超级管理员 禁用了节点：节点ID(70),节点标题(后台首页),节点链接(admin/index/index)', '1', '1587370976');
INSERT INTO `dp_admin_log` VALUES ('7', '33', '1', '2130706433', 'admin_menu', '70', '超级管理员 启用了节点：节点ID(70),节点标题(后台首页),节点链接(admin/index/index)', '1', '1587370979');
INSERT INTO `dp_admin_log` VALUES ('8', '35', '1', '2130706433', 'admin_module', '0', '超级管理员 安装了模块：门户', '1', '1587373197');
INSERT INTO `dp_admin_log` VALUES ('9', '42', '1', '2130706433', 'admin_config', '0', '超级管理员 更新了系统设置：分组(system)', '1', '1587432086');
INSERT INTO `dp_admin_log` VALUES ('10', '31', '1', '2130706433', 'admin_menu', '237', '超级管理员 编辑了节点：节点ID(237)', '1', '1587432327');
INSERT INTO `dp_admin_log` VALUES ('11', '30', '1', '2130706433', 'admin_menu', '333', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(官网首页),节点链接()', '1', '1587432398');
INSERT INTO `dp_admin_log` VALUES ('12', '30', '1', '2130706433', 'admin_menu', '334', '超级管理员 添加了节点：所属模块(admin),所属节点ID(237),节点标题(公共配置),节点链接()', '1', '1587432464');
INSERT INTO `dp_admin_log` VALUES ('13', '30', '1', '2130706433', 'admin_menu', '335', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(相册),节点链接()', '1', '1587432767');
INSERT INTO `dp_admin_log` VALUES ('14', '30', '1', '2130706433', 'admin_menu', '336', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(轮播图),节点链接()', '1', '1587432799');
INSERT INTO `dp_admin_log` VALUES ('15', '30', '1', '2130706433', 'admin_menu', '337', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(NEWS),节点链接()', '1', '1587432833');
INSERT INTO `dp_admin_log` VALUES ('16', '30', '1', '2130706433', 'admin_menu', '338', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(美食中心),节点链接()', '1', '1587432874');
INSERT INTO `dp_admin_log` VALUES ('17', '30', '1', '2130706433', 'admin_menu', '339', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(店铺实拍),节点链接()', '1', '1587432924');
INSERT INTO `dp_admin_log` VALUES ('18', '30', '1', '2130706433', 'admin_menu', '340', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(滚动图),节点链接()', '1', '1587433102');
INSERT INTO `dp_admin_log` VALUES ('19', '31', '1', '2130706433', 'admin_menu', '238', '超级管理员 编辑了节点：节点ID(238)', '1', '1587434962');
INSERT INTO `dp_admin_log` VALUES ('20', '31', '1', '2130706433', 'admin_menu', '340', '超级管理员 编辑了节点：节点ID(340)', '1', '1587436622');
INSERT INTO `dp_admin_log` VALUES ('21', '31', '1', '2130706433', 'admin_menu', '340', '超级管理员 编辑了节点：节点ID(340)', '1', '1587436657');
INSERT INTO `dp_admin_log` VALUES ('22', '32', '1', '2130706433', 'admin_menu', '238', '超级管理员 删除了节点：节点ID(238),节点标题(导航栏),节点链接(admin/navigation/index)', '1', '1587436909');
INSERT INTO `dp_admin_log` VALUES ('23', '30', '1', '2130706433', 'admin_menu', '341', '超级管理员 添加了节点：所属模块(admin),所属节点ID(237),节点标题(导航栏),节点链接(admin/navigation/index)', '1', '1587436941');
INSERT INTO `dp_admin_log` VALUES ('24', '31', '1', '2130706433', 'admin_menu', '341', '超级管理员 编辑了节点：节点ID(341)', '1', '1587436990');
INSERT INTO `dp_admin_log` VALUES ('25', '31', '1', '2130706433', 'admin_menu', '1', '超级管理员 编辑了节点：节点ID(1)', '1', '1587438743');
INSERT INTO `dp_admin_log` VALUES ('26', '31', '1', '2130706433', 'admin_menu', '1', '超级管理员 编辑了节点：节点ID(1)', '1', '1587438757');
INSERT INTO `dp_admin_log` VALUES ('27', '30', '1', '2130706433', 'admin_menu', '341', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(关于我们),节点链接(home/aboutus/index)', '1', '1587438863');
INSERT INTO `dp_admin_log` VALUES ('28', '31', '1', '2130706433', 'admin_menu', '341', '超级管理员 编辑了节点：节点ID(341)', '1', '1587438906');
INSERT INTO `dp_admin_log` VALUES ('29', '30', '1', '2130706433', 'admin_menu', '342', '超级管理员 添加了节点：所属模块(admin),所属节点ID(341),节点标题(企业简介),节点链接(home/aboutus/index)', '1', '1587439548');
INSERT INTO `dp_admin_log` VALUES ('30', '31', '1', '2130706433', 'admin_menu', '334', '超级管理员 编辑了节点：节点ID(334)', '1', '1587448050');
INSERT INTO `dp_admin_log` VALUES ('31', '16', '1', '2130706433', 'admin_config', '15', '超级管理员 编辑了配置：原数据：分组(upload)、类型(tags)、标题(允许上传的图片后缀)、名称(upload_image_ext)', '1', '1587449025');
INSERT INTO `dp_admin_log` VALUES ('32', '32', '1', '2130706433', 'admin_menu', '335', '超级管理员 删除了节点：节点ID(335),节点标题(相册),节点链接()', '1', '1587451941');
INSERT INTO `dp_admin_log` VALUES ('33', '30', '1', '2130706433', 'admin_menu', '348', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(相册),节点链接(admin/album/index)', '1', '1587452030');
INSERT INTO `dp_admin_log` VALUES ('34', '32', '1', '2130706433', 'admin_menu', '337', '超级管理员 删除了节点：节点ID(337),节点标题(NEWS),节点链接()', '1', '1587518997');
INSERT INTO `dp_admin_log` VALUES ('35', '30', '1', '2130706433', 'admin_menu', '355', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(NEWS),节点链接(admin/news/index)', '1', '1587519049');
INSERT INTO `dp_admin_log` VALUES ('36', '30', '1', '2130706433', 'admin_menu', '343', '超级管理员 添加了节点：所属模块(admin),所属节点ID(341),节点标题(潮流前言),节点链接(home/aboutus/index)', '1', '1587522490');
INSERT INTO `dp_admin_log` VALUES ('37', '31', '1', '2130706433', 'admin_menu', '342', '超级管理员 编辑了节点：节点ID(342)', '1', '1587522512');
INSERT INTO `dp_admin_log` VALUES ('38', '30', '1', '2130706433', 'admin_menu', '362', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(关于),节点链接()', '1', '1587522724');
INSERT INTO `dp_admin_log` VALUES ('39', '31', '1', '2130706433', 'admin_menu', '362', '超级管理员 编辑了节点：节点ID(362)', '1', '1587522760');
INSERT INTO `dp_admin_log` VALUES ('40', '31', '1', '2130706433', 'admin_menu', '362', '超级管理员 编辑了节点：节点ID(362)', '1', '1587522784');
INSERT INTO `dp_admin_log` VALUES ('41', '30', '1', '2130706433', 'admin_menu', '363', '超级管理员 添加了节点：所属模块(admin),所属节点ID(362),节点标题(文章管理),节点链接()', '1', '1587522829');
INSERT INTO `dp_admin_log` VALUES ('42', '30', '1', '2130706433', 'admin_menu', '344', '超级管理员 添加了节点：所属模块(admin),所属节点ID(341),节点标题(品牌介绍),节点链接(home/aboutus/index)', '1', '1587522939');
INSERT INTO `dp_admin_log` VALUES ('43', '30', '1', '2130706433', 'admin_menu', '345', '超级管理员 添加了节点：所属模块(admin),所属节点ID(341),节点标题(品牌优势),节点链接(home/aboutus/index)', '1', '1587522976');
INSERT INTO `dp_admin_log` VALUES ('44', '30', '1', '2130706433', 'admin_menu', '346', '超级管理员 添加了节点：所属模块(admin),所属节点ID(341),节点标题(企业大事记),节点链接(home/aboutus/index)', '1', '1587523013');
INSERT INTO `dp_admin_log` VALUES ('45', '30', '1', '2130706433', 'admin_menu', '347', '超级管理员 添加了节点：所属模块(admin),所属节点ID(341),节点标题(资深讲师),节点链接(home/aboutus/index)', '1', '1587523045');
INSERT INTO `dp_admin_log` VALUES ('46', '31', '1', '2130706433', 'admin_menu', '346', '超级管理员 编辑了节点：节点ID(346)', '1', '1587523055');
INSERT INTO `dp_admin_log` VALUES ('47', '30', '1', '2130706433', 'admin_menu', '348', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(美食中心),节点链接(home/food/index)', '1', '1587523148');
INSERT INTO `dp_admin_log` VALUES ('48', '31', '1', '2130706433', 'admin_menu', '348', '超级管理员 编辑了节点：节点ID(348)', '1', '1587523164');
INSERT INTO `dp_admin_log` VALUES ('49', '30', '1', '2130706433', 'admin_menu', '349', '超级管理员 添加了节点：所属模块(admin),所属节点ID(348),节点标题(纸上烤肉),节点链接(home/aboutus/index)', '1', '1587523204');
INSERT INTO `dp_admin_log` VALUES ('50', '30', '1', '2130706433', 'admin_menu', '350', '超级管理员 添加了节点：所属模块(admin),所属节点ID(348),节点标题(纸上火锅),节点链接(home/food/indexh)', '1', '1587523260');
INSERT INTO `dp_admin_log` VALUES ('51', '31', '1', '2130706433', 'admin_menu', '349', '超级管理员 编辑了节点：节点ID(349)', '1', '1587523279');
INSERT INTO `dp_admin_log` VALUES ('52', '31', '1', '2130706433', 'admin_menu', '350', '超级管理员 编辑了节点：节点ID(350)', '1', '1587523302');
INSERT INTO `dp_admin_log` VALUES ('53', '30', '1', '2130706433', 'admin_menu', '351', '超级管理员 添加了节点：所属模块(admin),所属节点ID(348),节点标题(牛排海鲜),节点链接(home/food/index)', '1', '1587523349');
INSERT INTO `dp_admin_log` VALUES ('54', '30', '1', '2130706433', 'admin_menu', '352', '超级管理员 添加了节点：所属模块(admin),所属节点ID(348),节点标题(养生汤品),节点链接(home/food/index)', '1', '1587523395');
INSERT INTO `dp_admin_log` VALUES ('55', '30', '1', '2130706433', 'admin_menu', '353', '超级管理员 添加了节点：所属模块(admin),所属节点ID(348),节点标题(特色小吃),节点链接(home/food/index)', '1', '1587523415');
INSERT INTO `dp_admin_log` VALUES ('56', '30', '1', '2130706433', 'admin_menu', '354', '超级管理员 添加了节点：所属模块(admin),所属节点ID(348),节点标题(港式甜品),节点链接(home/food/index)', '1', '1587523439');
INSERT INTO `dp_admin_log` VALUES ('57', '30', '1', '2130706433', 'admin_menu', '355', '超级管理员 添加了节点：所属模块(admin),所属节点ID(348),节点标题(时尚饮品),节点链接(home/food/index)', '1', '1587523460');
INSERT INTO `dp_admin_log` VALUES ('58', '30', '1', '2130706433', 'admin_menu', '356', '超级管理员 添加了节点：所属模块(admin),所属节点ID(348),节点标题(冰淇淋),节点链接(home/food/index)', '1', '1587523485');
INSERT INTO `dp_admin_log` VALUES ('59', '30', '1', '2130706433', 'admin_menu', '357', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(店面风采),节点链接(home/store/index)', '1', '1587523585');
INSERT INTO `dp_admin_log` VALUES ('60', '30', '1', '2130706433', 'admin_menu', '358', '超级管理员 添加了节点：所属模块(admin),所属节点ID(357),节点标题(店铺形象),节点链接(home/store/index)', '1', '1587523625');
INSERT INTO `dp_admin_log` VALUES ('61', '30', '1', '2130706433', 'admin_menu', '359', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(项目中心),节点链接(home/project /index)', '1', '1587523765');
INSERT INTO `dp_admin_log` VALUES ('62', '30', '1', '2130706433', 'admin_menu', '360', '超级管理员 添加了节点：所属模块(admin),所属节点ID(359),节点标题(媒体报道),节点链接(home/project /index)', '1', '1587523800');
INSERT INTO `dp_admin_log` VALUES ('63', '30', '1', '2130706433', 'admin_menu', '22', '超级管理员 添加了节点：所属模块(admin),所属节点ID(20),节点标题(投资店型),节点链接(home/project /index)', '1', '1587524146');
INSERT INTO `dp_admin_log` VALUES ('64', '30', '1', '2130706433', 'admin_menu', '23', '超级管理员 添加了节点：所属模块(admin),所属节点ID(20),节点标题(合作流程),节点链接(home/project /index)', '1', '1587524167');
INSERT INTO `dp_admin_log` VALUES ('65', '30', '1', '2130706433', 'admin_menu', '24', '超级管理员 添加了节点：所属模块(admin),所属节点ID(20),节点标题(代理专区),节点链接(home/project /index)', '1', '1587524191');
INSERT INTO `dp_admin_log` VALUES ('66', '30', '1', '2130706433', 'admin_menu', '25', '超级管理员 添加了节点：所属模块(admin),所属节点ID(20),节点标题(成功案例),节点链接(home/project /index)', '1', '1587524317');
INSERT INTO `dp_admin_log` VALUES ('67', '30', '1', '2130706433', 'admin_menu', '26', '超级管理员 添加了节点：所属模块(admin),所属节点ID(20),节点标题(自助投资分析),节点链接(home/project /index)', '1', '1587524337');
INSERT INTO `dp_admin_log` VALUES ('68', '30', '1', '2130706433', 'admin_menu', '27', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(品牌动态),节点链接(home/trends/index)', '1', '1587524409');
INSERT INTO `dp_admin_log` VALUES ('69', '30', '1', '2130706433', 'admin_menu', '28', '超级管理员 添加了节点：所属模块(admin),所属节点ID(27),节点标题(开店快讯),节点链接(home/trends/index)', '1', '1587524470');
INSERT INTO `dp_admin_log` VALUES ('70', '30', '1', '2130706433', 'admin_menu', '29', '超级管理员 添加了节点：所属模块(admin),所属节点ID(27),节点标题(新闻资讯),节点链接(home/trends/index)', '1', '1587524495');
INSERT INTO `dp_admin_log` VALUES ('71', '30', '1', '2130706433', 'admin_menu', '30', '超级管理员 添加了节点：所属模块(admin),所属节点ID(27),节点标题(品牌动态),节点链接(home/trends/index)', '1', '1587524526');
INSERT INTO `dp_admin_log` VALUES ('72', '30', '1', '2130706433', 'admin_menu', '31', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(加盟信息),节点链接(home/)', '1', '1587524619');
INSERT INTO `dp_admin_log` VALUES ('73', '31', '1', '2130706433', 'admin_menu', '31', '超级管理员 编辑了节点：节点ID(31)', '1', '1587524630');
INSERT INTO `dp_admin_log` VALUES ('74', '31', '1', '2130706433', 'admin_menu', '31', '超级管理员 编辑了节点：节点ID(31)', '1', '1587524649');
INSERT INTO `dp_admin_log` VALUES ('75', '30', '1', '2130706433', 'admin_menu', '32', '超级管理员 添加了节点：所属模块(admin),所属节点ID(31),节点标题(招商加盟服务),节点链接(home/)', '1', '1587524726');
INSERT INTO `dp_admin_log` VALUES ('76', '30', '1', '2130706433', 'admin_menu', '33', '超级管理员 添加了节点：所属模块(admin),所属节点ID(31),节点标题(加盟流程),节点链接()', '1', '1587524746');
INSERT INTO `dp_admin_log` VALUES ('77', '30', '1', '2130706433', 'admin_menu', '34', '超级管理员 添加了节点：所属模块(admin),所属节点ID(31),节点标题(加盟优势),节点链接(home/)', '1', '1587524770');
INSERT INTO `dp_admin_log` VALUES ('78', '30', '1', '2130706433', 'admin_menu', '35', '超级管理员 添加了节点：所属模块(admin),所属节点ID(0),节点标题(联系我们),节点链接(home/contactus/index)', '1', '1587524831');
INSERT INTO `dp_admin_log` VALUES ('79', '30', '1', '2130706433', 'admin_menu', '36', '超级管理员 添加了节点：所属模块(admin),所属节点ID(35),节点标题(联系方式),节点链接(home/contactus/index)', '1', '1587524857');
INSERT INTO `dp_admin_log` VALUES ('80', '30', '1', '2130706433', 'admin_menu', '37', '超级管理员 添加了节点：所属模块(admin),所属节点ID(35),节点标题(在线留言),节点链接(home/contactus/index)', '1', '1587524873');
INSERT INTO `dp_admin_log` VALUES ('81', '31', '1', '2130706433', 'admin_menu', '363', '超级管理员 编辑了节点：节点ID(363)', '1', '1587524976');
INSERT INTO `dp_admin_log` VALUES ('82', '32', '1', '2130706433', 'admin_menu', '363', '超级管理员 删除了节点：节点ID(363),节点标题(文章管理),节点链接(admin/aboutus/index)', '1', '1587525531');
INSERT INTO `dp_admin_log` VALUES ('83', '30', '1', '2130706433', 'admin_menu', '370', '超级管理员 添加了节点：所属模块(admin),所属节点ID(362),节点标题(文章管理),节点链接(admin/aboutus/index)', '1', '1587525565');
INSERT INTO `dp_admin_log` VALUES ('84', '22', '1', '2130706433', 'database', '0', '超级管理员 优化了数据表：dp_home_aboutus', '1', '1587526065');
INSERT INTO `dp_admin_log` VALUES ('85', '20', '1', '2130706433', 'database', '0', '超级管理员 备份了数据库：dp_admin_access,dp_admin_action,dp_admin_attachment,dp_admin_config,dp_admin_hook,dp_admin_hook_plugin,dp_admin_icon,dp_admin_icon_list,dp_admin_log,dp_admin_menu,dp_admin_message,dp_admin_module,dp_admin_navigation,dp_admin_packet,dp_admin_plugin,dp_admin_role,dp_admin_user,dp_cms_advert,dp_cms_advert_type,dp_cms_column,dp_cms_document,dp_cms_field,dp_cms_link,dp_cms_menu,dp_cms_model,dp_cms_nav,dp_cms_page,dp_cms_slider,dp_cms_support,dp_configuration,dp_home_aboutus,dp_home_album,dp_home_news', '1', '1587526084');
INSERT INTO `dp_admin_log` VALUES ('86', '31', '1', '2130706433', 'admin_menu', '1', '超级管理员 编辑了节点：节点ID(1)', '1', '1587536005');
INSERT INTO `dp_admin_log` VALUES ('87', '31', '1', '2130706433', 'admin_menu', '1', '超级管理员 编辑了节点：节点ID(1)', '1', '1587536164');
INSERT INTO `dp_admin_log` VALUES ('88', '31', '1', '2130706433', 'admin_menu', '1', '超级管理员 编辑了节点：节点ID(1)', '1', '1587537154');
INSERT INTO `dp_admin_log` VALUES ('89', '31', '1', '2130706433', 'admin_menu', '1', '超级管理员 编辑了节点：节点ID(1)', '1', '1587537872');
INSERT INTO `dp_admin_log` VALUES ('90', '30', '1', '2130706433', 'admin_menu', '377', '超级管理员 添加了节点：所属模块(admin),所属节点ID(362),节点标题(资深讲师),节点链接(admin/lecturer/index)', '1', '1587544832');
INSERT INTO `dp_admin_log` VALUES ('91', '32', '1', '2130706433', 'admin_menu', '239', '超级管理员 删除了节点：节点ID(239),节点标题(Banner图),节点链接(admin/menu/add)', '1', '1587614512');
INSERT INTO `dp_admin_log` VALUES ('92', '30', '1', '2130706433', 'admin_menu', '384', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(Banner背景图),节点链接(admin/BannerBg/index)', '1', '1587614557');
INSERT INTO `dp_admin_log` VALUES ('93', '31', '1', '2130706433', 'admin_menu', '384', '超级管理员 编辑了节点：节点ID(384)', '1', '1587614671');
INSERT INTO `dp_admin_log` VALUES ('94', '30', '1', '2130706433', 'admin_menu', '391', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(Banner图),节点链接(admin/Banner/index)', '1', '1587621514');
INSERT INTO `dp_admin_log` VALUES ('95', '32', '1', '2130706433', 'admin_menu', '338', '超级管理员 删除了节点：节点ID(338),节点标题(美食中心),节点链接()', '1', '1587631670');
INSERT INTO `dp_admin_log` VALUES ('96', '30', '1', '2130706433', 'admin_menu', '398', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(美食中心),节点链接(admin/food/index)', '1', '1587631711');
INSERT INTO `dp_admin_log` VALUES ('97', '32', '1', '2130706433', 'admin_menu', '339', '超级管理员 删除了节点：节点ID(339),节点标题(店铺实拍),节点链接()', '1', '1587695088');
INSERT INTO `dp_admin_log` VALUES ('98', '30', '1', '2130706433', 'admin_menu', '405', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(店铺实拍),节点链接(admin/store/index)', '1', '1587695259');
INSERT INTO `dp_admin_log` VALUES ('99', '32', '1', '2130706433', 'admin_menu', '340', '超级管理员 删除了节点：节点ID(340),节点标题(滚动图),节点链接()', '1', '1587695331');
INSERT INTO `dp_admin_log` VALUES ('100', '30', '1', '2130706433', 'admin_menu', '412', '超级管理员 添加了节点：所属模块(admin),所属节点ID(333),节点标题(滚动图),节点链接(admin/roll/index)', '1', '1587695405');
INSERT INTO `dp_admin_log` VALUES ('101', '30', '1', '2130706433', 'admin_menu', '419', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(品牌动态),节点链接()', '1', '1587705586');
INSERT INTO `dp_admin_log` VALUES ('102', '30', '1', '2130706433', 'admin_menu', '420', '超级管理员 添加了节点：所属模块(admin),所属节点ID(419),节点标题(新闻快讯),节点链接(admin/bulletin/index)', '1', '1587705664');
INSERT INTO `dp_admin_log` VALUES ('103', '30', '1', '2130706433', 'admin_menu', '427', '超级管理员 添加了节点：所属模块(admin),所属节点ID(419),节点标题(新闻资讯),节点链接(admin/news/index)', '1', '1587705725');
INSERT INTO `dp_admin_log` VALUES ('104', '16', '1', '2130706433', 'admin_config', '1', '超级管理员 编辑了配置：字段(status)，原值(1)，新值：(false)', '1', '1587709418');
INSERT INTO `dp_admin_log` VALUES ('105', '16', '1', '2130706433', 'admin_config', '1', '超级管理员 编辑了配置：字段(status)，原值(0)，新值：(true)', '1', '1587709419');
INSERT INTO `dp_admin_log` VALUES ('106', '16', '1', '2130706433', 'admin_config', '34', '超级管理员 编辑了配置：字段(status)，原值(1)，新值：(false)', '1', '1587710398');
INSERT INTO `dp_admin_log` VALUES ('107', '16', '1', '2130706433', 'admin_config', '34', '超级管理员 编辑了配置：字段(status)，原值(0)，新值：(true)', '1', '1587710399');
INSERT INTO `dp_admin_log` VALUES ('108', '16', '1', '2130706433', 'admin_config', '12', '超级管理员 编辑了配置：字段(status)，原值(1)，新值：(false)', '1', '1587710408');
INSERT INTO `dp_admin_log` VALUES ('109', '16', '1', '2130706433', 'admin_config', '12', '超级管理员 编辑了配置：字段(status)，原值(0)，新值：(true)', '1', '1587710409');
INSERT INTO `dp_admin_log` VALUES ('110', '31', '1', '2130706433', 'admin_menu', '1', '超级管理员 编辑了节点：节点ID(1)', '1', '1587780233');
INSERT INTO `dp_admin_log` VALUES ('111', '32', '1', '2130706433', 'admin_menu', '377', '超级管理员 删除了节点：节点ID(377),节点标题(资深讲师),节点链接(admin/lecturer/index)', '1', '1587783511');
INSERT INTO `dp_admin_log` VALUES ('112', '31', '1', '2130706433', 'admin_menu', '370', '超级管理员 编辑了节点：节点ID(370)', '1', '1587783538');
INSERT INTO `dp_admin_log` VALUES ('113', '31', '1', '2130706433', 'admin_menu', '370', '超级管理员 编辑了节点：节点ID(370)', '1', '1587783573');
INSERT INTO `dp_admin_log` VALUES ('114', '31', '1', '2130706433', 'admin_menu', '2', '超级管理员 编辑了节点：节点ID(2)', '1', '1587786571');
INSERT INTO `dp_admin_log` VALUES ('115', '31', '1', '2130706433', 'admin_menu', '3', '超级管理员 编辑了节点：节点ID(3)', '1', '1587786584');
INSERT INTO `dp_admin_log` VALUES ('116', '31', '1', '2130706433', 'admin_menu', '4', '超级管理员 编辑了节点：节点ID(4)', '1', '1587786597');
INSERT INTO `dp_admin_log` VALUES ('117', '31', '1', '2130706433', 'admin_menu', '5', '超级管理员 编辑了节点：节点ID(5)', '1', '1587786609');
INSERT INTO `dp_admin_log` VALUES ('118', '31', '1', '2130706433', 'admin_menu', '6', '超级管理员 编辑了节点：节点ID(6)', '1', '1587786621');
INSERT INTO `dp_admin_log` VALUES ('119', '31', '1', '2130706433', 'admin_menu', '7', '超级管理员 编辑了节点：节点ID(7)', '1', '1587786634');
INSERT INTO `dp_admin_log` VALUES ('120', '31', '1', '2130706433', 'admin_menu', '8', '超级管理员 编辑了节点：节点ID(8)', '1', '1587786644');
INSERT INTO `dp_admin_log` VALUES ('121', '31', '1', '2130706433', 'admin_menu', '2', '超级管理员 编辑了节点：节点ID(2)', '1', '1587786722');
INSERT INTO `dp_admin_log` VALUES ('122', '31', '1', '2130706433', 'admin_menu', '3', '超级管理员 编辑了节点：节点ID(3)', '1', '1587786748');
INSERT INTO `dp_admin_log` VALUES ('123', '31', '1', '2130706433', 'admin_menu', '4', '超级管理员 编辑了节点：节点ID(4)', '1', '1587802238');
INSERT INTO `dp_admin_log` VALUES ('124', '31', '1', '2130706433', 'admin_menu', '5', '超级管理员 编辑了节点：节点ID(5)', '1', '1587802253');
INSERT INTO `dp_admin_log` VALUES ('125', '30', '1', '2130706433', 'admin_menu', '434', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(美食中心),节点链接()', '1', '1587803620');
INSERT INTO `dp_admin_log` VALUES ('126', '30', '1', '2130706433', 'admin_menu', '435', '超级管理员 添加了节点：所属模块(admin),所属节点ID(434),节点标题(内容管理),节点链接(admin/fooda/index)', '1', '1587804027');
INSERT INTO `dp_admin_log` VALUES ('127', '30', '1', '2130706433', 'admin_menu', '442', '超级管理员 添加了节点：所属模块(admin),所属节点ID(434),节点标题(相册管理),节点链接(admin/foodb/index)', '1', '1587804074');
INSERT INTO `dp_admin_log` VALUES ('128', '30', '1', '2130706433', 'admin_menu', '449', '超级管理员 添加了节点：所属模块(admin),所属节点ID(434),节点标题(轮播图管理),节点链接(admin/foodc/index)', '1', '1587804138');
INSERT INTO `dp_admin_log` VALUES ('129', '31', '1', '2130706433', 'admin_menu', '442', '超级管理员 编辑了节点：节点ID(442)', '1', '1587804158');
INSERT INTO `dp_admin_log` VALUES ('130', '31', '1', '2130706433', 'admin_menu', '10', '超级管理员 编辑了节点：节点ID(10)', '1', '1587954540');
INSERT INTO `dp_admin_log` VALUES ('131', '31', '1', '2130706433', 'admin_menu', '9', '超级管理员 编辑了节点：节点ID(9)', '1', '1587954573');
INSERT INTO `dp_admin_log` VALUES ('132', '31', '1', '2130706433', 'admin_menu', '9', '超级管理员 编辑了节点：节点ID(9)', '1', '1587955840');
INSERT INTO `dp_admin_log` VALUES ('133', '30', '1', '2130706433', 'admin_menu', '456', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(店面风采),节点链接()', '1', '1587965724');
INSERT INTO `dp_admin_log` VALUES ('134', '30', '1', '2130706433', 'admin_menu', '457', '超级管理员 添加了节点：所属模块(admin),所属节点ID(456),节点标题(店铺形象),节点链接(admin/stores/index)', '1', '1587965897');
INSERT INTO `dp_admin_log` VALUES ('135', '32', '1', '2130706433', 'admin_menu', '420', '超级管理员 删除了节点：节点ID(420),节点标题(新闻快讯),节点链接(admin/bulletin/index)', '1', '1587977800');
INSERT INTO `dp_admin_log` VALUES ('136', '31', '1', '2130706433', 'admin_menu', '427', '超级管理员 编辑了节点：节点ID(427)', '1', '1587977841');
INSERT INTO `dp_admin_log` VALUES ('137', '31', '1', '2130706433', 'admin_menu', '28', '超级管理员 编辑了节点：节点ID(28)', '1', '1588037857');
INSERT INTO `dp_admin_log` VALUES ('138', '30', '1', '2130706433', 'admin_menu', '464', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(项目中心),节点链接()', '1', '1588052986');
INSERT INTO `dp_admin_log` VALUES ('139', '30', '1', '2130706433', 'admin_menu', '465', '超级管理员 添加了节点：所属模块(admin),所属节点ID(464),节点标题(媒体报道),节点链接(admin/media/index)', '1', '1588053093');
INSERT INTO `dp_admin_log` VALUES ('140', '42', '1', '2130706433', 'admin_config', '0', '超级管理员 更新了系统设置：分组(upload)', '1', '1588057315');
INSERT INTO `dp_admin_log` VALUES ('141', '30', '1', '2130706433', 'admin_menu', '472', '超级管理员 添加了节点：所属模块(admin),所属节点ID(50),节点标题(新增),节点链接(admin/attachment/add)', '1', '1588057665');
INSERT INTO `dp_admin_log` VALUES ('142', '31', '1', '2130706433', 'admin_menu', '472', '超级管理员 编辑了节点：节点ID(472)', '1', '1588057829');
INSERT INTO `dp_admin_log` VALUES ('143', '31', '1', '2130706433', 'admin_menu', '20', '超级管理员 编辑了节点：节点ID(20)', '1', '1588062637');
INSERT INTO `dp_admin_log` VALUES ('144', '30', '1', '2130706433', 'admin_menu', '473', '超级管理员 添加了节点：所属模块(admin),所属节点ID(464),节点标题(综合管理),节点链接(admin/project/index)', '1', '1588063728');
INSERT INTO `dp_admin_log` VALUES ('145', '31', '1', '2130706433', 'admin_menu', '22', '超级管理员 编辑了节点：节点ID(22)', '1', '1588064318');
INSERT INTO `dp_admin_log` VALUES ('146', '31', '1', '2130706433', 'admin_menu', '23', '超级管理员 编辑了节点：节点ID(23)', '1', '1588064341');
INSERT INTO `dp_admin_log` VALUES ('147', '30', '1', '2130706433', 'admin_menu', '480', '超级管理员 添加了节点：所属模块(admin),所属节点ID(464),节点标题(代理专区),节点链接(admin/agent/index)', '1', '1588127057');
INSERT INTO `dp_admin_log` VALUES ('148', '31', '1', '2130706433', 'admin_menu', '24', '超级管理员 编辑了节点：节点ID(24)', '1', '1588133223');
INSERT INTO `dp_admin_log` VALUES ('149', '30', '1', '2130706433', 'admin_menu', '487', '超级管理员 添加了节点：所属模块(admin),所属节点ID(464),节点标题(成功案例),节点链接(admin/cases/index)', '1', '1588137397');
INSERT INTO `dp_admin_log` VALUES ('150', '31', '1', '2130706433', 'admin_menu', '25', '超级管理员 编辑了节点：节点ID(25)', '1', '1588139335');
INSERT INTO `dp_admin_log` VALUES ('151', '31', '1', '2130706433', 'admin_menu', '26', '超级管理员 编辑了节点：节点ID(26)', '1', '1588141915');
INSERT INTO `dp_admin_log` VALUES ('152', '24', '1', '2130706433', 'database', '0', '超级管理员 删除了数据库备份：20200422-112804', '1', '1588142127');
INSERT INTO `dp_admin_log` VALUES ('153', '30', '1', '2130706433', 'admin_menu', '494', '超级管理员 添加了节点：所属模块(admin),所属节点ID(464),节点标题(自助投资分析),节点链接(admin/analysis/index)', '1', '1588143052');
INSERT INTO `dp_admin_log` VALUES ('154', '30', '1', '2130706433', 'admin_menu', '495', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(联系我们),节点链接()', '1', '1588150942');
INSERT INTO `dp_admin_log` VALUES ('155', '30', '1', '2130706433', 'admin_menu', '496', '超级管理员 添加了节点：所属模块(admin),所属节点ID(495),节点标题(联系方式),节点链接(admin/contactus/index)', '1', '1588150993');
INSERT INTO `dp_admin_log` VALUES ('156', '31', '1', '2130706433', 'admin_menu', '37', '超级管理员 编辑了节点：节点ID(37)', '1', '1588214038');
INSERT INTO `dp_admin_log` VALUES ('157', '31', '1', '2130706433', 'admin_menu', '31', '超级管理员 编辑了节点：节点ID(31)', '1', '1588224387');
INSERT INTO `dp_admin_log` VALUES ('158', '31', '1', '2130706433', 'admin_menu', '32', '超级管理员 编辑了节点：节点ID(32)', '1', '1588224431');
INSERT INTO `dp_admin_log` VALUES ('159', '31', '1', '2130706433', 'admin_menu', '33', '超级管理员 编辑了节点：节点ID(33)', '1', '1588224473');
INSERT INTO `dp_admin_log` VALUES ('160', '31', '1', '2130706433', 'admin_menu', '34', '超级管理员 编辑了节点：节点ID(34)', '1', '1588224532');
INSERT INTO `dp_admin_log` VALUES ('161', '20', '1', '2130706433', 'database', '0', '超级管理员 备份了数据库：dp_admin_access,dp_admin_action,dp_admin_attachment,dp_admin_config,dp_admin_hook,dp_admin_hook_plugin,dp_admin_icon,dp_admin_icon_list,dp_admin_log,dp_admin_menu,dp_admin_message,dp_admin_module,dp_admin_navigation,dp_admin_packet,dp_admin_plugin,dp_admin_role,dp_admin_user,dp_cms_advert,dp_cms_advert_type,dp_cms_column,dp_cms_document,dp_cms_field,dp_cms_link,dp_cms_menu,dp_cms_model,dp_cms_nav,dp_cms_page,dp_cms_slider,dp_cms_support,dp_configuration,dp_home_aboutus,dp_home_agent,dp_home_agent_img,dp_home_album,dp_home_analysis,dp_home_banner,dp_home_banner_bg,dp_home_bulletin,dp_home_cases,dp_home_contactus,dp_home_contactus_img,dp_home_food,dp_home_foods,dp_home_media,dp_home_media_img,dp_home_news,dp_home_project,dp_home_roll,dp_home_store,dp_home_stores', '1', '1588224802');
INSERT INTO `dp_admin_log` VALUES ('162', '20', '1', '2130706433', 'database', '0', '超级管理员 备份了数据库：dp_admin_access,dp_admin_action,dp_admin_attachment,dp_admin_config,dp_admin_hook,dp_admin_hook_plugin,dp_admin_icon,dp_admin_icon_list,dp_admin_log,dp_admin_menu,dp_admin_message,dp_admin_module,dp_admin_navigation,dp_admin_packet,dp_admin_plugin,dp_admin_role,dp_admin_user,dp_cms_advert,dp_cms_advert_type,dp_cms_column,dp_cms_document,dp_cms_field,dp_cms_link,dp_cms_menu,dp_cms_model,dp_cms_nav,dp_cms_page,dp_cms_slider,dp_cms_support,dp_configuration,dp_home_aboutus,dp_home_agent,dp_home_agent_img,dp_home_album,dp_home_analysis,dp_home_banner,dp_home_banner_bg,dp_home_cases,dp_home_contactus,dp_home_contactus_img,dp_home_food,dp_home_foods,dp_home_media,dp_home_media_img,dp_home_news,dp_home_project,dp_home_roll,dp_home_store,dp_home_stores', '1', '1588225568');
INSERT INTO `dp_admin_log` VALUES ('163', '24', '1', '2130706433', 'database', '0', '超级管理员 删除了数据库备份：20200430-133322', '1', '1588225589');
INSERT INTO `dp_admin_log` VALUES ('164', '30', '1', '2130706433', 'admin_menu', '503', '超级管理员 添加了节点：所属模块(admin),所属节点ID(1),节点标题(用户留言),节点链接()', '1', '1588525404');
INSERT INTO `dp_admin_log` VALUES ('165', '30', '1', '2130706433', 'admin_menu', '504', '超级管理员 添加了节点：所属模块(admin),所属节点ID(503),节点标题(在线申请),节点链接(admin/apply/index)', '1', '1588525933');
INSERT INTO `dp_admin_log` VALUES ('166', '30', '1', '2130706433', 'admin_menu', '511', '超级管理员 添加了节点：所属模块(admin),所属节点ID(504),节点标题(详情),节点链接(admin/apply/details)', '1', '1588527282');
INSERT INTO `dp_admin_log` VALUES ('167', '30', '1', '2130706433', 'admin_menu', '512', '超级管理员 添加了节点：所属模块(admin),所属节点ID(503),节点标题(自助投资分析),节点链接(admin/analysismessage/index)', '1', '1588555683');
INSERT INTO `dp_admin_log` VALUES ('168', '30', '1', '2130706433', 'admin_menu', '519', '超级管理员 添加了节点：所属模块(admin),所属节点ID(512),节点标题(详情),节点链接(admin/analysismessage/details)', '1', '1588555729');
INSERT INTO `dp_admin_log` VALUES ('169', '30', '1', '2130706433', 'admin_menu', '520', '超级管理员 添加了节点：所属模块(admin),所属节点ID(503),节点标题(在线留言),节点链接(admin/Contactusmessage/index)', '1', '1588555816');
INSERT INTO `dp_admin_log` VALUES ('170', '30', '1', '2130706433', 'admin_menu', '527', '超级管理员 添加了节点：所属模块(admin),所属节点ID(520),节点标题(详情),节点链接(admin/Contactusmessage/details)', '1', '1588555862');
INSERT INTO `dp_admin_log` VALUES ('171', '22', '1', '2130706433', 'database', '0', '超级管理员 优化了数据表：`dp_home_contactus`', '1', '1588753358');
INSERT INTO `dp_admin_log` VALUES ('172', '22', '1', '2130706433', 'database', '0', '超级管理员 优化了数据表：dp_home_media_img', '1', '1588753426');

-- -----------------------------
-- Table structure for `dp_admin_menu`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_menu`;
CREATE TABLE `dp_admin_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级菜单id',
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模块名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `url_type` varchar(16) NOT NULL DEFAULT '' COMMENT '链接类型（link：外链，module：模块）',
  `url_value` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `url_target` varchar(16) NOT NULL DEFAULT '_self' COMMENT '链接打开方式：_blank,_self',
  `online_hide` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '网站上线后是否隐藏',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `system_menu` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统菜单，系统菜单不可删除',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `params` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=528 DEFAULT CHARSET=utf8 COMMENT='后台菜单表';

-- -----------------------------
-- Records of `dp_admin_menu`
-- -----------------------------
INSERT INTO `dp_admin_menu` VALUES ('1', '0', 'admin', '首页', 'fa fa-fw fa-home', 'module_admin', 'admin/index/index', '_self', '0', '1467617722', '1477710540', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('2', '1', 'admin', '快捷操作', 'fa fa-fw fa-folder-open-o', 'module_admin', '', '_self', '0', '1467618170', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('3', '2', 'admin', '清空缓存', 'fa fa-fw fa-trash-o', 'module_admin', 'admin/index/wipecache', '_self', '0', '1467618273', '1588053007', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('4', '0', 'admin', '系统', 'fa fa-fw fa-gear', 'module_admin', 'admin/system/index', '_self', '0', '1467618361', '1477710540', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('5', '4', 'admin', '系统功能', 'si si-wrench', 'module_admin', '', '_self', '0', '1467618441', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('6', '5', 'admin', '系统设置', 'fa fa-fw fa-wrench', 'module_admin', 'admin/system/index', '_self', '0', '1467618490', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('7', '5', 'admin', '配置管理', 'fa fa-fw fa-gears', 'module_admin', 'admin/config/index', '_self', '0', '1467618618', '1588053007', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('8', '7', 'admin', '新增', '', 'module_admin', 'admin/config/add', '_self', '0', '1467618648', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('9', '7', 'admin', '编辑', '', 'module_admin', 'admin/config/edit', '_self', '0', '1467619566', '1588053007', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('10', '7', 'admin', '删除', '', 'module_admin', 'admin/config/delete', '_self', '0', '1467619583', '1588053007', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('11', '7', 'admin', '启用', '', 'module_admin', 'admin/config/enable', '_self', '0', '1467619609', '1588053007', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('12', '7', 'admin', '禁用', '', 'module_admin', 'admin/config/disable', '_self', '0', '1467619637', '1588053007', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('13', '5', 'admin', '节点管理', 'fa fa-fw fa-bars', 'module_admin', 'admin/menu/index', '_self', '0', '1467619882', '1588053007', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('14', '13', 'admin', '新增', '', 'module_admin', 'admin/menu/add', '_self', '0', '1467619902', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('15', '13', 'admin', '编辑', '', 'module_admin', 'admin/menu/edit', '_self', '0', '1467620331', '1588053007', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('16', '13', 'admin', '删除', '', 'module_admin', 'admin/menu/delete', '_self', '0', '1467620363', '1588053007', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('17', '13', 'admin', '启用', '', 'module_admin', 'admin/menu/enable', '_self', '0', '1467620386', '1588053007', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('18', '13', 'admin', '禁用', '', 'module_admin', 'admin/menu/disable', '_self', '0', '1467620404', '1588053007', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('19', '68', 'user', '权限管理', 'fa fa-fw fa-key', 'module_admin', '', '_self', '0', '1467688065', '1477710702', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('20', '19', 'user', '用户管理', 'fa fa-fw fa-user', 'module_admin', 'user/index/index', '_self', '0', '1467688137', '1477710702', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('21', '20', 'user', '新增', '', 'module_admin', 'user/index/add', '_self', '0', '1467688177', '1477710702', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('22', '20', 'user', '编辑', '', 'module_admin', 'user/index/edit', '_self', '0', '1467688202', '1477710702', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('23', '20', 'user', '删除', '', 'module_admin', 'user/index/delete', '_self', '0', '1467688219', '1477710702', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('24', '20', 'user', '启用', '', 'module_admin', 'user/index/enable', '_self', '0', '1467688238', '1477710702', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('25', '20', 'user', '禁用', '', 'module_admin', 'user/index/disable', '_self', '0', '1467688256', '1477710702', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('211', '64', 'admin', '日志详情', '', 'module_admin', 'admin/log/details', '_self', '0', '1480299320', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('32', '4', 'admin', '扩展中心', 'si si-social-dropbox', 'module_admin', '', '_self', '0', '1467688853', '1588053007', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('33', '32', 'admin', '模块管理', 'fa fa-fw fa-th-large', 'module_admin', 'admin/module/index', '_self', '0', '1467689008', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('34', '33', 'admin', '导入', '', 'module_admin', 'admin/module/import', '_self', '0', '1467689153', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('35', '33', 'admin', '导出', '', 'module_admin', 'admin/module/export', '_self', '0', '1467689173', '1588053007', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('36', '33', 'admin', '安装', '', 'module_admin', 'admin/module/install', '_self', '0', '1467689192', '1588053007', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('37', '33', 'admin', '卸载', '', 'module_admin', 'admin/module/uninstall', '_self', '0', '1467689241', '1588053007', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('38', '33', 'admin', '启用', '', 'module_admin', 'admin/module/enable', '_self', '0', '1467689294', '1588053007', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('39', '33', 'admin', '禁用', '', 'module_admin', 'admin/module/disable', '_self', '0', '1467689312', '1588053007', '6', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('40', '33', 'admin', '更新', '', 'module_admin', 'admin/module/update', '_self', '0', '1467689341', '1588053007', '7', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('41', '32', 'admin', '插件管理', 'fa fa-fw fa-puzzle-piece', 'module_admin', 'admin/plugin/index', '_self', '0', '1467689527', '1588053007', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('42', '41', 'admin', '导入', '', 'module_admin', 'admin/plugin/import', '_self', '0', '1467689650', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('43', '41', 'admin', '导出', '', 'module_admin', 'admin/plugin/export', '_self', '0', '1467689665', '1588053007', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('44', '41', 'admin', '安装', '', 'module_admin', 'admin/plugin/install', '_self', '0', '1467689680', '1588053007', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('45', '41', 'admin', '卸载', '', 'module_admin', 'admin/plugin/uninstall', '_self', '0', '1467689700', '1588053007', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('46', '41', 'admin', '启用', '', 'module_admin', 'admin/plugin/enable', '_self', '0', '1467689730', '1588053007', '5', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('47', '41', 'admin', '禁用', '', 'module_admin', 'admin/plugin/disable', '_self', '0', '1467689747', '1588053007', '6', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('48', '41', 'admin', '设置', '', 'module_admin', 'admin/plugin/config', '_self', '0', '1467689789', '1588053007', '7', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('49', '41', 'admin', '管理', '', 'module_admin', 'admin/plugin/manage', '_self', '0', '1467689846', '1588053007', '8', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('50', '5', 'admin', '附件管理', 'fa fa-fw fa-cloud-upload', 'module_admin', 'admin/attachment/index', '_self', '0', '1467690161', '1588053007', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('51', '70', 'admin', '文件上传', '', 'module_admin', 'admin/attachment/upload', '_self', '0', '1467690240', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('52', '50', 'admin', '下载', '', 'module_admin', 'admin/attachment/download', '_self', '0', '1467690334', '1588053007', '1', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('53', '50', 'admin', '启用', '', 'module_admin', 'admin/attachment/enable', '_self', '0', '1467690352', '1588053007', '2', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('54', '50', 'admin', '禁用', '', 'module_admin', 'admin/attachment/disable', '_self', '0', '1467690369', '1588053007', '3', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('55', '50', 'admin', '删除', '', 'module_admin', 'admin/attachment/delete', '_self', '0', '1467690396', '1588053007', '4', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('56', '41', 'admin', '删除', '', 'module_admin', 'admin/plugin/delete', '_self', '0', '1467858065', '1588053007', '11', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('57', '41', 'admin', '编辑', '', 'module_admin', 'admin/plugin/edit', '_self', '0', '1467858092', '1588053007', '10', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('60', '41', 'admin', '新增', '', 'module_admin', 'admin/plugin/add', '_self', '0', '1467858421', '1588053007', '9', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('61', '41', 'admin', '执行', '', 'module_admin', 'admin/plugin/execute', '_self', '0', '1467879016', '1588053007', '12', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('62', '13', 'admin', '保存', '', 'module_admin', 'admin/menu/save', '_self', '0', '1468073039', '1588053007', '6', '1', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('64', '5', 'admin', '系统日志', 'fa fa-fw fa-book', 'module_admin', 'admin/log/index', '_self', '0', '1476111944', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('65', '5', 'admin', '数据库管理', 'fa fa-fw fa-database', 'module_admin', 'admin/database/index', '_self', '0', '1476111992', '1588053007', '7', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('66', '32', 'admin', '数据包管理', 'fa fa-fw fa-database', 'module_admin', 'admin/packet/index', '_self', '0', '1476112326', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('67', '19', 'user', '角色管理', 'fa fa-fw fa-users', 'module_admin', 'user/role/index', '_self', '0', '1476113025', '1477710702', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('68', '0', 'user', '用户', 'fa fa-fw fa-user', 'module_admin', 'user/index/index', '_self', '0', '1476193348', '1477710540', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('69', '32', 'admin', '钩子管理', 'fa fa-fw fa-anchor', 'module_admin', 'admin/hook/index', '_self', '0', '1476236193', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('70', '2', 'admin', '后台首页', 'fa fa-fw fa-tachometer', 'module_admin', 'admin/index/index', '_self', '0', '1476237472', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('71', '67', 'user', '新增', '', 'module_admin', 'user/role/add', '_self', '0', '1476256935', '1477710702', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('72', '67', 'user', '编辑', '', 'module_admin', 'user/role/edit', '_self', '0', '1476256968', '1477710702', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('73', '67', 'user', '删除', '', 'module_admin', 'user/role/delete', '_self', '0', '1476256993', '1477710702', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('74', '67', 'user', '启用', '', 'module_admin', 'user/role/enable', '_self', '0', '1476257023', '1477710702', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('75', '67', 'user', '禁用', '', 'module_admin', 'user/role/disable', '_self', '0', '1476257046', '1477710702', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('76', '20', 'user', '授权', '', 'module_admin', 'user/index/access', '_self', '0', '1476375187', '1477710702', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('77', '69', 'admin', '新增', '', 'module_admin', 'admin/hook/add', '_self', '0', '1476668971', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('78', '69', 'admin', '编辑', '', 'module_admin', 'admin/hook/edit', '_self', '0', '1476669006', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('79', '69', 'admin', '删除', '', 'module_admin', 'admin/hook/delete', '_self', '0', '1476669375', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('80', '69', 'admin', '启用', '', 'module_admin', 'admin/hook/enable', '_self', '0', '1476669427', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('81', '69', 'admin', '禁用', '', 'module_admin', 'admin/hook/disable', '_self', '0', '1476669564', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('183', '66', 'admin', '安装', '', 'module_admin', 'admin/packet/install', '_self', '0', '1476851362', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('184', '66', 'admin', '卸载', '', 'module_admin', 'admin/packet/uninstall', '_self', '0', '1476851382', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('185', '5', 'admin', '行为管理', 'fa fa-fw fa-bug', 'module_admin', 'admin/action/index', '_self', '0', '1476882441', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('186', '185', 'admin', '新增', '', 'module_admin', 'admin/action/add', '_self', '0', '1476884439', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('187', '185', 'admin', '编辑', '', 'module_admin', 'admin/action/edit', '_self', '0', '1476884464', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('188', '185', 'admin', '启用', '', 'module_admin', 'admin/action/enable', '_self', '0', '1476884493', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('189', '185', 'admin', '禁用', '', 'module_admin', 'admin/action/disable', '_self', '0', '1476884534', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('190', '185', 'admin', '删除', '', 'module_admin', 'admin/action/delete', '_self', '0', '1476884551', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('191', '65', 'admin', '备份数据库', '', 'module_admin', 'admin/database/export', '_self', '0', '1476972746', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('192', '65', 'admin', '还原数据库', '', 'module_admin', 'admin/database/import', '_self', '0', '1476972772', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('193', '65', 'admin', '优化表', '', 'module_admin', 'admin/database/optimize', '_self', '0', '1476972800', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('194', '65', 'admin', '修复表', '', 'module_admin', 'admin/database/repair', '_self', '0', '1476972825', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('195', '65', 'admin', '删除备份', '', 'module_admin', 'admin/database/delete', '_self', '0', '1476973457', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('210', '41', 'admin', '快速编辑', '', 'module_admin', 'admin/plugin/quickedit', '_self', '0', '1477713981', '1588053007', '13', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('209', '185', 'admin', '快速编辑', '', 'module_admin', 'admin/action/quickedit', '_self', '0', '1477713939', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('208', '7', 'admin', '快速编辑', '', 'module_admin', 'admin/config/quickedit', '_self', '0', '1477713808', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('207', '69', 'admin', '快速编辑', '', 'module_admin', 'admin/hook/quickedit', '_self', '0', '1477713770', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('212', '2', 'admin', '个人设置', 'fa fa-fw fa-user', 'module_admin', 'admin/index/profile', '_self', '0', '1489049767', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('213', '70', 'admin', '检查版本更新', '', 'module_admin', 'admin/index/checkupdate', '_self', '0', '1490588610', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('214', '68', 'user', '消息管理', 'fa fa-fw fa-comments-o', 'module_admin', '', '_self', '0', '1520492129', '1520492129', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('215', '214', 'user', '消息列表', 'fa fa-fw fa-th-list', 'module_admin', 'user/message/index', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('216', '215', 'user', '新增', '', 'module_admin', 'user/message/add', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('217', '215', 'user', '编辑', '', 'module_admin', 'user/message/edit', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('218', '215', 'user', '删除', '', 'module_admin', 'user/message/delete', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('219', '215', 'user', '启用', '', 'module_admin', 'user/message/enable', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('220', '215', 'user', '禁用', '', 'module_admin', 'user/message/disable', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('221', '215', 'user', '快速编辑', '', 'module_admin', 'user/message/quickedit', '_self', '0', '1520492195', '1520492195', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('222', '2', 'admin', '消息中心', 'fa fa-fw fa-comments-o', 'module_admin', 'admin/message/index', '_self', '0', '1520495992', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('223', '222', 'admin', '删除', '', 'module_admin', 'admin/message/delete', '_self', '0', '1520495992', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('224', '222', 'admin', '启用', '', 'module_admin', 'admin/message/enable', '_self', '0', '1520495992', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('225', '32', 'admin', '图标管理', 'fa fa-fw fa-tint', 'module_admin', 'admin/icon/index', '_self', '0', '1520908295', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('226', '225', 'admin', '新增', '', 'module_admin', 'admin/icon/add', '_self', '0', '1520908295', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('227', '225', 'admin', '编辑', '', 'module_admin', 'admin/icon/edit', '_self', '0', '1520908295', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('228', '225', 'admin', '删除', '', 'module_admin', 'admin/icon/delete', '_self', '0', '1520908295', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('229', '225', 'admin', '启用', '', 'module_admin', 'admin/icon/enable', '_self', '0', '1520908295', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('230', '225', 'admin', '禁用', '', 'module_admin', 'admin/icon/disable', '_self', '0', '1520908295', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('231', '225', 'admin', '快速编辑', '', 'module_admin', 'admin/icon/quickedit', '_self', '0', '1520908295', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('232', '225', 'admin', '图标列表', '', 'module_admin', 'admin/icon/items', '_self', '0', '1520923368', '1588053007', '7', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('233', '225', 'admin', '更新图标', '', 'module_admin', 'admin/icon/reload', '_self', '0', '1520931908', '1588053007', '8', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('234', '20', 'user', '快速编辑', '', 'module_admin', 'user/index/quickedit', '_self', '0', '1526028258', '1526028258', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('235', '67', 'user', '快速编辑', '', 'module_admin', 'user/role/quickedit', '_self', '0', '1526028282', '1526028282', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('236', '6', 'admin', '快速编辑', '', 'module_admin', 'admin/system/quickedit', '_self', '0', '1559054310', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('237', '1', 'admin', '公共管理', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1587363322', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('384', '333', 'admin', 'Banner背景图', 'fa fa-fw fa-photo', 'module_admin', 'admin/bannerbg/index', '_self', '0', '1587614557', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('240', '0', 'cms', '门户', 'fa fa-fw fa-newspaper-o', 'module_admin', 'cms/index/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('241', '240', 'cms', '常用操作', 'fa fa-fw fa-folder-open-o', 'module_admin', '', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('242', '241', 'cms', '仪表盘', 'fa fa-fw fa-tachometer', 'module_admin', 'cms/index/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('243', '241', 'cms', '发布文档', 'fa fa-fw fa-plus', 'module_admin', 'cms/document/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('244', '241', 'cms', '文档列表', 'fa fa-fw fa-list', 'module_admin', 'cms/document/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('245', '244', 'cms', '编辑', '', 'module_admin', 'cms/document/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('246', '244', 'cms', '删除', '', 'module_admin', 'cms/document/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('247', '244', 'cms', '启用', '', 'module_admin', 'cms/document/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('248', '244', 'cms', '禁用', '', 'module_admin', 'cms/document/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('249', '244', 'cms', '快速编辑', '', 'module_admin', 'cms/document/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('250', '241', 'cms', '单页管理', 'fa fa-fw fa-file-word-o', 'module_admin', 'cms/page/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('251', '250', 'cms', '新增', '', 'module_admin', 'cms/page/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('252', '250', 'cms', '编辑', '', 'module_admin', 'cms/page/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('253', '250', 'cms', '删除', '', 'module_admin', 'cms/page/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('254', '250', 'cms', '启用', '', 'module_admin', 'cms/page/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('255', '250', 'cms', '禁用', '', 'module_admin', 'cms/page/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('256', '250', 'cms', '快速编辑', '', 'module_admin', 'cms/page/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('257', '241', 'cms', '回收站', 'fa fa-fw fa-recycle', 'module_admin', 'cms/recycle/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('258', '257', 'cms', '删除', '', 'module_admin', 'cms/recycle/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('259', '257', 'cms', '还原', '', 'module_admin', 'cms/recycle/restore', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('260', '240', 'cms', '内容管理', 'fa fa-fw fa-th-list', 'module_admin', '', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('261', '240', 'cms', '营销管理', 'fa fa-fw fa-money', 'module_admin', '', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('262', '261', 'cms', '广告管理', 'fa fa-fw fa-handshake-o', 'module_admin', 'cms/advert/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('263', '262', 'cms', '新增', '', 'module_admin', 'cms/advert/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('264', '262', 'cms', '编辑', '', 'module_admin', 'cms/advert/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('265', '262', 'cms', '删除', '', 'module_admin', 'cms/advert/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('266', '262', 'cms', '启用', '', 'module_admin', 'cms/advert/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('267', '262', 'cms', '禁用', '', 'module_admin', 'cms/advert/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('268', '262', 'cms', '快速编辑', '', 'module_admin', 'cms/advert/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('269', '262', 'cms', '广告分类', '', 'module_admin', 'cms/advert_type/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('270', '269', 'cms', '新增', '', 'module_admin', 'cms/advert_type/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('271', '269', 'cms', '编辑', '', 'module_admin', 'cms/advert_type/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('272', '269', 'cms', '删除', '', 'module_admin', 'cms/advert_type/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('273', '269', 'cms', '启用', '', 'module_admin', 'cms/advert_type/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('274', '269', 'cms', '禁用', '', 'module_admin', 'cms/advert_type/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('275', '269', 'cms', '快速编辑', '', 'module_admin', 'cms/advert_type/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('276', '261', 'cms', '滚动图片', 'fa fa-fw fa-photo', 'module_admin', 'cms/slider/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('277', '276', 'cms', '新增', '', 'module_admin', 'cms/slider/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('278', '276', 'cms', '编辑', '', 'module_admin', 'cms/slider/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('279', '276', 'cms', '删除', '', 'module_admin', 'cms/slider/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('280', '276', 'cms', '启用', '', 'module_admin', 'cms/slider/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('281', '276', 'cms', '禁用', '', 'module_admin', 'cms/slider/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('282', '276', 'cms', '快速编辑', '', 'module_admin', 'cms/slider/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('283', '261', 'cms', '友情链接', 'fa fa-fw fa-link', 'module_admin', 'cms/link/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('284', '283', 'cms', '新增', '', 'module_admin', 'cms/link/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('285', '283', 'cms', '编辑', '', 'module_admin', 'cms/link/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('286', '283', 'cms', '删除', '', 'module_admin', 'cms/link/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('287', '283', 'cms', '启用', '', 'module_admin', 'cms/link/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('288', '283', 'cms', '禁用', '', 'module_admin', 'cms/link/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('289', '283', 'cms', '快速编辑', '', 'module_admin', 'cms/link/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('290', '261', 'cms', '客服管理', 'fa fa-fw fa-commenting', 'module_admin', 'cms/support/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('291', '290', 'cms', '新增', '', 'module_admin', 'cms/support/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('292', '290', 'cms', '编辑', '', 'module_admin', 'cms/support/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('293', '290', 'cms', '删除', '', 'module_admin', 'cms/support/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('294', '290', 'cms', '启用', '', 'module_admin', 'cms/support/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('295', '290', 'cms', '禁用', '', 'module_admin', 'cms/support/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('296', '290', 'cms', '快速编辑', '', 'module_admin', 'cms/support/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('297', '240', 'cms', '门户设置', 'fa fa-fw fa-sliders', 'module_admin', '', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('298', '297', 'cms', '栏目分类', 'fa fa-fw fa-sitemap', 'module_admin', 'cms/column/index', '_self', '1', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('299', '298', 'cms', '新增', '', 'module_admin', 'cms/column/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('300', '298', 'cms', '编辑', '', 'module_admin', 'cms/column/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('301', '298', 'cms', '删除', '', 'module_admin', 'cms/column/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('302', '298', 'cms', '启用', '', 'module_admin', 'cms/column/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('303', '298', 'cms', '禁用', '', 'module_admin', 'cms/column/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('304', '298', 'cms', '快速编辑', '', 'module_admin', 'cms/column/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('305', '297', 'cms', '内容模型', 'fa fa-fw fa-th-large', 'module_admin', 'cms/model/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('306', '305', 'cms', '新增', '', 'module_admin', 'cms/model/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('307', '305', 'cms', '编辑', '', 'module_admin', 'cms/model/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('308', '305', 'cms', '删除', '', 'module_admin', 'cms/model/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('309', '305', 'cms', '启用', '', 'module_admin', 'cms/model/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('310', '305', 'cms', '禁用', '', 'module_admin', 'cms/model/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('311', '305', 'cms', '快速编辑', '', 'module_admin', 'cms/model/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('312', '305', 'cms', '字段管理', '', 'module_admin', 'cms/field/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('313', '312', 'cms', '新增', '', 'module_admin', 'cms/field/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('314', '312', 'cms', '编辑', '', 'module_admin', 'cms/field/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('315', '312', 'cms', '删除', '', 'module_admin', 'cms/field/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('316', '312', 'cms', '启用', '', 'module_admin', 'cms/field/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('317', '312', 'cms', '禁用', '', 'module_admin', 'cms/field/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('318', '312', 'cms', '快速编辑', '', 'module_admin', 'cms/field/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('319', '297', 'cms', '导航管理', 'fa fa-fw fa-map-signs', 'module_admin', 'cms/nav/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('320', '319', 'cms', '新增', '', 'module_admin', 'cms/nav/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('321', '319', 'cms', '编辑', '', 'module_admin', 'cms/nav/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('322', '319', 'cms', '删除', '', 'module_admin', 'cms/nav/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('323', '319', 'cms', '启用', '', 'module_admin', 'cms/nav/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('324', '319', 'cms', '禁用', '', 'module_admin', 'cms/nav/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('325', '319', 'cms', '快速编辑', '', 'module_admin', 'cms/nav/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('326', '319', 'cms', '菜单管理', '', 'module_admin', 'cms/menu/index', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('327', '326', 'cms', '新增', '', 'module_admin', 'cms/menu/add', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('328', '326', 'cms', '编辑', '', 'module_admin', 'cms/menu/edit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('329', '326', 'cms', '删除', '', 'module_admin', 'cms/menu/delete', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('330', '326', 'cms', '启用', '', 'module_admin', 'cms/menu/enable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('331', '326', 'cms', '禁用', '', 'module_admin', 'cms/menu/disable', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('332', '326', 'cms', '快速编辑', '', 'module_admin', 'cms/menu/quickedit', '_self', '0', '1587373198', '1587373198', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('333', '1', 'admin', '官网首页', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1587432398', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('334', '237', 'admin', '公共配置', 'fa fa-fw fa-list', 'module_admin', 'admin/configuration/index', '_self', '0', '1587432465', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('348', '333', 'admin', '相册', 'fa fa-fw fa-photo', 'module_admin', 'admin/album/index', '_self', '0', '1587452031', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('336', '333', 'admin', '轮播图', 'fa fa-fw fa-photo', 'module_admin', '', '_self', '0', '1587432799', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('355', '333', 'admin', 'NEWS', 'fa fa-fw fa-list-alt', 'module_admin', 'admin/news/index', '_self', '0', '1587519050', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('398', '333', 'admin', '美食中心', 'fa fa-fw fa-photo', 'module_admin', 'admin/food/index', '_self', '0', '1587631712', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('405', '333', 'admin', '店铺实拍', 'fa fa-fw fa-photo', 'module_admin', 'admin/store/index', '_self', '0', '1587695259', '1588053007', '7', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('412', '333', 'admin', '滚动图', 'fa fa-fw fa-photo', 'module_admin', 'admin/roll/index', '_self', '0', '1587695405', '1588053007', '8', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('341', '237', 'admin', '导航栏', 'fa fa-fw fa-list', 'module_admin', 'admin/navigation/index', '_self', '0', '1587436941', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('342', '341', 'admin', '新增', '', 'module_admin', 'admin/navigation/add', '_self', '0', '1587436941', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('343', '341', 'admin', '编辑', '', 'module_admin', 'admin/navigation/edit', '_self', '0', '1587436941', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('344', '341', 'admin', '删除', '', 'module_admin', 'admin/navigation/delete', '_self', '0', '1587436941', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('345', '341', 'admin', '启用', '', 'module_admin', 'admin/navigation/enable', '_self', '0', '1587436941', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('346', '341', 'admin', '禁用', '', 'module_admin', 'admin/navigation/disable', '_self', '0', '1587436941', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('347', '341', 'admin', '快速编辑', '', 'module_admin', 'admin/navigation/quickedit', '_self', '0', '1587436941', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('349', '348', 'admin', '新增', '', 'module_admin', 'admin/album/add', '_self', '0', '1587452030', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('350', '348', 'admin', '编辑', '', 'module_admin', 'admin/album/edit', '_self', '0', '1587452030', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('351', '348', 'admin', '删除', '', 'module_admin', 'admin/album/delete', '_self', '0', '1587452030', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('352', '348', 'admin', '启用', '', 'module_admin', 'admin/album/enable', '_self', '0', '1587452030', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('353', '348', 'admin', '禁用', '', 'module_admin', 'admin/album/disable', '_self', '0', '1587452030', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('354', '348', 'admin', '快速编辑', '', 'module_admin', 'admin/album/quickedit', '_self', '0', '1587452030', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('356', '355', 'admin', '新增', '', 'module_admin', 'admin/news/add', '_self', '0', '1587519049', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('357', '355', 'admin', '编辑', '', 'module_admin', 'admin/news/edit', '_self', '0', '1587519049', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('358', '355', 'admin', '删除', '', 'module_admin', 'admin/news/delete', '_self', '0', '1587519049', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('359', '355', 'admin', '启用', '', 'module_admin', 'admin/news/enable', '_self', '0', '1587519049', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('360', '355', 'admin', '禁用', '', 'module_admin', 'admin/news/disable', '_self', '0', '1587519049', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('361', '355', 'admin', '快速编辑', '', 'module_admin', 'admin/news/quickedit', '_self', '0', '1587519049', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('362', '1', 'admin', '关于我们', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1587522724', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('374', '370', 'admin', '启用', '', 'module_admin', 'admin/aboutus/enable', '_self', '0', '1587525565', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('373', '370', 'admin', '删除', '', 'module_admin', 'admin/aboutus/delete', '_self', '0', '1587525565', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('372', '370', 'admin', '编辑', '', 'module_admin', 'admin/aboutus/edit', '_self', '0', '1587525565', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('371', '370', 'admin', '新增', '', 'module_admin', 'admin/aboutus/add', '_self', '0', '1587525565', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('370', '362', 'admin', '综合管理', 'fa fa-fw fa-list', 'module_admin', 'admin/aboutus/index', '_self', '0', '1587525565', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('375', '370', 'admin', '禁用', '', 'module_admin', 'admin/aboutus/disable', '_self', '0', '1587525565', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('376', '370', 'admin', '快速编辑', '', 'module_admin', 'admin/aboutus/quickedit', '_self', '0', '1587525565', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('439', '435', 'admin', '启用', '', 'module_admin', 'admin/fooda/enable', '_self', '0', '1587804027', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('438', '435', 'admin', '删除', '', 'module_admin', 'admin/fooda/delete', '_self', '0', '1587804027', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('437', '435', 'admin', '编辑', '', 'module_admin', 'admin/fooda/edit', '_self', '0', '1587804027', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('436', '435', 'admin', '新增', '', 'module_admin', 'admin/fooda/add', '_self', '0', '1587804027', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('435', '434', 'admin', '内容管理', 'fa fa-fw fa-photo', 'module_admin', 'admin/fooda/index', '_self', '0', '1587804027', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('434', '1', 'admin', '美食中心', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1587803620', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('385', '384', 'admin', '新增', '', 'module_admin', 'admin/BannerBg/add', '_self', '0', '1587614557', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('386', '384', 'admin', '编辑', '', 'module_admin', 'admin/BannerBg/edit', '_self', '0', '1587614557', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('387', '384', 'admin', '删除', '', 'module_admin', 'admin/BannerBg/delete', '_self', '0', '1587614557', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('388', '384', 'admin', '启用', '', 'module_admin', 'admin/BannerBg/enable', '_self', '0', '1587614557', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('389', '384', 'admin', '禁用', '', 'module_admin', 'admin/BannerBg/disable', '_self', '0', '1587614557', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('390', '384', 'admin', '快速编辑', '', 'module_admin', 'admin/BannerBg/quickedit', '_self', '0', '1587614557', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('391', '333', 'admin', 'Banner图', 'fa fa-fw fa-photo', 'module_admin', 'admin/banner/index', '_self', '0', '1587621514', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('392', '391', 'admin', '新增', '', 'module_admin', 'admin/Banner/add', '_self', '0', '1587621514', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('393', '391', 'admin', '编辑', '', 'module_admin', 'admin/Banner/edit', '_self', '0', '1587621514', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('394', '391', 'admin', '删除', '', 'module_admin', 'admin/Banner/delete', '_self', '0', '1587621514', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('395', '391', 'admin', '启用', '', 'module_admin', 'admin/Banner/enable', '_self', '0', '1587621514', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('396', '391', 'admin', '禁用', '', 'module_admin', 'admin/Banner/disable', '_self', '0', '1587621514', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('397', '391', 'admin', '快速编辑', '', 'module_admin', 'admin/Banner/quickedit', '_self', '0', '1587621514', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('399', '398', 'admin', '新增', '', 'module_admin', 'admin/food/add', '_self', '0', '1587631711', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('400', '398', 'admin', '编辑', '', 'module_admin', 'admin/food/edit', '_self', '0', '1587631711', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('401', '398', 'admin', '删除', '', 'module_admin', 'admin/food/delete', '_self', '0', '1587631711', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('402', '398', 'admin', '启用', '', 'module_admin', 'admin/food/enable', '_self', '0', '1587631711', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('403', '398', 'admin', '禁用', '', 'module_admin', 'admin/food/disable', '_self', '0', '1587631711', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('404', '398', 'admin', '快速编辑', '', 'module_admin', 'admin/food/quickedit', '_self', '0', '1587631711', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('406', '405', 'admin', '新增', '', 'module_admin', 'admin/store/add', '_self', '0', '1587695259', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('407', '405', 'admin', '编辑', '', 'module_admin', 'admin/store/edit', '_self', '0', '1587695259', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('408', '405', 'admin', '删除', '', 'module_admin', 'admin/store/delete', '_self', '0', '1587695259', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('409', '405', 'admin', '启用', '', 'module_admin', 'admin/store/enable', '_self', '0', '1587695259', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('410', '405', 'admin', '禁用', '', 'module_admin', 'admin/store/disable', '_self', '0', '1587695259', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('411', '405', 'admin', '快速编辑', '', 'module_admin', 'admin/store/quickedit', '_self', '0', '1587695259', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('413', '412', 'admin', '新增', '', 'module_admin', 'admin/roll/add', '_self', '0', '1587695405', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('414', '412', 'admin', '编辑', '', 'module_admin', 'admin/roll/edit', '_self', '0', '1587695405', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('415', '412', 'admin', '删除', '', 'module_admin', 'admin/roll/delete', '_self', '0', '1587695405', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('416', '412', 'admin', '启用', '', 'module_admin', 'admin/roll/enable', '_self', '0', '1587695405', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('417', '412', 'admin', '禁用', '', 'module_admin', 'admin/roll/disable', '_self', '0', '1587695405', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('418', '412', 'admin', '快速编辑', '', 'module_admin', 'admin/roll/quickedit', '_self', '0', '1587695405', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('419', '1', 'admin', '品牌动态', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1587705586', '1588053007', '8', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('469', '465', 'admin', '启用', '', 'module_admin', 'admin/media/enable', '_self', '0', '1588053093', '1588053093', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('468', '465', 'admin', '删除', '', 'module_admin', 'admin/media/delete', '_self', '0', '1588053093', '1588053093', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('467', '465', 'admin', '编辑', '', 'module_admin', 'admin/media/edit', '_self', '0', '1588053093', '1588053093', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('466', '465', 'admin', '新增', '', 'module_admin', 'admin/media/add', '_self', '0', '1588053093', '1588053093', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('465', '464', 'admin', '媒体报道', 'fa fa-fw fa-list', 'module_admin', 'admin/media/index', '_self', '0', '1588053093', '1588053093', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('464', '1', 'admin', '项目中心', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1588052986', '1588053007', '7', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('427', '419', 'admin', '文章管理', 'fa fa-fw fa-list', 'module_admin', 'admin/news/index', '_self', '0', '1587705726', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('428', '427', 'admin', '新增', '', 'module_admin', 'admin/news/add', '_self', '0', '1587705725', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('429', '427', 'admin', '编辑', '', 'module_admin', 'admin/news/edit', '_self', '0', '1587705725', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('430', '427', 'admin', '删除', '', 'module_admin', 'admin/news/delete', '_self', '0', '1587705725', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('431', '427', 'admin', '启用', '', 'module_admin', 'admin/news/enable', '_self', '0', '1587705725', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('432', '427', 'admin', '禁用', '', 'module_admin', 'admin/news/disable', '_self', '0', '1587705725', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('433', '427', 'admin', '快速编辑', '', 'module_admin', 'admin/news/quickedit', '_self', '0', '1587705725', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('440', '435', 'admin', '禁用', '', 'module_admin', 'admin/fooda/disable', '_self', '0', '1587804027', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('441', '435', 'admin', '快速编辑', '', 'module_admin', 'admin/fooda/quickedit', '_self', '0', '1587804027', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('442', '434', 'admin', '相册管理', 'fa fa-fw fa-photo', 'module_admin', 'admin/foodb/index', '_self', '0', '1587804074', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('443', '442', 'admin', '新增', '', 'module_admin', 'admin/foodb/add', '_self', '0', '1587804074', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('444', '442', 'admin', '编辑', '', 'module_admin', 'admin/foodb/edit', '_self', '0', '1587804074', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('445', '442', 'admin', '删除', '', 'module_admin', 'admin/foodb/delete', '_self', '0', '1587804074', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('446', '442', 'admin', '启用', '', 'module_admin', 'admin/foodb/enable', '_self', '0', '1587804074', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('447', '442', 'admin', '禁用', '', 'module_admin', 'admin/foodb/disable', '_self', '0', '1587804074', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('448', '442', 'admin', '快速编辑', '', 'module_admin', 'admin/foodb/quickedit', '_self', '0', '1587804074', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('449', '434', 'admin', '轮播图管理', 'fa fa-fw fa-photo', 'module_admin', 'admin/foodc/index', '_self', '0', '1587804138', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('450', '449', 'admin', '新增', '', 'module_admin', 'admin/foodc/add', '_self', '0', '1587804138', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('451', '449', 'admin', '编辑', '', 'module_admin', 'admin/foodc/edit', '_self', '0', '1587804138', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('452', '449', 'admin', '删除', '', 'module_admin', 'admin/foodc/delete', '_self', '0', '1587804138', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('453', '449', 'admin', '启用', '', 'module_admin', 'admin/foodc/enable', '_self', '0', '1587804138', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('454', '449', 'admin', '禁用', '', 'module_admin', 'admin/foodc/disable', '_self', '0', '1587804138', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('455', '449', 'admin', '快速编辑', '', 'module_admin', 'admin/foodc/quickedit', '_self', '0', '1587804138', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('456', '1', 'admin', '店面风采', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1587965724', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('457', '456', 'admin', '店铺形象', 'fa fa-fw fa-list', 'module_admin', 'admin/stores/index', '_self', '0', '1587965897', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('458', '457', 'admin', '新增', '', 'module_admin', 'admin/stores/add', '_self', '0', '1587965897', '1588053007', '1', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('459', '457', 'admin', '编辑', '', 'module_admin', 'admin/stores/edit', '_self', '0', '1587965897', '1588053007', '2', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('460', '457', 'admin', '删除', '', 'module_admin', 'admin/stores/delete', '_self', '0', '1587965897', '1588053007', '3', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('461', '457', 'admin', '启用', '', 'module_admin', 'admin/stores/enable', '_self', '0', '1587965897', '1588053007', '4', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('462', '457', 'admin', '禁用', '', 'module_admin', 'admin/stores/disable', '_self', '0', '1587965897', '1588053007', '5', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('463', '457', 'admin', '快速编辑', '', 'module_admin', 'admin/stores/quickedit', '_self', '0', '1587965897', '1588053007', '6', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('470', '465', 'admin', '禁用', '', 'module_admin', 'admin/media/disable', '_self', '0', '1588053093', '1588053093', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('471', '465', 'admin', '快速编辑', '', 'module_admin', 'admin/media/quickedit', '_self', '0', '1588053093', '1588053093', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('472', '50', 'admin', '上传', '', 'module_admin', 'admin/attachment/upload', '_self', '0', '1588057665', '1588057829', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('473', '464', 'admin', '综合管理', 'fa fa-fw fa-list', 'module_admin', 'admin/project/index', '_self', '0', '1588063728', '1588063728', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('474', '473', 'admin', '新增', '', 'module_admin', 'admin/project/add', '_self', '0', '1588063728', '1588063728', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('475', '473', 'admin', '编辑', '', 'module_admin', 'admin/project/edit', '_self', '0', '1588063728', '1588063728', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('476', '473', 'admin', '删除', '', 'module_admin', 'admin/project/delete', '_self', '0', '1588063728', '1588063728', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('477', '473', 'admin', '启用', '', 'module_admin', 'admin/project/enable', '_self', '0', '1588063728', '1588063728', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('478', '473', 'admin', '禁用', '', 'module_admin', 'admin/project/disable', '_self', '0', '1588063728', '1588063728', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('479', '473', 'admin', '快速编辑', '', 'module_admin', 'admin/project/quickedit', '_self', '0', '1588063728', '1588063728', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('480', '464', 'admin', '代理专区', 'fa fa-fw fa-list', 'module_admin', 'admin/agent/index', '_self', '0', '1588127057', '1588127057', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('481', '480', 'admin', '新增', '', 'module_admin', 'admin/agent/add', '_self', '0', '1588127057', '1588127057', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('482', '480', 'admin', '编辑', '', 'module_admin', 'admin/agent/edit', '_self', '0', '1588127057', '1588127057', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('483', '480', 'admin', '删除', '', 'module_admin', 'admin/agent/delete', '_self', '0', '1588127057', '1588127057', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('484', '480', 'admin', '启用', '', 'module_admin', 'admin/agent/enable', '_self', '0', '1588127057', '1588127057', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('485', '480', 'admin', '禁用', '', 'module_admin', 'admin/agent/disable', '_self', '0', '1588127057', '1588127057', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('486', '480', 'admin', '快速编辑', '', 'module_admin', 'admin/agent/quickedit', '_self', '0', '1588127057', '1588127057', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('487', '464', 'admin', '成功案例', 'fa fa-fw fa-list', 'module_admin', 'admin/cases/index', '_self', '0', '1588137397', '1588137397', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('488', '487', 'admin', '新增', '', 'module_admin', 'admin/cases/add', '_self', '0', '1588137397', '1588137397', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('489', '487', 'admin', '编辑', '', 'module_admin', 'admin/cases/edit', '_self', '0', '1588137397', '1588137397', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('490', '487', 'admin', '删除', '', 'module_admin', 'admin/cases/delete', '_self', '0', '1588137397', '1588137397', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('491', '487', 'admin', '启用', '', 'module_admin', 'admin/cases/enable', '_self', '0', '1588137397', '1588137397', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('492', '487', 'admin', '禁用', '', 'module_admin', 'admin/cases/disable', '_self', '0', '1588137397', '1588137397', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('493', '487', 'admin', '快速编辑', '', 'module_admin', 'admin/cases/quickedit', '_self', '0', '1588137397', '1588137397', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('494', '464', 'admin', '自助投资分析', 'fa fa-fw fa-list', 'module_admin', 'admin/analysis/index', '_self', '0', '1588143052', '1588143052', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('495', '1', 'admin', '联系我们', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1588150942', '1588150942', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('496', '495', 'admin', '联系方式', 'fa fa-fw fa-list', 'module_admin', 'admin/contactus/index', '_self', '0', '1588150993', '1588150993', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('497', '496', 'admin', '新增', '', 'module_admin', 'admin/contactus/add', '_self', '0', '1588150993', '1588150993', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('498', '496', 'admin', '编辑', '', 'module_admin', 'admin/contactus/edit', '_self', '0', '1588150993', '1588150993', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('499', '496', 'admin', '删除', '', 'module_admin', 'admin/contactus/delete', '_self', '0', '1588150993', '1588150993', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('500', '496', 'admin', '启用', '', 'module_admin', 'admin/contactus/enable', '_self', '0', '1588150993', '1588150993', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('501', '496', 'admin', '禁用', '', 'module_admin', 'admin/contactus/disable', '_self', '0', '1588150993', '1588150993', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('502', '496', 'admin', '快速编辑', '', 'module_admin', 'admin/contactus/quickedit', '_self', '0', '1588150993', '1588150993', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('503', '1', 'admin', '用户留言', 'fa fa-fw fa-th-large', 'module_admin', '', '_self', '0', '1588525406', '1588525406', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('504', '503', 'admin', '在线申请', 'fa fa-fw fa-envelope-o', 'module_admin', 'admin/apply/index', '_self', '0', '1588525934', '1588525934', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('505', '504', 'admin', '新增', '', 'module_admin', 'admin/apply/add', '_self', '0', '1588525933', '1588525933', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('506', '504', 'admin', '编辑', '', 'module_admin', 'admin/apply/edit', '_self', '0', '1588525933', '1588525933', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('507', '504', 'admin', '删除', '', 'module_admin', 'admin/apply/delete', '_self', '0', '1588525933', '1588525933', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('508', '504', 'admin', '启用', '', 'module_admin', 'admin/apply/enable', '_self', '0', '1588525933', '1588525933', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('509', '504', 'admin', '禁用', '', 'module_admin', 'admin/apply/disable', '_self', '0', '1588525933', '1588525933', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('510', '504', 'admin', '快速编辑', '', 'module_admin', 'admin/apply/quickedit', '_self', '0', '1588525933', '1588525933', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('511', '504', 'admin', '详情', '', 'module_admin', 'admin/apply/details', '_self', '0', '1588527282', '1588527282', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('512', '503', 'admin', '自助投资分析', 'fa fa-fw fa-envelope', 'module_admin', 'admin/analysismessage/index', '_self', '0', '1588555684', '1588555684', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('513', '512', 'admin', '新增', '', 'module_admin', 'admin/analysismessage/add', '_self', '0', '1588555683', '1588555683', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('514', '512', 'admin', '编辑', '', 'module_admin', 'admin/analysismessage/edit', '_self', '0', '1588555683', '1588555683', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('515', '512', 'admin', '删除', '', 'module_admin', 'admin/analysismessage/delete', '_self', '0', '1588555683', '1588555683', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('516', '512', 'admin', '启用', '', 'module_admin', 'admin/analysismessage/enable', '_self', '0', '1588555683', '1588555683', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('517', '512', 'admin', '禁用', '', 'module_admin', 'admin/analysismessage/disable', '_self', '0', '1588555683', '1588555683', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('518', '512', 'admin', '快速编辑', '', 'module_admin', 'admin/analysismessage/quickedit', '_self', '0', '1588555683', '1588555683', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('519', '512', 'admin', '详情', '', 'module_admin', 'admin/analysismessage/details', '_self', '0', '1588555730', '1588555730', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('520', '503', 'admin', '在线留言', 'fa fa-fw fa-comment-o', 'module_admin', 'admin/contactusmessage/index', '_self', '0', '1588555816', '1588555816', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('521', '520', 'admin', '新增', '', 'module_admin', 'admin/Contactusmessage/add', '_self', '0', '1588555816', '1588555816', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('522', '520', 'admin', '编辑', '', 'module_admin', 'admin/Contactusmessage/edit', '_self', '0', '1588555816', '1588555816', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('523', '520', 'admin', '删除', '', 'module_admin', 'admin/Contactusmessage/delete', '_self', '0', '1588555816', '1588555816', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('524', '520', 'admin', '启用', '', 'module_admin', 'admin/Contactusmessage/enable', '_self', '0', '1588555816', '1588555816', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('525', '520', 'admin', '禁用', '', 'module_admin', 'admin/Contactusmessage/disable', '_self', '0', '1588555816', '1588555816', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('526', '520', 'admin', '快速编辑', '', 'module_admin', 'admin/Contactusmessage/quickedit', '_self', '0', '1588555816', '1588555816', '100', '0', '1', '');
INSERT INTO `dp_admin_menu` VALUES ('527', '520', 'admin', '详情', '', 'module_admin', 'admin/contactusmessage/details', '_self', '0', '1588555863', '1588555863', '100', '0', '1', '');

-- -----------------------------
-- Table structure for `dp_admin_message`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_message`;
CREATE TABLE `dp_admin_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_receive` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '接收消息的用户id',
  `uid_send` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送消息的用户id',
  `type` varchar(128) NOT NULL DEFAULT '' COMMENT '消息分类',
  `content` text NOT NULL COMMENT '消息内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `read_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='消息表';

-- -----------------------------
-- Records of `dp_admin_message`
-- -----------------------------
INSERT INTO `dp_admin_message` VALUES ('1', '1', '1', '1', '2', '0', '1588145157', '1588145157', '0');

-- -----------------------------
-- Table structure for `dp_admin_module`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_module`;
CREATE TABLE `dp_admin_module` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '模块名称（标识）',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '模块标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `description` text NOT NULL COMMENT '描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者主页',
  `config` text COMMENT '配置信息',
  `access` text COMMENT '授权配置',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '模块唯一标识符',
  `system_module` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统模块',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='模块表';

-- -----------------------------
-- Records of `dp_admin_module`
-- -----------------------------
INSERT INTO `dp_admin_module` VALUES ('1', 'admin', '系统', 'fa fa-fw fa-gear', '系统模块，DolphinPHP的核心模块', 'DolphinPHP', 'http://www.dolphinphp.com', '', '', '1.0.0', 'admin.dolphinphp.module', '1', '1468204902', '1468204902', '100', '1');
INSERT INTO `dp_admin_module` VALUES ('2', 'user', '用户', 'fa fa-fw fa-user', '用户模块，DolphinPHP自带模块', 'DolphinPHP', 'http://www.dolphinphp.com', '', '', '1.0.0', 'user.dolphinphp.module', '1', '1468204902', '1468204902', '100', '1');
INSERT INTO `dp_admin_module` VALUES ('3', 'cms', '门户', 'fa fa-fw fa-newspaper-o', '门户模块', 'CaiWeiMing', 'http://www.dolphinphp.com', '{\"summary\":0,\"contact\":\"<div class=\\\"font-s13 push\\\"><strong>\\u6cb3\\u6e90\\u5e02\\u5353\\u9510\\u79d1\\u6280\\u6709\\u9650\\u516c\\u53f8<\\/strong><br \\/>\\r\\n\\u5730\\u5740\\uff1a\\u6cb3\\u6e90\\u5e02\\u6c5f\\u4e1c\\u65b0\\u533a\\u4e1c\\u73af\\u8def\\u6c47\\u901a\\u82d1D3-H232<br \\/>\\r\\n\\u7535\\u8bdd\\uff1a0762-8910006<br \\/>\\r\\n\\u90ae\\u7bb1\\uff1aadmin@zrthink.com<\\/div>\",\"meta_head\":\"\",\"meta_foot\":\"\",\"support_status\":1,\"support_color\":\"rgba(0,158,232,1)\",\"support_wx\":\"\",\"support_extra\":\"\"}', '{\"column\":{\"title\":\"\\u680f\\u76ee\\u6388\\u6743\",\"nodes\":{\"group\":\"column\",\"table_name\":\"cms_column\",\"primary_key\":\"id\",\"parent_id\":\"pid\",\"node_name\":\"name\"}}}', '1.0.0', 'cms.ming.module', '0', '1587373198', '1587373215', '100', '1');

-- -----------------------------
-- Table structure for `dp_admin_navigation`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_navigation`;
CREATE TABLE `dp_admin_navigation` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级菜单id',
  `module` varchar(16) NOT NULL DEFAULT '' COMMENT '模块名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `url_type` varchar(16) NOT NULL DEFAULT '' COMMENT '链接类型（link：外链，module：模块）',
  `url_value` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `url_target` varchar(16) NOT NULL DEFAULT '_self' COMMENT '链接打开方式：_blank,_self',
  `online_hide` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '网站上线后是否隐藏',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `system_menu` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否为系统菜单，系统菜单不可删除',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `params` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `footer` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否在底部导航栏',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COMMENT='后台菜单表';

-- -----------------------------
-- Records of `dp_admin_navigation`
-- -----------------------------
INSERT INTO `dp_admin_navigation` VALUES ('1', '0', 'admin', '官网首页', 'fa fa-fw fa-home', 'module_home', 'index/index/index', '_self', '0', '1467617722', '1587780234', '1', '1', '1', '', '0');
INSERT INTO `dp_admin_navigation` VALUES ('2', '0', 'admin', '关于我们', 'fa fa-fw fa-list', 'module_home', 'index/aboutus/index', '_self', '0', '1587438863', '1587786723', '100', '0', '1', 'cat=3', '1');
INSERT INTO `dp_admin_navigation` VALUES ('3', '2', 'admin', '企业简介', '', 'module_home', 'index/aboutus/index', '_self', '0', '1587439548', '1587786748', '100', '0', '1', 'cat=3', '0');
INSERT INTO `dp_admin_navigation` VALUES ('4', '2', 'admin', '潮流前言', '', 'module_home', 'index/aboutus/index', '_self', '0', '1587522490', '1587802238', '100', '0', '1', 'cat=4', '0');
INSERT INTO `dp_admin_navigation` VALUES ('5', '2', 'admin', '品牌介绍', '', 'module_home', 'index/aboutus/index', '_self', '0', '1587522939', '1587802253', '100', '0', '1', 'cat=5', '1');
INSERT INTO `dp_admin_navigation` VALUES ('6', '2', 'admin', '品牌优势', '', 'module_home', 'index/aboutus/index', '_self', '0', '1587522977', '1587786621', '100', '0', '1', 'cat=6', '0');
INSERT INTO `dp_admin_navigation` VALUES ('7', '2', 'admin', '企业大事记', '', 'module_home', 'index/aboutus/index', '_self', '0', '1587523013', '1587786634', '100', '0', '1', 'cat=7', '0');
INSERT INTO `dp_admin_navigation` VALUES ('8', '2', 'admin', '资深讲师', '', 'module_home', 'index/aboutus/index', '_self', '0', '1587523045', '1587786644', '100', '0', '1', 'cat=8', '0');
INSERT INTO `dp_admin_navigation` VALUES ('9', '0', 'admin', '美食中心', 'fa fa-fw fa-list', 'module_home', 'index/food/index', '_self', '0', '1587523148', '1587955840', '100', '0', '1', 'cat=10', '1');
INSERT INTO `dp_admin_navigation` VALUES ('10', '9', 'admin', '纸上烤肉', '', 'module_home', 'index/food/index', '_self', '0', '1587523204', '1587954540', '100', '0', '1', 'cat=10', '0');
INSERT INTO `dp_admin_navigation` VALUES ('11', '9', 'admin', '纸上火锅', '', 'module_home', 'index/food/index', '_self', '0', '1587523261', '1587523302', '100', '0', '1', 'cat=11', '0');
INSERT INTO `dp_admin_navigation` VALUES ('12', '9', 'admin', '牛排海鲜', '', 'module_home', 'index/food/index', '_self', '0', '1587523350', '1587523350', '100', '0', '1', 'cat=12', '0');
INSERT INTO `dp_admin_navigation` VALUES ('13', '9', 'admin', '养生汤品', '', 'module_home', 'index/food/index', '_self', '0', '1587523395', '1587523395', '100', '0', '1', 'cat=13', '0');
INSERT INTO `dp_admin_navigation` VALUES ('14', '9', 'admin', '特色小吃', '', 'module_home', 'index/food/index', '_self', '0', '1587523415', '1587523415', '100', '0', '1', 'cat=14', '0');
INSERT INTO `dp_admin_navigation` VALUES ('15', '9', 'admin', '港式甜品', '', 'module_home', 'index/food/index', '_self', '0', '1587523439', '1587523439', '100', '0', '1', 'cat=15', '0');
INSERT INTO `dp_admin_navigation` VALUES ('16', '9', 'admin', '时尚饮品', '', 'module_home', 'index/food/index', '_self', '0', '1587523460', '1587523460', '100', '0', '1', 'cat=16', '0');
INSERT INTO `dp_admin_navigation` VALUES ('17', '9', 'admin', '冰淇淋', '', 'module_home', 'index/food/index', '_self', '0', '1587523486', '1587523486', '100', '0', '1', 'cat=17', '0');
INSERT INTO `dp_admin_navigation` VALUES ('18', '0', 'admin', '店面风采', 'fa fa-fw fa-list', 'module_home', 'index/store/index', '_self', '0', '1587523585', '1587523585', '100', '0', '1', '', '1');
INSERT INTO `dp_admin_navigation` VALUES ('19', '18', 'admin', '店铺形象', '', 'module_home', 'index/store/index', '_self', '0', '1587523625', '1587523625', '100', '0', '1', '', '0');
INSERT INTO `dp_admin_navigation` VALUES ('20', '0', 'admin', '项目中心', 'fa fa-fw fa-list', 'module_home', 'index/project/index', '_self', '0', '1587523765', '1588062637', '100', '0', '1', '', '0');
INSERT INTO `dp_admin_navigation` VALUES ('21', '20', 'admin', '媒体报道', '', 'module_home', 'index/project/index', '_self', '0', '1587523800', '1587523800', '100', '0', '1', '', '0');
INSERT INTO `dp_admin_navigation` VALUES ('22', '20', 'admin', '投资店型', '', 'module_home', 'index/project/project', '_self', '0', '1587524147', '1588064318', '100', '0', '1', 'cat=22', '1');
INSERT INTO `dp_admin_navigation` VALUES ('23', '20', 'admin', '合作流程', '', 'module_home', 'index/project/project', '_self', '0', '1587524167', '1588064341', '100', '0', '1', 'cat=23', '0');
INSERT INTO `dp_admin_navigation` VALUES ('24', '20', 'admin', '代理专区', '', 'module_home', 'index/project/agent', '_self', '0', '1587524191', '1588133223', '100', '0', '1', '', '0');
INSERT INTO `dp_admin_navigation` VALUES ('25', '20', 'admin', '成功案例', '', 'module_home', 'index/project/cases', '_self', '0', '1587524318', '1588139335', '100', '0', '1', '', '1');
INSERT INTO `dp_admin_navigation` VALUES ('26', '20', 'admin', '自助投资分析', '', 'module_home', 'index/project/analysis', '_self', '0', '1587524337', '1588141915', '100', '0', '1', '', '0');
INSERT INTO `dp_admin_navigation` VALUES ('27', '0', 'admin', '品牌动态', 'fa fa-fw fa-list', 'module_home', 'index/news/index', '_self', '0', '1587524409', '1587524409', '100', '0', '1', 'cat=28', '0');
INSERT INTO `dp_admin_navigation` VALUES ('28', '27', 'admin', '新店快讯', '', 'module_home', 'index/news/index', '_self', '0', '1587524470', '1588037857', '100', '0', '1', 'cat=28', '0');
INSERT INTO `dp_admin_navigation` VALUES ('29', '27', 'admin', '新闻资讯', '', 'module_home', 'index/news/index', '_self', '0', '1587524495', '1587524495', '100', '0', '1', 'cat=29', '1');
INSERT INTO `dp_admin_navigation` VALUES ('30', '27', 'admin', '品牌动态', '', 'module_home', 'index/news/index', '_self', '0', '1587524526', '1587524526', '100', '0', '1', 'cat=30', '0');
INSERT INTO `dp_admin_navigation` VALUES ('31', '0', 'admin', '加盟信息', 'fa fa-fw fa-list', 'module_home', 'index/news/index', '_self', '0', '1587524619', '1588224387', '100', '0', '1', 'cat=28', '0');
INSERT INTO `dp_admin_navigation` VALUES ('32', '31', 'admin', '招商加盟服务', '', 'module_home', 'index/project/agent', '_self', '0', '1587524727', '1588224432', '100', '0', '1', '', '0');
INSERT INTO `dp_admin_navigation` VALUES ('33', '31', 'admin', '加盟流程', '', 'module_home', 'index/project/project', '_self', '0', '1587524746', '1588224474', '100', '0', '1', 'cat=23', '0');
INSERT INTO `dp_admin_navigation` VALUES ('34', '31', 'admin', '加盟优势', '', 'module_home', 'index/aboutus/index', '_self', '0', '1587524770', '1588224532', '100', '0', '1', 'cat=6', '0');
INSERT INTO `dp_admin_navigation` VALUES ('35', '0', 'admin', '联系我们', 'fa fa-fw fa-list', 'module_home', 'index/contactus/index', '_self', '0', '1587524832', '1587524832', '100', '0', '1', '', '0');
INSERT INTO `dp_admin_navigation` VALUES ('36', '35', 'admin', '联系方式', '', 'module_home', 'index/contactus/index', '_self', '0', '1587524857', '1587524857', '100', '0', '1', '', '1');
INSERT INTO `dp_admin_navigation` VALUES ('37', '35', 'admin', '在线留言', '', 'module_home', 'index/contactus/message', '_self', '0', '1587524873', '1588214038', '100', '0', '1', '', '1');

-- -----------------------------
-- Table structure for `dp_admin_packet`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_packet`;
CREATE TABLE `dp_admin_packet` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '数据包名',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '数据包标题',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者url',
  `version` varchar(16) NOT NULL,
  `tables` text NOT NULL COMMENT '数据表名',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='数据包表';


-- -----------------------------
-- Table structure for `dp_admin_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_plugin`;
CREATE TABLE `dp_admin_plugin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '插件名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '插件标题',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '图标',
  `description` text NOT NULL COMMENT '插件描述',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `author_url` varchar(255) NOT NULL DEFAULT '' COMMENT '作者主页',
  `config` text NOT NULL COMMENT '配置信息',
  `version` varchar(16) NOT NULL DEFAULT '' COMMENT '版本号',
  `identifier` varchar(64) NOT NULL DEFAULT '' COMMENT '插件唯一标识符',
  `admin` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台管理',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `dp_admin_plugin`
-- -----------------------------
INSERT INTO `dp_admin_plugin` VALUES ('1', 'SystemInfo', '系统环境信息', 'fa fa-fw fa-info-circle', '在后台首页显示服务器信息', '蔡伟明', 'http://www.caiweiming.com', '{\"display\":\"1\",\"width\":\"6\"}', '1.0.0', 'system_info.ming.plugin', '0', '1477757503', '1477757503', '100', '1');
INSERT INTO `dp_admin_plugin` VALUES ('2', 'DevTeam', '开发团队成员信息', 'fa fa-fw fa-users', '开发团队成员信息', '蔡伟明', 'http://www.caiweiming.com', '{\"display\":\"1\",\"width\":\"6\"}', '1.0.0', 'dev_team.ming.plugin', '0', '1477755780', '1477755780', '100', '1');

-- -----------------------------
-- Table structure for `dp_admin_role`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_role`;
CREATE TABLE `dp_admin_role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级角色',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '角色名称',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '角色描述',
  `menu_auth` text NOT NULL COMMENT '菜单权限',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `access` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否可登录后台',
  `default_module` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '默认访问模块',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色表';

-- -----------------------------
-- Records of `dp_admin_role`
-- -----------------------------
INSERT INTO `dp_admin_role` VALUES ('1', '0', '超级管理员', '系统默认创建的角色，拥有最高权限', '', '0', '1476270000', '1468117612', '1', '1', '0');

-- -----------------------------
-- Table structure for `dp_admin_user`
-- -----------------------------
DROP TABLE IF EXISTS `dp_admin_user`;
CREATE TABLE `dp_admin_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(32) NOT NULL DEFAULT '' COMMENT '昵称',
  `password` varchar(96) NOT NULL DEFAULT '' COMMENT '密码',
  `email` varchar(64) NOT NULL DEFAULT '' COMMENT '邮箱地址',
  `email_bind` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定邮箱地址',
  `mobile` varchar(11) NOT NULL DEFAULT '' COMMENT '手机号码',
  `mobile_bind` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否绑定手机号码',
  `avatar` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '头像',
  `money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '余额',
  `score` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `role` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '角色ID',
  `group` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '部门id',
  `signup_ip` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '注册ip',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `last_login_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后一次登录时间',
  `last_login_ip` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '登录ip',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `dp_admin_user`
-- -----------------------------
INSERT INTO `dp_admin_user` VALUES ('1', 'admin', '超级管理员', '$2y$10$KUEeWELJX8RH932ysogEKuugCP.0IBt7GWaDd0gOmOBhwR8ZQp22K', '', '0', '', '0', '1', '0.00', '0', '1', '0', '0', '1476065410', '1588751941', '1588751940', '2130706433', '100', '1');

-- -----------------------------
-- Table structure for `dp_cms_advert`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_advert`;
CREATE TABLE `dp_cms_advert` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '分类id',
  `tagname` varchar(30) NOT NULL DEFAULT '' COMMENT '广告位标识',
  `ad_type` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '广告类型',
  `timeset` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '时间限制:0-永不过期,1-在设内时间内有效',
  `start_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '结束时间',
  `name` varchar(60) NOT NULL DEFAULT '' COMMENT '广告位名称',
  `content` text NOT NULL COMMENT '广告内容',
  `expcontent` text NOT NULL COMMENT '过期显示内容',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='广告表';


-- -----------------------------
-- Table structure for `dp_cms_advert_type`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_advert_type`;
CREATE TABLE `dp_cms_advert_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '分类名称',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='广告分类表';


-- -----------------------------
-- Table structure for `dp_cms_column`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_column`;
CREATE TABLE `dp_cms_column` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `model` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文档模型id',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接',
  `target` varchar(16) NOT NULL DEFAULT '_self' COMMENT '链接打开方式',
  `content` text NOT NULL COMMENT '内容',
  `icon` varchar(64) NOT NULL DEFAULT '' COMMENT '字体图标',
  `index_template` varchar(32) NOT NULL DEFAULT '' COMMENT '封面模板',
  `list_template` varchar(32) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `detail_template` varchar(32) NOT NULL DEFAULT '' COMMENT '详情页模板',
  `post_auth` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '投稿权限',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `hide` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `rank_auth` int(11) NOT NULL DEFAULT '0' COMMENT '浏览权限，-1待审核，0为开放浏览，大于0则为对应的用户角色id',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '栏目属性：0-最终列表栏目，1-外部链接，2-频道封面',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='栏目表';


-- -----------------------------
-- Table structure for `dp_cms_document`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_document`;
CREATE TABLE `dp_cms_document` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '栏目id',
  `model` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文档模型ID',
  `title` varchar(256) NOT NULL DEFAULT '' COMMENT '标题',
  `shorttitle` varchar(32) NOT NULL DEFAULT '' COMMENT '简略标题',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `flag` set('j','p','b','s','a','f','c','h') DEFAULT NULL COMMENT '自定义属性',
  `view` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `comment` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `good` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点赞数',
  `bad` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '踩数',
  `mark` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数量',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `trash` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '回收站',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档基础表';


-- -----------------------------
-- Table structure for `dp_cms_field`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_field`;
CREATE TABLE `dp_cms_field` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '字段名称',
  `name` varchar(32) NOT NULL,
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '字段标题',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '字段类型',
  `define` varchar(128) NOT NULL DEFAULT '' COMMENT '字段定义',
  `value` text COMMENT '默认值',
  `options` text COMMENT '额外选项',
  `tips` varchar(256) NOT NULL DEFAULT '' COMMENT '提示说明',
  `fixed` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '是否为固定字段',
  `show` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '是否显示',
  `model` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '所属文档模型id',
  `ajax_url` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框ajax地址',
  `next_items` varchar(256) NOT NULL DEFAULT '' COMMENT '联动下拉框的下级下拉框名，多个以逗号隔开',
  `param` varchar(32) NOT NULL DEFAULT '' COMMENT '联动下拉框请求参数名',
  `format` varchar(32) NOT NULL DEFAULT '' COMMENT '格式，用于格式文本',
  `table` varchar(32) NOT NULL DEFAULT '' COMMENT '表名，只用于快速联动类型',
  `level` tinyint(2) unsigned NOT NULL DEFAULT '2' COMMENT '联动级别，只用于快速联动类型',
  `key` varchar(32) NOT NULL DEFAULT '' COMMENT '键字段，只用于快速联动类型',
  `option` varchar(32) NOT NULL DEFAULT '' COMMENT '值字段，只用于快速联动类型',
  `pid` varchar(32) NOT NULL DEFAULT '' COMMENT '父级id字段，只用于快速联动类型',
  `ak` varchar(32) NOT NULL DEFAULT '' COMMENT '百度地图appkey',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='文档字段表';

-- -----------------------------
-- Records of `dp_cms_field`
-- -----------------------------
INSERT INTO `dp_cms_field` VALUES ('1', 'id', 'ID', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', 'ID', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480562978', '1480562978', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('2', 'cid', '栏目', 'select', 'int(11) UNSIGNED NOT NULL', '0', '', '请选择所属栏目', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480562978', '1480562978', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('3', 'uid', '用户ID', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563110', '1480563110', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('4', 'model', '模型ID', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563110', '1480563110', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('5', 'title', '标题', 'text', 'varchar(128) NOT NULL', '', '', '文档标题', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480575844', '1480576134', '1', '1');
INSERT INTO `dp_cms_field` VALUES ('6', 'shorttitle', '简略标题', 'text', 'varchar(32) NOT NULL', '', '', '简略标题', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480575844', '1480576134', '1', '1');
INSERT INTO `dp_cms_field` VALUES ('7', 'flag', '自定义属性', 'checkbox', 'set(\'j\',\'p\',\'b\',\'s\',\'a\',\'f\',\'h\',\'c\') NULL DEFAULT NULL', '', 'j:跳转\r\np:图片\r\nb:加粗\r\ns:滚动\r\na:特荐\r\nf:幻灯\r\nh:头条\r\nc:推荐', '自定义属性', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480671258', '1480671258', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('8', 'view', '阅读量', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480563149', '1480563149', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('9', 'comment', '评论数', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563189', '1480563189', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('10', 'good', '点赞数', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563279', '1480563279', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('11', 'bad', '踩数', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563330', '1480563330', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('12', 'mark', '收藏数量', 'text', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563372', '1480563372', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('13', 'create_time', '创建时间', 'datetime', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563406', '1480563406', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('14', 'update_time', '更新时间', 'datetime', 'int(11) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563432', '1480563432', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('15', 'sort', '排序', 'text', 'int(11) NOT NULL', '100', '', '', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480563510', '1480563510', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('16', 'status', '状态', 'radio', 'tinyint(2) UNSIGNED NOT NULL', '1', '0:禁用\r\n1:启用', '', '0', '1', '0', '', '', '', '', '', '0', '', '', '', '', '1480563576', '1480563576', '100', '1');
INSERT INTO `dp_cms_field` VALUES ('17', 'trash', '回收站', 'text', 'tinyint(2) UNSIGNED NOT NULL', '0', '', '', '0', '0', '0', '', '', '', '', '', '0', '', '', '', '', '1480563576', '1480563576', '100', '1');

-- -----------------------------
-- Table structure for `dp_cms_link`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_link`;
CREATE TABLE `dp_cms_link` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型：1-文字链接，2-图片链接',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '链接标题',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `logo` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '链接LOGO',
  `contact` varchar(255) NOT NULL DEFAULT '' COMMENT '联系方式',
  `sort` int(11) NOT NULL DEFAULT '100',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='有钱链接表';


-- -----------------------------
-- Table structure for `dp_cms_menu`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_menu`;
CREATE TABLE `dp_cms_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '导航id',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `column` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '栏目id',
  `page` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '单页id',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '类型：0-栏目链接，1-单页链接，2-自定义链接',
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接',
  `css` varchar(64) NOT NULL DEFAULT '' COMMENT 'css类',
  `rel` varchar(64) NOT NULL DEFAULT '' COMMENT '链接关系网',
  `target` varchar(16) NOT NULL DEFAULT '' COMMENT '打开方式',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='菜单表';

-- -----------------------------
-- Records of `dp_cms_menu`
-- -----------------------------
INSERT INTO `dp_cms_menu` VALUES ('1', '1', '0', '0', '0', '2', '首页', 'cms/index/index', '', '', '_self', '1492345605', '1492345605', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('2', '2', '0', '0', '0', '2', '关于我们', 'http://www.dolphinphp.com', '', '', '_self', '1492346763', '1492346763', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('3', '3', '0', '0', '0', '2', '开发文档', 'http://www.kancloud.cn/ming5112/dolphinphp', '', '', '_self', '1492346812', '1492346812', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('4', '3', '0', '0', '0', '2', '开发者社区', 'http://bbs.dolphinphp.com/', '', '', '_self', '1492346832', '1492346832', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('5', '1', '0', '0', '0', '2', '二级菜单', 'http://www.dolphinphp.com', '', '', '_self', '1492347372', '1492347510', '100', '1');
INSERT INTO `dp_cms_menu` VALUES ('6', '1', '5', '0', '0', '2', '子菜单', 'http://www.dolphinphp.com', '', '', '_self', '1492347388', '1492347520', '100', '1');

-- -----------------------------
-- Table structure for `dp_cms_model`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_model`;
CREATE TABLE `dp_cms_model` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '模型名称',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '模型标题',
  `table` varchar(64) NOT NULL DEFAULT '' COMMENT '附加表名称',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '模型类别：0-系统模型，1-普通模型，2-独立模型',
  `icon` varchar(64) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `system` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '是否系统模型',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='内容模型表';


-- -----------------------------
-- Table structure for `dp_cms_nav`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_nav`;
CREATE TABLE `dp_cms_nav` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(32) NOT NULL DEFAULT '' COMMENT '导航标识',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '菜单标题',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='导航表';

-- -----------------------------
-- Records of `dp_cms_nav`
-- -----------------------------
INSERT INTO `dp_cms_nav` VALUES ('1', 'main_nav', '顶部导航', '1492345083', '1492345083', '1');
INSERT INTO `dp_cms_nav` VALUES ('2', 'about_nav', '底部关于', '1492346685', '1492346685', '1');
INSERT INTO `dp_cms_nav` VALUES ('3', 'support_nav', '服务与支持', '1492346715', '1492346715', '1');

-- -----------------------------
-- Table structure for `dp_cms_page`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_page`;
CREATE TABLE `dp_cms_page` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '单页标题',
  `content` mediumtext NOT NULL COMMENT '单页内容',
  `keywords` varchar(32) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` varchar(250) NOT NULL DEFAULT '' COMMENT '页面描述',
  `template` varchar(32) NOT NULL DEFAULT '' COMMENT '模板文件',
  `cover` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '单页封面',
  `view` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='单页表';

-- -----------------------------
-- Records of `dp_cms_page`
-- -----------------------------
INSERT INTO `dp_cms_page` VALUES ('1', 'test', '<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:910px\">\r\n	<tbody>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p><img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/1.jpg\" />&nbsp;<img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/2.jpg\" />&nbsp;<img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/3.jpg\" />&nbsp;<img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/4.jpg\" />&nbsp;<img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/5.jpg\" />&nbsp;<img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/6.jpg\" />&nbsp;<img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/7.jpg\" />&nbsp;<img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/8.jpg\" />&nbsp;<img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/9.jpg\" />&nbsp;<img alt=\"\" src=\"http://www.1zhichan.com/image/clqy/10.jpg\" /></p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '', '', '', '0', '0', '1587526235', '1587526235', '1');
INSERT INTO `dp_cms_page` VALUES ('2', '热烈祝贺贵州龙里涮烤吧正式开店营业！', '<table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:930px\">\r\n	<tbody>\r\n		<tr>\r\n			<td>2018/6/21</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p>好消息！好消息！好消息！重要的事情说三遍！这不，<strong><a href=\"http://www.1zhichan.com/xwc2027.html\" target=\"_blank\">一纸馋纸上烤肉店</a></strong>加盟在贵州龙里迎来了新成员，一场别开生面的开业典礼让到场观礼的美食爱好者享受到了一场视听觉盛宴。</p>\r\n\r\n			<p><img alt=\"\" src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20180621/20180621152952_5297.jpg\" /></p>\r\n\r\n			<p>&nbsp;</p>\r\n\r\n			<p>&nbsp;&nbsp; &nbsp; 联系电话：400 0809 517</p>\r\n\r\n			<p>&nbsp; &nbsp; &nbsp;官网查询：www.1zhichan.com</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n', '', '热烈祝贺贵州龙里涮烤吧正式开店营业！\r\n', '新店快讯', '0', '0', '1587708197', '1587708197', '1');

-- -----------------------------
-- Table structure for `dp_cms_slider`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_slider`;
CREATE TABLE `dp_cms_slider` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '标题',
  `cover` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '封面id',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='滚动图片表';


-- -----------------------------
-- Table structure for `dp_cms_support`
-- -----------------------------
DROP TABLE IF EXISTS `dp_cms_support`;
CREATE TABLE `dp_cms_support` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT '客服名称',
  `qq` varchar(16) NOT NULL DEFAULT '' COMMENT 'QQ',
  `msn` varchar(100) NOT NULL DEFAULT '' COMMENT 'msn',
  `taobao` varchar(100) NOT NULL DEFAULT '' COMMENT 'taobao',
  `alibaba` varchar(100) NOT NULL DEFAULT '' COMMENT 'alibaba',
  `skype` varchar(100) NOT NULL DEFAULT '' COMMENT 'skype',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `sort` int(11) unsigned NOT NULL DEFAULT '100' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='客服表';


-- -----------------------------
-- Table structure for `dp_configuration`
-- -----------------------------
DROP TABLE IF EXISTS `dp_configuration`;
CREATE TABLE `dp_configuration` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `mobile` varchar(255) NOT NULL DEFAULT '' COMMENT '客服电话',
  `tel` varchar(50) NOT NULL DEFAULT '0' COMMENT '400热线',
  `icon` varchar(11) NOT NULL DEFAULT '0' COMMENT 'icon',
  `logo` varchar(255) NOT NULL COMMENT 'logo',
  `wb_img` varchar(11) NOT NULL DEFAULT '' COMMENT '微博二维码',
  `wx_img` varchar(11) NOT NULL DEFAULT '0' COMMENT '微信二维码',
  `address` varchar(255) NOT NULL COMMENT '地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='公共配置表';

-- -----------------------------
-- Records of `dp_configuration`
-- -----------------------------
INSERT INTO `dp_configuration` VALUES ('1', '一纸馋官网,烤肉加盟,韩国烤肉加盟,纸上烤肉加盟,自助烤肉加盟', '一纸馋主营烧烤加盟、自助烧烤加盟、烤肉加盟、烧烤品牌加盟、烤肉店的成本多少钱、烧烤店要多少钱、纸上烤肉加盟、烧烤排行榜、十大烧烤加盟、纸上火锅。', '028-69162188', '400-0809-517', '', '3', '2', '2', '成都市青羊区顺城大街248号世界贸易中心A座7楼', '1587448797', '1587545140');

-- -----------------------------
-- Table structure for `dp_home_aboutus`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_aboutus`;
CREATE TABLE `dp_home_aboutus` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `pid` int(11) NOT NULL COMMENT '所属分页id',
  `img` int(11) NOT NULL COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COMMENT='关于我们表';

-- -----------------------------
-- Records of `dp_home_aboutus`
-- -----------------------------
INSERT INTO `dp_home_aboutus` VALUES ('1', '3', '7', '1', '1', '1', '1587783816', '1587785910', '1');
INSERT INTO `dp_home_aboutus` VALUES ('2', '3', '6', '2', '2', '2', '1587785178', '1587785178', '1');
INSERT INTO `dp_home_aboutus` VALUES ('3', '3', '9', '3', '3', '3', '1587785212', '1587785212', '1');
INSERT INTO `dp_home_aboutus` VALUES ('4', '3', '8', '4', '4', '4', '1587785251', '1587785251', '1');
INSERT INTO `dp_home_aboutus` VALUES ('5', '3', '10', '5', '5', '5', '1587785269', '1587785269', '1');
INSERT INTO `dp_home_aboutus` VALUES ('6', '3', '11', '6', '6', '6', '1587785295', '1587785295', '1');
INSERT INTO `dp_home_aboutus` VALUES ('7', '3', '12', '7', '7', '7', '1587785313', '1587785313', '1');
INSERT INTO `dp_home_aboutus` VALUES ('8', '3', '13', '8', '8', '8', '1587785333', '1587785333', '1');
INSERT INTO `dp_home_aboutus` VALUES ('9', '3', '14', '9', '9', '9', '1587785351', '1587785351', '1');
INSERT INTO `dp_home_aboutus` VALUES ('10', '3', '15', '10', '10', '10', '1587785371', '1587785371', '1');
INSERT INTO `dp_home_aboutus` VALUES ('11', '4', '52', '1', '1', '1', '1587785435', '1587785435', '1');
INSERT INTO `dp_home_aboutus` VALUES ('12', '4', '53', '2', '2', '2', '1587785454', '1587785454', '1');
INSERT INTO `dp_home_aboutus` VALUES ('13', '4', '54', '3', '3', '3', '1587785471', '1587785471', '1');
INSERT INTO `dp_home_aboutus` VALUES ('14', '4', '55', '4', '4', '4', '1587785490', '1587785490', '1');
INSERT INTO `dp_home_aboutus` VALUES ('15', '4', '56', '5', '5', '5', '1587785506', '1587785506', '1');
INSERT INTO `dp_home_aboutus` VALUES ('16', '4', '57', '6', '6', '6', '1587785523', '1587785523', '1');
INSERT INTO `dp_home_aboutus` VALUES ('17', '4', '58', '7', '7', '7', '1587785552', '1587785552', '1');
INSERT INTO `dp_home_aboutus` VALUES ('18', '4', '59', '8', '8', '8', '1587785567', '1587785567', '1');
INSERT INTO `dp_home_aboutus` VALUES ('19', '4', '60', '9', '9', '9', '1587785586', '1587785586', '1');
INSERT INTO `dp_home_aboutus` VALUES ('20', '4', '61', '10', '10', '10', '1587785608', '1587785608', '1');
INSERT INTO `dp_home_aboutus` VALUES ('21', '5', '62', '1', '1', '1', '1587786337', '1587786337', '1');
INSERT INTO `dp_home_aboutus` VALUES ('22', '5', '63', '2', '2', '2', '1587786355', '1587786355', '1');
INSERT INTO `dp_home_aboutus` VALUES ('23', '5', '64', '3', '3', '3', '1587786380', '1587786380', '1');
INSERT INTO `dp_home_aboutus` VALUES ('24', '5', '65', '4', '4', '4', '1587786396', '1587786396', '1');
INSERT INTO `dp_home_aboutus` VALUES ('25', '5', '66', '5', '5', '5', '1587786412', '1587786412', '1');
INSERT INTO `dp_home_aboutus` VALUES ('26', '5', '67', '6', '6', '6', '1587786427', '1587786427', '1');
INSERT INTO `dp_home_aboutus` VALUES ('27', '5', '68', '7', '7', '7', '1587786442', '1587786442', '1');
INSERT INTO `dp_home_aboutus` VALUES ('28', '5', '69', '8', '8', '8', '1587786469', '1587786469', '1');
INSERT INTO `dp_home_aboutus` VALUES ('29', '5', '70', '9', '9', '9', '1587786484', '1587786484', '1');
INSERT INTO `dp_home_aboutus` VALUES ('30', '5', '71', '10', '10', '10', '1587786504', '1587786504', '1');
INSERT INTO `dp_home_aboutus` VALUES ('31', '6', '111', '1', '1', '1', '1588036113', '1588036113', '1');
INSERT INTO `dp_home_aboutus` VALUES ('32', '6', '112', '2', '2', '2', '1588036129', '1588036129', '1');
INSERT INTO `dp_home_aboutus` VALUES ('33', '6', '113', '3', '3', '3', '1588036150', '1588036150', '1');
INSERT INTO `dp_home_aboutus` VALUES ('34', '6', '114', '4', '4', '4', '1588036173', '1588036173', '1');
INSERT INTO `dp_home_aboutus` VALUES ('35', '6', '115', '5', '5', '5', '1588036192', '1588036192', '1');
INSERT INTO `dp_home_aboutus` VALUES ('36', '6', '116', '6', '6', '6', '1588036208', '1588036208', '1');
INSERT INTO `dp_home_aboutus` VALUES ('37', '6', '117', '7', '7', '7', '1588036225', '1588036225', '1');
INSERT INTO `dp_home_aboutus` VALUES ('38', '6', '118', '8', '8', '8', '1588036240', '1588036240', '1');
INSERT INTO `dp_home_aboutus` VALUES ('39', '6', '119', '9', '9', '9', '1588036257', '1588036257', '1');
INSERT INTO `dp_home_aboutus` VALUES ('40', '6', '120', '10', '10', '10', '1588036278', '1588036278', '1');
INSERT INTO `dp_home_aboutus` VALUES ('41', '7', '343', '1', '1', '1', '1588223309', '1588223309', '1');
INSERT INTO `dp_home_aboutus` VALUES ('42', '7', '344', '2', '2', '2', '1588223324', '1588223324', '1');
INSERT INTO `dp_home_aboutus` VALUES ('43', '7', '345', '3', '3', '3', '1588223337', '1588223337', '1');
INSERT INTO `dp_home_aboutus` VALUES ('44', '7', '346', '4', '4', '4', '1588223351', '1588223351', '1');
INSERT INTO `dp_home_aboutus` VALUES ('45', '7', '347', '5', '5', '5', '1588223364', '1588223364', '1');
INSERT INTO `dp_home_aboutus` VALUES ('46', '7', '348', '6', '6', '6', '1588223379', '1588223379', '1');
INSERT INTO `dp_home_aboutus` VALUES ('47', '7', '349', '7', '7', '7', '1588223393', '1588223393', '1');
INSERT INTO `dp_home_aboutus` VALUES ('48', '7', '350', '8', '8', '8', '1588223407', '1588223407', '1');
INSERT INTO `dp_home_aboutus` VALUES ('49', '7', '351', '9', '9', '9', '1588223423', '1588223423', '1');
INSERT INTO `dp_home_aboutus` VALUES ('50', '7', '352', '10', '10', '10', '1588223444', '1588223444', '1');
INSERT INTO `dp_home_aboutus` VALUES ('51', '7', '353', '11', '11', '11', '1588223461', '1588223461', '1');
INSERT INTO `dp_home_aboutus` VALUES ('52', '8', '354', '1', '1', '1', '1588223488', '1588223488', '1');
INSERT INTO `dp_home_aboutus` VALUES ('53', '8', '355', '2', '2', '2', '1588223506', '1588223506', '1');
INSERT INTO `dp_home_aboutus` VALUES ('54', '8', '356', '3', '3', '3', '1588223526', '1588223526', '1');
INSERT INTO `dp_home_aboutus` VALUES ('55', '8', '357', '4', '4', '4', '1588223542', '1588223542', '1');
INSERT INTO `dp_home_aboutus` VALUES ('56', '8', '358', '5', '5', '5', '1588223556', '1588223556', '1');
INSERT INTO `dp_home_aboutus` VALUES ('57', '8', '359', '6', '6', '6', '1588223573', '1588223573', '1');
INSERT INTO `dp_home_aboutus` VALUES ('58', '8', '360', '7', '7', '7', '1588223919', '1588223919', '1');
INSERT INTO `dp_home_aboutus` VALUES ('59', '8', '361', '8', '8', '8', '1588223935', '1588223935', '1');
INSERT INTO `dp_home_aboutus` VALUES ('60', '8', '362', '9', '9', '9', '1588223954', '1588223954', '1');
INSERT INTO `dp_home_aboutus` VALUES ('61', '8', '363', '10', '10', '10', '1588223972', '1588223972', '1');

-- -----------------------------
-- Table structure for `dp_home_agent`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_agent`;
CREATE TABLE `dp_home_agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '项目',
  `img` varchar(255) NOT NULL COMMENT '县（市、地辖区）级代理',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '地级市代理',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '省会城市代理',
  `status` varchar(255) NOT NULL DEFAULT '' COMMENT '直辖市代理',
  `sort` varchar(255) NOT NULL COMMENT '省级代理',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='代理专区';

-- -----------------------------
-- Records of `dp_home_agent`
-- -----------------------------
INSERT INTO `dp_home_agent` VALUES ('1', '区域划分', '县、县级市、市辖区', '含所辖区、市、县', '省会城市代理', '北京、上海、天津、重庆', '全省行政所辖范围');
INSERT INTO `dp_home_agent` VALUES ('2', '区域代理费', '30万', '50万', '100万', '100万', '200万');
INSERT INTO `dp_home_agent` VALUES ('3', '年度运营服务费', '5000元/年', '5000元/年', '5000元/年', '8000元/年', '10000元/年');

-- -----------------------------
-- Table structure for `dp_home_agent_img`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_agent_img`;
CREATE TABLE `dp_home_agent_img` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `img` int(11) NOT NULL COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `pag` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0,1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='代理专区';

-- -----------------------------
-- Records of `dp_home_agent_img`
-- -----------------------------
INSERT INTO `dp_home_agent_img` VALUES ('1', '189', '1', '1', '1', '1588132760', '1588132760', '1', '0');
INSERT INTO `dp_home_agent_img` VALUES ('2', '190', '2', '2', '2', '1588132774', '1588132774', '1', '0');
INSERT INTO `dp_home_agent_img` VALUES ('3', '191', '3', '3', '3', '1588132785', '1588132785', '1', '0');
INSERT INTO `dp_home_agent_img` VALUES ('5', '193', '5', '5', '5', '1588135513', '1588135513', '1', '1');
INSERT INTO `dp_home_agent_img` VALUES ('6', '194', '6', '6', '6', '1588135527', '1588135527', '1', '1');
INSERT INTO `dp_home_agent_img` VALUES ('7', '195', '7', '7', '7', '1588135541', '1588135541', '1', '1');
INSERT INTO `dp_home_agent_img` VALUES ('8', '196', '8', '8', '8', '1588135562', '1588135562', '1', '1');
INSERT INTO `dp_home_agent_img` VALUES ('9', '197', '9', '9', '9', '1588135574', '1588135574', '1', '1');
INSERT INTO `dp_home_agent_img` VALUES ('10', '198', '10', '10', '10', '1588135589', '1588135589', '1', '1');

-- -----------------------------
-- Table structure for `dp_home_album`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_album`;
CREATE TABLE `dp_home_album` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `url` varchar(255) NOT NULL COMMENT '跳转链接',
  `img` varchar(11) NOT NULL DEFAULT '' COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='首页相册表';

-- -----------------------------
-- Records of `dp_home_album`
-- -----------------------------
INSERT INTO `dp_home_album` VALUES ('1', '1', '50', '海鲜拼盘', '海鲜拼盘', '100', '1587457777', '1587718738', '1');
INSERT INTO `dp_home_album` VALUES ('2', '1', '5', '纸上火锅', '纸上火锅', '100', '1587718694', '1587718694', '1');
INSERT INTO `dp_home_album` VALUES ('3', '1', '51', '牛排', '牛排', '10', '1587718879', '1587718879', '1');

-- -----------------------------
-- Table structure for `dp_home_analysis`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_analysis`;
CREATE TABLE `dp_home_analysis` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `budget` varchar(255) NOT NULL DEFAULT '' COMMENT '预算',
  `area` varchar(255) NOT NULL DEFAULT '' COMMENT '面积',
  `position` varchar(255) NOT NULL DEFAULT '' COMMENT '位置',
  `style` varchar(255) NOT NULL DEFAULT '' COMMENT '风格',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='项目中心/自助分析';

-- -----------------------------
-- Records of `dp_home_analysis`
-- -----------------------------
INSERT INTO `dp_home_analysis` VALUES ('1', '10万以内、10万~20万、20万~30万、30万~40万、40万以上', '80平以内、80~120平、120~160平、160~200平、200平以上', '商业体、学校附近、热闹街区、小区周边、其他', '简约格调风、现代都市风、星际魔幻风');

-- -----------------------------
-- Table structure for `dp_home_analysis_message`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_analysis_message`;
CREATE TABLE `dp_home_analysis_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `budget` varchar(128) NOT NULL DEFAULT '' COMMENT '预算',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '地址',
  `store` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有门店',
  `area` varchar(255) NOT NULL DEFAULT '' COMMENT '面积',
  `position` varchar(255) NOT NULL COMMENT '门店位置',
  `style` varchar(255) NOT NULL COMMENT '风格',
  `experience` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有开店经验',
  `qq` varchar(255) NOT NULL DEFAULT '' COMMENT 'QQ',
  `data` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否接收资料',
  `tel` varchar(255) NOT NULL DEFAULT '' COMMENT '联系方式',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `ip` varchar(255) NOT NULL COMMENT 'IP地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `read_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='消息表';

-- -----------------------------
-- Records of `dp_home_analysis_message`
-- -----------------------------
INSERT INTO `dp_home_analysis_message` VALUES ('1', '10万以内', '四川-市辖区', '0', '80平以内', '商业体', '简约格调风', '0', '773916571', '0', '13219294337', '0', '127.0.0.1', '1588525276', '0');

-- -----------------------------
-- Table structure for `dp_home_banner`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_banner`;
CREATE TABLE `dp_home_banner` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `url` varchar(255) NOT NULL COMMENT '链接',
  `params` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `img1` int(11) NOT NULL COMMENT '图片',
  `alt1` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title1` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `img2` int(11) NOT NULL COMMENT '图片',
  `alt2` varchar(255) NOT NULL COMMENT '替代文本',
  `title2` varchar(255) NOT NULL COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='首页/Banner';

-- -----------------------------
-- Records of `dp_home_banner`
-- -----------------------------
INSERT INTO `dp_home_banner` VALUES ('1', 'index/store/index', '', '韩国烤肉', '20', '韩国烤肉', '韩国烤肉', '21', '武汉加油', '武汉加油', '100', '1587624584', '1588580225', '1');
INSERT INTO `dp_home_banner` VALUES ('2', 'index/store/index', '', '韩国烤肉', '22', '遇到TA，约吗', '遇到TA，约吗', '23', '贺报', '贺报', '100', '1587624796', '1588580238', '1');
INSERT INTO `dp_home_banner` VALUES ('3', 'index/food/index', 'cat=12', '来自韩国的烤肉', '24', '来自韩国的烤肉', '来自韩国的烤肉', '25', '来自韩国的烤肉', '来自韩国的烤肉', '100', '1587624875', '1588580989', '1');
INSERT INTO `dp_home_banner` VALUES ('4', 'index/food/index', 'cat=10', '韩国烤肉', '26', '这是一场向舌尖味蕾发出的挑战', '这是一场向舌尖味蕾发出的挑战', '21', '武汉加油', '武汉加油', '100', '1587624965', '1588581247', '1');

-- -----------------------------
-- Table structure for `dp_home_banner_bg`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_banner_bg`;
CREATE TABLE `dp_home_banner_bg` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `img` int(11) NOT NULL COMMENT '图片',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='首页/Bannner背景图';

-- -----------------------------
-- Records of `dp_home_banner_bg`
-- -----------------------------
INSERT INTO `dp_home_banner_bg` VALUES ('1', '16', '', '100', '1587614840', '1587614840', '1');
INSERT INTO `dp_home_banner_bg` VALUES ('2', '17', '', '100', '1587614872', '1587614872', '1');
INSERT INTO `dp_home_banner_bg` VALUES ('3', '18', '', '100', '1587614939', '1587614939', '1');
INSERT INTO `dp_home_banner_bg` VALUES ('4', '19', '', '100', '1587614978', '1587614978', '1');

-- -----------------------------
-- Table structure for `dp_home_cases`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_cases`;
CREATE TABLE `dp_home_cases` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `img` varchar(255) NOT NULL COMMENT '封面图',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `text` mediumtext NOT NULL COMMENT '文章内容',
  `time` varchar(255) NOT NULL DEFAULT '' COMMENT '显示时间',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='项目中心/成功案例';

-- -----------------------------
-- Records of `dp_home_cases`
-- -----------------------------
INSERT INTO `dp_home_cases` VALUES ('1', '199', '成功案例', '<p><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160044_9580.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160045_0205.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160045_0517.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160045_1142.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160045_2080.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160045_2705.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160045_3173.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160045_4111.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160045_4580.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327160045_5205.jpg\" alt=\"\"/></p>', '2017/1/5', '0', '1588137643', '1588139531', '1');
INSERT INTO `dp_home_cases` VALUES ('2', '200', '成功案例', '<p><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155855_3955.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155855_5048.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155855_5673.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155855_6142.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155855_7080.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155855_7392.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155855_8017.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155855_8955.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155855_9423.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155856_0048.jpg\" alt=\"\"/></p>', '2017/1/5', '0', '1588139707', '1588139707', '1');
INSERT INTO `dp_home_cases` VALUES ('3', '201', '成功案例', '<p><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170113/20170113145919_8437.jpg\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170113/20170113145920_0625.jpg\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170113/20170113145920_1875.jpg\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170113/20170113145920_2968.jpg\"/></p>', '2017/1/5', '0', '1588139778', '1588140484', '1');
INSERT INTO `dp_home_cases` VALUES ('4', '202', '成功案例', '<table width=\"930\" align=\"center\"><tbody style=\"margin: 0px; padding: 0px;\"><tr style=\"margin: 0px; padding: 0px; outline: none;\" class=\"firstRow\"><td align=\"left\" style=\"margin: 0px; padding: 10px 0px; outline: none; line-height: 28px; background-image: url(&quot;/image/alcbg.jpg&quot;); background-position: initial; background-size: initial; background-repeat: repeat-y; background-attachment: initial; background-origin: initial; background-clip: initial;\"><p><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_0205.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_0673.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_1298.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_2080.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_2548.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_3330.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_4111.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_4580.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_5673.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155429_6455.jpg\" alt=\"\"/></p></td></tr></tbody></table><p><br/></p>', '2017/1/5', '0', '1588140708', '1588140708', '1');
INSERT INTO `dp_home_cases` VALUES ('5', '203', '成功案例', '<table width=\"930\" align=\"center\"><tbody style=\"margin: 0px; padding: 0px;\"><tr style=\"margin: 0px; padding: 0px; outline: none;\" class=\"firstRow\"><td align=\"left\" style=\"margin: 0px; padding: 10px 0px; outline: none; line-height: 28px; background-image: url(&quot;/image/alcbg.jpg&quot;); background-position: initial; background-size: initial; background-repeat: repeat-y; background-attachment: initial; background-origin: initial; background-clip: initial;\"><p><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155604_6298.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155604_7548.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155604_8173.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155604_8642.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155604_9423.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155605_0205.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155605_0673.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155605_1142.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155605_2080.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327155605_2548.jpg\" alt=\"\"/></p></td></tr></tbody></table><p><br/></p>', '2017/5/1', '0', '1588140758', '1588140758', '1');
INSERT INTO `dp_home_cases` VALUES ('6', '204', '成功案例', '<table width=\"930\" align=\"center\"><tbody style=\"margin: 0px; padding: 0px;\"><tr style=\"margin: 0px; padding: 0px; outline: none;\" class=\"firstRow\"><td align=\"left\" style=\"margin: 0px; padding: 10px 0px; outline: none; line-height: 28px; background-image: url(&quot;/image/alcbg.jpg&quot;); background-position: initial; background-size: initial; background-repeat: repeat-y; background-attachment: initial; background-origin: initial; background-clip: initial;\"><p><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154857_6767.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154857_7548.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154857_8173.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154857_8642.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154857_9580.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154858_0048.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154858_0673.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154858_1611.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154858_2080.jpg\" alt=\"\"/><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20170327/20170327154858_2705.jpg\" alt=\"\"/></p></td></tr></tbody></table><p><br/></p>', '2017/5/1', '0', '1588140792', '1588140792', '1');

-- -----------------------------
-- Table structure for `dp_home_contactus`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_contactus`;
CREATE TABLE `dp_home_contactus` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `content` varchar(255) NOT NULL COMMENT '简介',
  `point` varchar(255) NOT NULL COMMENT '经纬度',
  `icon` int(11) unsigned NOT NULL COMMENT 'icon',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='联系我们/联系方式';

-- -----------------------------
-- Records of `dp_home_contactus`
-- -----------------------------
INSERT INTO `dp_home_contactus` VALUES ('1', '一纸馋总部', '一纸馋隶属于成都餐协餐饮管理有限公司', '104.077874,30.669242', '207', '0', '1588212943');

-- -----------------------------
-- Table structure for `dp_home_contactus_img`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_contactus_img`;
CREATE TABLE `dp_home_contactus_img` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `img` int(11) NOT NULL COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `pag` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0,1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='联系我们/联系方式';

-- -----------------------------
-- Records of `dp_home_contactus_img`
-- -----------------------------
INSERT INTO `dp_home_contactus_img` VALUES ('1', '205', '1', '1', '1', '1588151533', '1588151533', '1', '0');
INSERT INTO `dp_home_contactus_img` VALUES ('2', '206', '2', '2', '2', '1588151548', '1588151548', '1', '1');

-- -----------------------------
-- Table structure for `dp_home_contactus_message`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_contactus_message`;
CREATE TABLE `dp_home_contactus_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT '姓名',
  `phone` varchar(255) NOT NULL DEFAULT '' COMMENT '电话',
  `email` varchar(255) NOT NULL DEFAULT '' COMMENT '邮箱',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '地址',
  `content` text NOT NULL COMMENT '消息内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `ip` varchar(255) NOT NULL COMMENT 'IP地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `read_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='消息表';

-- -----------------------------
-- Records of `dp_home_contactus_message`
-- -----------------------------
INSERT INTO `dp_home_contactus_message` VALUES ('1', '黄海平', '13219294337', '773916571@qq.com', '/', '', '0', '127.0.0.1', '1588522176', '0');

-- -----------------------------
-- Table structure for `dp_home_food`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_food`;
CREATE TABLE `dp_home_food` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `url` varchar(255) NOT NULL COMMENT '跳转链接',
  `img` varchar(11) NOT NULL DEFAULT '' COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='首页/美食中心';

-- -----------------------------
-- Records of `dp_home_food`
-- -----------------------------
INSERT INTO `dp_home_food` VALUES ('1', '/index/food/index.html?cat=12', '27', '海鲜拼盘', '海鲜拼盘', '4', '1587457777', '1588218876', '1');
INSERT INTO `dp_home_food` VALUES ('2', '/index/food/index.html?cat=10', '28', '三线五花肉', '三线五花肉', '1', '1587631814', '1588218258', '1');
INSERT INTO `dp_home_food` VALUES ('3', '/index/food/index.html?cat=10', '29', '猪颈肉', '猪颈肉', '2', '1587631863', '1588218329', '1');
INSERT INTO `dp_home_food` VALUES ('4', '/index/food/index.html?cat=10', '30', '牛肉拼盘', '牛肉拼盘', '3', '1587631907', '1588218352', '1');
INSERT INTO `dp_home_food` VALUES ('5', '/index/food/index.html?cat=14', '31', '特色小吃', '特色小吃', '5', '1587631930', '1588218889', '1');

-- -----------------------------
-- Table structure for `dp_home_foods`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_foods`;
CREATE TABLE `dp_home_foods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `pid` int(11) NOT NULL COMMENT '所属分页id',
  `img` int(11) NOT NULL COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `pag` tinyint(2) NOT NULL DEFAULT '0' COMMENT '1,2,3,4',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8 COMMENT='美食中心';

-- -----------------------------
-- Records of `dp_home_foods`
-- -----------------------------
INSERT INTO `dp_home_foods` VALUES ('1', '10', '72', '1', '1', '1', '1587952807', '1587952807', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('2', '10', '73', '2', '2', '2', '1587952830', '1587952830', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('3', '10', '74', '3', '3', '3', '1587952847', '1587952847', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('4', '10', '75', '4', '4', '4', '1587952969', '1587952969', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('5', '10', '76', '5', '5', '5', '1587953002', '1587953002', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('6', '10', '77', '6', '6', '6', '1587953321', '1587953345', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('7', '10', '78', '0', '0', '0', '1587953551', '1587953551', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('8', '10', '79', '1', '1', '1', '1587953767', '1587953767', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('9', '10', '80', '2', '2', '2', '1587953915', '1587953915', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('10', '10', '81', '3', '3', '3', '1587953963', '1587953963', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('11', '10', '82', '4', '4', '4', '1587954101', '1587954101', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('12', '10', '83', '5', '5', '5', '1587954125', '1587954125', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('13', '10', '84', '6', '6', '6', '1587954143', '1587954143', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('14', '10', '85', '7', '7', '7', '1587954159', '1587954159', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('15', '10', '86', '8', '8', '8', '1587954176', '1587954176', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('16', '10', '78', '10', '10', '10', '1587954216', '1587954216', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('17', '10', '87', '1', '1', '1', '1587954296', '1587954296', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('18', '10', '88', '2', '2', '2', '1587954311', '1587954311', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('19', '10', '89', '3', '3', '3', '1587954326', '1587954326', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('20', '10', '90', '4', '4', '4', '1587954340', '1587954340', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('21', '10', '91', '5', '5', '5', '1587954357', '1587954357', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('22', '10', '92', '7', '7', '7', '1587954383', '1587954383', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('23', '10', '93', '8', '8', '8', '1587954405', '1587954405', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('24', '10', '94', '9', '9', '9', '1587954421', '1587954421', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('25', '10', '95', '10', '10', '10', '1587954444', '1587954444', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('26', '11', '121', '1', '1', '1', '1588036405', '1588036405', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('27', '11', '122', '2', '2', '2', '1588036420', '1588036420', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('28', '11', '123', '3', '3', '3', '1588036434', '1588036434', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('29', '11', '124', '4', '4', '4', '1588036447', '1588036447', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('30', '11', '125', '5', '5', '5', '1588036462', '1588036462', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('31', '11', '126', '6', '6', '6', '1588036478', '1588036478', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('32', '11', '127', '7', '7', '7', '1588036493', '1588036493', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('33', '11', '128', '8', '8', '8', '1588036508', '1588036525', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('34', '11', '129', '9', '9', '9', '1588036547', '1588036547', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('35', '11', '130', '10', '10', '10', '1588036568', '1588036568', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('36', '11', '78', '0', '0', '0', '1588036603', '1588036603', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('37', '11', '131', '1', '1', '1', '1588036635', '1588036635', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('38', '11', '132', '2', '2', '2', '1588036652', '1588036652', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('39', '11', '133', '3', '3', '3', '1588036665', '1588036665', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('40', '11', '134', '4', '4', '4', '1588036687', '1588036687', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('41', '11', '135', '5', '5', '5', '1588036700', '1588036700', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('42', '11', '136', '6', '6', '6', '1588036712', '1588036712', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('43', '11', '137', '7', '7', '7', '1588036727', '1588036727', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('44', '11', '138', '8', '8', '8', '1588036740', '1588036740', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('45', '11', '78', '10', '10', '10', '1588036763', '1588036763', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('46', '11', '139', '1', '1', '1', '1588036794', '1588036794', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('47', '11', '140', '2', '2', '2', '1588036809', '1588036809', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('48', '11', '141', '3', '3', '3', '1588036823', '1588036823', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('49', '11', '142', '4', '4', '4', '1588036835', '1588036835', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('50', '11', '143', '5', '5', '5', '1588036849', '1588036849', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('51', '11', '144', '6', '6', '6', '1588036864', '1588036864', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('52', '11', '145', '7', '7', '7', '1588036877', '1588036877', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('53', '12', '208', '1', '1', '1', '1588215064', '1588215064', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('54', '12', '209', '2', '2', '2', '1588215081', '1588215081', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('55', '12', '210', '3', '3', '3', '1588215102', '1588215102', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('56', '12', '211', '4', '4', '4', '1588215116', '1588215116', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('57', '12', '212', '5', '5', '5', '1588215132', '1588215132', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('58', '12', '213', '6', '6', '6', '1588215147', '1588215147', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('59', '12', '214', '7', '7', '7', '1588215164', '1588215164', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('60', '12', '215', '8', '8', '8', '1588215180', '1588215180', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('61', '12', '216', '9', '9', '9', '1588215201', '1588215201', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('62', '12', '217', '10', '10', '10', '1588215217', '1588215217', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('63', '12', '78', '0', '0', '0', '1588215279', '1588215279', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('64', '12', '218', '1', '1', '1', '1588215310', '1588215310', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('65', '12', '219', '2', '2', '2', '1588215324', '1588215324', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('66', '12', '220', '3', '3', '3', '1588215344', '1588215344', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('67', '12', '221', '4', '4', '4', '1588215367', '1588215367', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('68', '12', '222', '5', '5', '5', '1588215384', '1588215384', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('69', '12', '223', '6', '6', '6', '1588215399', '1588215399', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('70', '12', '224', '7', '7', '7', '1588215414', '1588215414', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('71', '12', '225', '8', '8', '8', '1588215430', '1588215430', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('72', '12', '78', '10', '10', '10', '1588215449', '1588215449', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('73', '12', '226', '1', '1', '1', '1588215487', '1588215487', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('74', '12', '227', '2', '2', '2', '1588215504', '1588215504', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('75', '12', '228', '3', '3', '3', '1588215520', '1588215520', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('76', '12', '229', '4', '4', '4', '1588215533', '1588215533', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('77', '12', '230', '5', '5', '5', '1588215549', '1588215549', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('78', '12', '231', '6', '6', '6', '1588215564', '1588215564', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('79', '12', '232', '7', '7', '7', '1588215578', '1588215578', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('80', '12', '233', '8', '8', '8', '1588215592', '1588215592', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('81', '12', '234', '9', '9', '9', '1588215607', '1588215607', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('82', '13', '235', '1', '1', '1', '1588215638', '1588215638', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('83', '13', '236', '2', '2', '2', '1588215653', '1588215653', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('84', '13', '237', '3', '3', '3', '1588215669', '1588215669', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('85', '12', '238', '4', '4', '4', '1588215686', '1588215686', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('86', '13', '239', '5', '5', '5', '1588215701', '1588215701', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('87', '13', '240', '6', '6', '6', '1588215718', '1588215718', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('88', '13', '241', '7', '7', '7', '1588215736', '1588215736', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('89', '13', '242', '8', '8', '8', '1588215754', '1588215754', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('90', '13', '243', '9', '9', '9', '1588215772', '1588215772', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('91', '13', '244', '10', '10', '10', '1588215807', '1588215807', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('92', '13', '78', '0', '0', '0', '1588215838', '1588215838', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('93', '13', '245', '1', '1', '1', '1588215864', '1588215864', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('94', '13', '246', '2', '2', '2', '1588215884', '1588215884', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('95', '13', '247', '3', '3', '3', '1588215925', '1588215925', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('96', '13', '248', '4', '4', '4', '1588215947', '1588215947', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('97', '13', '249', '5', '5', '5', '1588215966', '1588215966', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('98', '13', '251', '6', '6', '6', '1588215991', '1588216019', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('99', '13', '250', '7', '7', '7', '1588216038', '1588216038', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('100', '13', '252', '8', '8', '8', '1588216055', '1588216055', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('101', '13', '78', '10', '10', '10', '1588216077', '1588216077', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('102', '13', '253', '1', '1', '1', '1588216103', '1588216103', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('103', '13', '254', '2', '2', '2', '1588216116', '1588216116', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('104', '13', '255', '3', '3', '3', '1588216129', '1588216129', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('105', '13', '256', '4', '4', '4', '1588216141', '1588216141', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('106', '13', '257', '5', '5', '5', '1588216157', '1588216157', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('107', '14', '258', '1', '1', '1', '1588216215', '1588216215', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('108', '14', '259', '2', '2', '2', '1588216231', '1588216231', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('109', '14', '260', '3', '3', '3', '1588216244', '1588216244', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('110', '14', '261', '4', '4', '4', '1588216258', '1588216258', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('111', '14', '262', '5', '5', '5', '1588216275', '1588216275', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('112', '14', '263', '6', '6', '6', '1588216291', '1588216291', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('113', '14', '264', '7', '7', '7', '1588216307', '1588216307', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('114', '14', '265', '8', '8', '8', '1588216321', '1588216321', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('115', '14', '266', '9', '9', '9', '1588216336', '1588216336', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('116', '14', '267', '10', '10', '10', '1588216355', '1588216355', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('117', '14', '78', '0', '0', '0', '1588216375', '1588216375', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('118', '14', '268', '1', '1', '1', '1588216398', '1588216398', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('119', '14', '269', '2', '2', '2', '1588216410', '1588216410', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('120', '14', '270', '3', '3', '3', '1588216424', '1588216424', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('121', '14', '271', '4', '4', '4', '1588216437', '1588216437', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('122', '14', '272', '5', '5', '5', '1588216450', '1588216450', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('123', '14', '273', '6', '6', '6', '1588216466', '1588216466', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('124', '14', '274', '7', '7', '7', '1588216481', '1588216481', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('125', '14', '275', '8', '8', '8', '1588216496', '1588216496', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('126', '14', '78', '10', '10', '10', '1588216511', '1588216511', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('127', '14', '276', '1', '1', '1', '1588216534', '1588216534', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('128', '14', '277', '2', '2', '2', '1588216547', '1588216547', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('129', '14', '278', '3', '3', '3', '1588216563', '1588216563', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('130', '14', '279', '4', '4', '4', '1588216576', '1588216576', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('131', '14', '280', '5', '5', '5', '1588216588', '1588216588', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('132', '15', '281', '1', '1', '1', '1588216682', '1588216682', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('133', '15', '282', '2', '2', '2', '1588216705', '1588216705', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('134', '15', '283', '3', '3', '3', '1588216718', '1588216718', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('135', '15', '284', '4', '4', '4', '1588216730', '1588216730', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('136', '15', '285', '5', '5', '5', '1588216743', '1588216743', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('137', '15', '286', '6', '6', '6', '1588216768', '1588216768', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('138', '15', '287', '7', '7', '7', '1588216786', '1588216786', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('139', '15', '288', '8', '8', '8', '1588216801', '1588216801', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('140', '15', '289', '9', '9', '9', '1588216825', '1588216825', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('141', '15', '290', '10', '10', '10', '1588216853', '1588216853', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('142', '15', '78', '0', '0', '0', '1588216911', '1588216911', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('143', '15', '291', '1', '1', '1', '1588216930', '1588216930', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('144', '15', '292', '2', '2', '2', '1588216943', '1588216943', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('145', '15', '293', '3', '3', '3', '1588216957', '1588216957', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('146', '15', '294', '4', '4', '4', '1588216971', '1588216971', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('147', '15', '295', '5', '5', '5', '1588216985', '1588216985', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('148', '15', '296', '6', '6', '6', '1588216999', '1588216999', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('149', '15', '78', '10', '10', '10', '1588217021', '1588217021', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('150', '15', '291', '1', '1', '1', '1588217036', '1588217036', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('151', '15', '292', '2', '2', '2', '1588217049', '1588217049', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('152', '15', '293', '3', '3', '3', '1588217062', '1588217062', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('153', '15', '294', '4', '4', '4', '1588217074', '1588217074', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('154', '15', '295', '5', '5', '5', '1588217087', '1588217087', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('155', '15', '296', '6', '6', '6', '1588217101', '1588217101', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('156', '16', '297', '1', '1', '1', '1588217127', '1588217127', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('157', '16', '298', '2', '2', '2', '1588217142', '1588217142', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('158', '16', '299', '3', '3', '3', '1588217158', '1588217158', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('159', '16', '300', '4', '4', '4', '1588217175', '1588217175', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('160', '16', '301', '5', '5', '5', '1588217190', '1588217190', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('161', '16', '302', '6', '6', '6', '1588217207', '1588217207', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('162', '16', '303', '7', '7', '7', '1588217224', '1588217224', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('163', '16', '304', '8', '8', '8', '1588217241', '1588217241', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('164', '16', '305', '9', '9', '9', '1588217263', '1588217263', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('165', '16', '306', '10', '10', '10', '1588217284', '1588217284', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('166', '16', '78', '0', '0', '0', '1588217303', '1588217324', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('167', '16', '307', '1', '1', '1', '1588217364', '1588217364', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('168', '16', '308', '2', '2', '2', '1588217379', '1588217379', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('169', '16', '309', '3', '3', '3', '1588217392', '1588217392', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('170', '16', '310', '4', '4', '4', '1588217407', '1588217407', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('171', '16', '311', '5', '5', '5', '1588217422', '1588217422', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('172', '16', '312', '6', '6', '6', '1588217441', '1588217441', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('173', '16', '313', '7', '7', '7', '1588217454', '1588217454', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('174', '16', '314', '8', '8', '8', '1588217468', '1588217468', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('175', '16', '78', '10', '10', '10', '1588217486', '1588217486', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('176', '16', '315', '1', '1', '1', '1588217505', '1588217505', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('177', '16', '316', '2', '2', '2', '1588217519', '1588217519', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('178', '16', '317', '3', '3', '3', '1588217532', '1588217532', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('179', '16', '318', '4', '4', '4', '1588217545', '1588217545', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('180', '17', '319', '1', '1', '1', '1588217630', '1588217630', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('181', '17', '320', '2', '2', '2', '1588217644', '1588217644', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('182', '17', '321', '3', '3', '3', '1588217657', '1588217657', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('183', '17', '322', '4', '4', '4', '1588217671', '1588217671', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('184', '17', '323', '5', '5', '5', '1588217687', '1588217687', '1', '1');
INSERT INTO `dp_home_foods` VALUES ('185', '17', '324', '6', '6', '6', '1588217702', '1588217702', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('186', '17', '325', '7', '7', '7', '1588217817', '1588217817', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('187', '17', '326', '8', '8', '8', '1588217832', '1588217832', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('188', '17', '327', '9', '9', '9', '1588217849', '1588217849', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('189', '17', '328', '101', '10', '10', '1588217868', '1588217868', '1', '4');
INSERT INTO `dp_home_foods` VALUES ('190', '17', '78', '0', '0', '0', '1588217887', '1588217887', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('191', '17', '329', '1', '1', '1', '1588217906', '1588217906', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('192', '17', '330', '2', '2', '2', '1588217919', '1588217919', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('193', '17', '331', '3', '3', '3', '1588217932', '1588217932', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('194', '17', '332', '4', '4', '4', '1588217946', '1588217946', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('195', '17', '333', '5', '5', '5', '1588217963', '1588217963', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('196', '17', '334', '6', '6', '6', '1588217979', '1588217979', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('197', '17', '335', '7', '7', '7', '1588217992', '1588217992', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('198', '17', '336', '8', '8', '8', '1588218006', '1588218006', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('199', '17', '78', '101', '10', '10', '1588218023', '1588218023', '1', '2');
INSERT INTO `dp_home_foods` VALUES ('200', '17', '337', '1', '1', '1', '1588218043', '1588218043', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('201', '17', '338', '2', '2', '2', '1588218056', '1588218056', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('202', '17', '339', '3', '3', '3', '1588218069', '1588218069', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('203', '17', '340', '4', '4', '4', '1588218082', '1588218082', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('204', '17', '341', '5', '5', '5', '1588218097', '1588218097', '1', '3');
INSERT INTO `dp_home_foods` VALUES ('205', '17', '342', '6', '6', '6', '1588218110', '1588218110', '1', '3');

-- -----------------------------
-- Table structure for `dp_home_media`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_media`;
CREATE TABLE `dp_home_media` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `text` varchar(4000) NOT NULL DEFAULT '' COMMENT '文本',
  `img` int(11) unsigned NOT NULL COMMENT '视频封面',
  `video` int(11) unsigned NOT NULL COMMENT '视频地址',
  `bg_img` int(11) unsigned NOT NULL COMMENT '背景图片',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='项目中心/媒体报道';

-- -----------------------------
-- Records of `dp_home_media`
-- -----------------------------
INSERT INTO `dp_home_media` VALUES ('1', '    自2012年至今，我们的开业店铺多达近千家。一纸馋品牌已经在全国拥有一定知名度，多次创造餐饮行业奇迹，各地开业门店 均创造了良好的运营业绩，是引领当地休闲餐饮消费的时尚先锋。我们的价值在于把握品牌、创新、品质的核心。我们的品牌绝非数字买卖，我们不断地思考和进步；我们将成为餐饮品牌领域， 最具有价值的创新领导者。我们时刻站在客户的角度思考问题，从品牌和根本利益出发寻找突破，并用“效率、专业、创新”的模式去实施这一过程，必将让您放心满意。', '166', '168', '158', '0', '1588148389');

-- -----------------------------
-- Table structure for `dp_home_media_img`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_media_img`;
CREATE TABLE `dp_home_media_img` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `img` int(11) NOT NULL COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `pag` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0,1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='项目中心/媒体报道';

-- -----------------------------
-- Records of `dp_home_media_img`
-- -----------------------------
INSERT INTO `dp_home_media_img` VALUES ('1', '156', '1', '1', '1', '1588055422', '1588055422', '1', '0');
INSERT INTO `dp_home_media_img` VALUES ('2', '157', '2', '2', '2', '1588055434', '1588055434', '1', '0');
INSERT INTO `dp_home_media_img` VALUES ('4', '159', '4', '4', '4', '1588055463', '1588055463', '1', '1');
INSERT INTO `dp_home_media_img` VALUES ('5', '160', '5', '5', '5', '1588055476', '1588055476', '1', '1');
INSERT INTO `dp_home_media_img` VALUES ('6', '161', '6', '6', '6', '1588055493', '1588055493', '1', '1');
INSERT INTO `dp_home_media_img` VALUES ('7', '162', '7', '7', '7', '1588055514', '1588055514', '1', '1');
INSERT INTO `dp_home_media_img` VALUES ('8', '163', '8', '8', '8', '1588055572', '1588055572', '1', '1');
INSERT INTO `dp_home_media_img` VALUES ('9', '164', '9', '9', '9', '1588055588', '1588055588', '1', '1');
INSERT INTO `dp_home_media_img` VALUES ('10', '165', '10', '10', '10', '1588055609', '1588055609', '1', '1');

-- -----------------------------
-- Table structure for `dp_home_news`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_news`;
CREATE TABLE `dp_home_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `pid` int(11) NOT NULL COMMENT '所属分页',
  `img` varchar(255) NOT NULL COMMENT '封面图',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `desc` varchar(255) NOT NULL COMMENT '简介',
  `text` mediumtext NOT NULL COMMENT '文章内容',
  `time` varchar(255) NOT NULL DEFAULT '' COMMENT '显示时间',
  `is_tui` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否首页',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='品牌动态';

-- -----------------------------
-- Records of `dp_home_news`
-- -----------------------------
INSERT INTO `dp_home_news` VALUES ('1', '29', '42', '四川什邡烤肉店加盟一纸馋开店是个备受青睐的商机吗?', '现目前餐饮市场上有许多烧烤品牌，然想在众多烧烤品牌中找到那个备受消费者青睐的烤肉品牌，还真的仔细斟酌。四川什邡烤肉店加盟一纸馋开店是个备受消费者与创业者青睐的创业商机吗?', '<p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">现目前餐饮市场上有许多烧烤品牌，然想在众多烧烤品牌中找到那个备受消费者青睐的烤肉品牌，还真的仔细斟酌。四川什邡烤肉店加盟一纸馋开店是个备受消费者与创业者青睐的创业商机吗<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">下面我们就围绕这个话题进行深度挖掘</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191122/20191122164311_3906.jpg\" alt=\"\" width=\"780\" height=\"598\" title=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">四川什邡烤肉店加盟一纸馋开店是个备受青睐的商机吗<span style=\"margin: 0px; padding: 0px;\">?</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">四川烤肉加盟哪家好<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">对于大多数创业想要开烤肉店的投资者来说，开烤肉店利润高吗，能否赚钱呢。如何经营提升自己的烤肉店规模利润成了投资创业者关注的核心问题。四川什邡烤肉店选择一纸馋开店怎样</span><span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">实际上，在经营我们烤肉店的时候，想要让自己的烤肉店利润得到大幅度的提升，主要需要开店投资者从自家店面的产品特色口味、店面的经营模式、以及菜品的食材质量三方面来做起。如果能够在这三方面做起打造一定的特色，我们的店面在市场上的知名度也必然会得到一定的提升。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191122/20191122164226_6718.jpg\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">一纸馋烤肉店加盟的创业优势<span style=\"margin: 0px; padding: 0px;\">?</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">一、连锁加盟标准化：加盟一纸馋烤肉的店面，均有统一的视觉系统，统一的经营管理，统一的原料购进，统一的产品配送，统一的员工培训，统一的服务流程。</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">二、品牌文化，稳定性更强：一纸馋烤肉以纸上无烟烧烤为主题的主题餐厅，集烧烤、火锅、炖锅、涮锅、饮品为一店，精选食材，秘制配方，并融合了素有<span style=\"margin: 0px; padding: 0px;\">“</span><span style=\"margin: 0px; padding: 0px;\">中华美食之都</span><span style=\"margin: 0px; padding: 0px;\">”</span><span style=\"margin: 0px; padding: 0px;\">之称的成都本地特色，不同于传统餐饮业以某种菜系为主题，而是结合多种美食风味、文化、时尚元素，满足各种食客的要求，与时俱进，持续保持市场活力的能力，成为一个有自己特色、包容性强、有长久生命力的品牌，可持续性发展经营</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">三、、一店四开化，全年火爆：烧烤<span style=\"margin: 0px; padding: 0px;\">+</span><span style=\"margin: 0px; padding: 0px;\">糯米纸</span><span style=\"margin: 0px; padding: 0px;\">+</span><span style=\"margin: 0px; padding: 0px;\">炖锅</span><span style=\"margin: 0px; padding: 0px;\">+</span><span style=\"margin: 0px; padding: 0px;\">涮锅</span><span style=\"margin: 0px; padding: 0px;\">+</span><span style=\"margin: 0px; padding: 0px;\">饮品</span><span style=\"margin: 0px; padding: 0px;\">=</span><span style=\"margin: 0px; padding: 0px;\">一店多盈，总部会提供每一种形式的技术指导，包教会</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">四、模式复制，去厨师化经营：我公司有成熟的管理运营等模式，一键式复制，轻松开店。总部全程帮扶，无需经验无需厨师，让你轻松当老板。</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">五、运营体系，轻松运营：总部拥有完善的内部运营体系，人事构架，薪酬体系，运营系统，晋升标准，管理分工落地，绩效机制等，并会提供内部运营体系手册，帮助连锁店轻松运营。<span style=\"margin: 0px; padding: 0px;\"></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191122/20191122164212_2656.png\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">四川什邡烤肉店加盟一纸馋开店是个备受青睐的商机吗</span><span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">不管社会发展到什么程度，餐饮这个行业是不会倒下去的。特别是随着人们对饮食的要求越来也高，烧烤这个行业也在迅速的崛起当中。选择这个行业是绝对正确的</span><span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">如果想了解水浒烤肉加盟费用多少钱，可以在线咨询或留言。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">加盟热线：</span><span style=\"margin: 0px; padding: 0px;\">400-0809-517</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">相关资讯：http://www.1zhichan.com/xwc2604.html</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp;</p><p><br/></p>', '2019/11/22', '1', '0', '1587519896', '1588037876', '1');
INSERT INTO `dp_home_news` VALUES ('2', '29', '43', '河南纸上烤肉加盟_开一家纸上烧烤需要多少资金', '烧烤是许多朋友非常喜欢的一种烹饪美食，特别是随着冬季的到来，在寒冷的冬季和亲朋好友围在一起边聊变烤，即促进之间的感情又能体会亲手制作烧烤的乐趣!那在河南开家纸上烤肉需要多少资金呢!', '<table width=\"930\" align=\"center\"><tbody style=\"margin: 0px; padding: 0px;\"><tr style=\"margin: 0px; padding: 0px; outline: none;\" class=\"firstRow\"><td align=\"left\" style=\"margin: 0px; padding: 10px 0px; outline: none; line-height: 28px;\"><p class=\"p\" style=\"outline: none;\">烧烤是许多朋友非常喜欢的一种烹饪美食，特别是随着冬季的到来，在寒冷的冬季和亲朋好友围在一起边聊变烤，即促进之间的感情又能体会亲手制作烧烤的乐趣<span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">那在河南开家纸上烤肉需要多少资金呢</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"outline: none; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191122/20191122163917_8125.jpg\" alt=\"\" width=\"780\" height=\"468\" title=\"\"/><br/></span></p><p class=\"p\" style=\"outline: none; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><br/></span></p><p class=\"p\" style=\"outline: none;\">河南纸上烤肉加盟<span style=\"margin: 0px; padding: 0px;\">_</span><span style=\"margin: 0px; padding: 0px;\">开一家纸上烧烤需要多少资金</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"outline: none;\">烧烤从古至今都是人们所喜欢的美食烹饪之一，由于烧烤深受广大消费者的喜爱，从而间接也导致烧烤成为餐饮市场上投资创业的热门行业，那在河南开家烤肉加盟店怎样<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">对于广大投资者而言，一纸馋纸上烧烤加盟连锁店，既能满足消费者一店多吃，消费又低的绿色、健康美味需求。河南纸上烤肉加盟一纸馋纸上烧烤开店有什么经营优势</span><span style=\"margin: 0px; padding: 0px;\">?</span></p><p class=\"p\" style=\"outline: none; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191122/20191122163729_1406.jpg\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"outline: none;\"><span style=\"margin: 0px; padding: 0px;\">1</span><span style=\"margin: 0px; padding: 0px;\">、品牌优势：一纸馋纸上烤肉一直在各大媒体不断进行广告宣传，已建立了自己的连锁网络，&nbsp;树立了较好的品牌形象，在业内具有极高的声誉和影响力。</span></p><p class=\"p\" style=\"outline: none;\"><span style=\"margin: 0px; padding: 0px;\">2</span><span style=\"margin: 0px; padding: 0px;\">、产品优势：一纸馋烤肉自面市以来，一直备受年轻消费群体的喜爱，现有的加盟体系中，大半的加盟商来自一纸馋纸上烧烤店的消费者，部分加盟商还开了二店、三店、区域代理，形成了</span><span style=\"margin: 0px; padding: 0px;\">“</span><span style=\"margin: 0px; padding: 0px;\">昔日休闲消费，今日投资开店</span><span style=\"margin: 0px; padding: 0px;\">”</span><span style=\"margin: 0px; padding: 0px;\">的一时佳话。</span></p><p class=\"p\" style=\"outline: none;\"><span style=\"margin: 0px; padding: 0px;\">3</span><span style=\"margin: 0px; padding: 0px;\">、技术优势：总部拥有超强的研发团队，具有丰富的产品创新能力，能够快速适应市场变化。</span></p><p class=\"p\" style=\"outline: none;\"><span style=\"margin: 0px; padding: 0px;\">4</span><span style=\"margin: 0px; padding: 0px;\">、培训优势：一纸馋烤肉已经形成了相当成熟的运营培训模式，营销中心根据各地经销商对产品知识培训与销售培训进行免费培训。</span></p><p class=\"p\" style=\"outline: none;\"><span style=\"margin: 0px; padding: 0px;\">5</span><span style=\"margin: 0px; padding: 0px;\">、服务优势：常年营销指导，财务分析，系统的管理培训，新品指导，公司成功的经验复制。</span></p><p class=\"p\" style=\"outline: none;\"><span style=\"margin: 0px; padding: 0px;\">6</span><span style=\"margin: 0px; padding: 0px;\">、投资优势：如今</span>一纸馋纸上烤肉加盟店数量日渐上涨，市场占领份额也在不断扩大，选择加盟一纸馋纸上烧烤，胜券在握。开一家纸上烧烤需要多少资金？几万元就可创业开家一店顶多店收入，3<span style=\"margin: 0px; padding: 0px;\">月就可回本的赚钱餐饮店！</span></p><p class=\"p\" style=\"outline: none; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191122/20191122163700_6093.png\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"outline: none;\">随着经济效益的提升，烧烤市场加盟品牌愈加增多，而且大多数烤肉的口味都非常好吃，所以自然而然就吸引了众多消费者的青睐，盈利空间当然也就上涨。河南纸上烤肉加盟<span style=\"margin: 0px; padding: 0px;\">_</span><span style=\"margin: 0px; padding: 0px;\">开一家纸上烧烤需要多少资金</span><span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">一纸馋一个特色品牌，丰富食材，好吃健康，市场广阔，有好的需求，支持多多，精心制作，新鲜健康，经营轻松，几万元低成本投入就能开家，发展领域广，一店定多店收入利润加盟连锁店。烤肉加盟一纸馋，值得那你选择的致富商机好项目</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"outline: none;\">加盟热线<span style=\"margin: 0px; padding: 0px;\">;400-0809-517</span></p><p class=\"p\" style=\"outline: none;\"><span style=\"margin: 0px; padding: 0px;\">相关资讯：http://www.1zhichan.com/xwc2605.html</span></p></td></tr><tr style=\"margin: 0px; padding: 0px; outline: none;\"><td><br/></td></tr></tbody></table><p><br/></p>', '2019/11/21', '1', '0', '1587708948', '1588037891', '1');
INSERT INTO `dp_home_news` VALUES ('3', '29', '44', '河南许昌市纸上烤肉加盟一纸馋，消费者所追捧的热门品牌!', '随着大家的生活水平不断提高，许多消费者的消费观也逐渐发生改变。河南许昌市纸上烤肉加盟一纸馋创业开店好吗?一纸馋纸上烧烤充分满足消费者对美食的需求,一店可同时品尝多款不同口味、种类的美味!', '<p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp;&nbsp; &nbsp; 随着大家的生活水平不断提高，许多消费者的消费观也逐渐发生改变。河南许昌市纸上烤肉加盟一纸馋创业开店好吗<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">一纸馋纸上烧烤充分满足消费者对美食的需求</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">一店可同时品尝多款不同口味、种类的美味</span><span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">许多加盟商对</span><span style=\"margin: 0px; padding: 0px;\">“</span><span style=\"margin: 0px; padding: 0px;\">烤肉加盟</span><span style=\"margin: 0px; padding: 0px;\">”</span><span style=\"margin: 0px; padding: 0px;\">创业开店抱有很大的期望，下面小编就带大家了解一下如何避免创业加盟采坑</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191120/20191120155122_5312.jpg\" alt=\"\" width=\"780\" height=\"585\" title=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;&nbsp;<strong style=\"margin: 0px; padding: 0px;\">河南许昌市纸上烤肉加盟一纸馋，消费者所追捧的热门品牌</strong><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">!</strong></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 河南烤肉加盟一纸馋纸上烧烤的优势<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">一纸馋纸上无烟烧烤店内随处可见经典的韩式元素，背景音乐也是耳熟能详的韩文歌曲，音乐的氛围刚刚好，治愈却不聒噪。装修软饰、柔和灯光、从光线到桌椅的精心搭配，都足见老板对美食的诚意和用心。三两好友聚集在这里，肆意的聊天欢笑，一切都刚刚好。每一口都是幸福的味道</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 都说人类对美食的热爱是刻在基因里。不论是工作的压力、情感的伤痕、生活的不如意，伴随美食给人带来的强大食欲，都在美食果腹间被治愈。河南许昌市纸上烤肉加盟一纸馋店有多达几十种美食可供选择，地道的韩式料理应有尽有，这是属于所有肉食主义者的饕餮盛宴。</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-indent: 18pt;\">一纸馋烤肉加盟色香味俱佳，才能被誉为原汁原味的韩式烧烤。河南烤肉加盟哪家好烧烤品牌创业好<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">河南许昌市一纸馋纸上烤肉加盟店非常注重食材的品质，购进的韩牛嫩而不软，有着紧密的纹理和充盈的肉汁，单从卖相上来看已经足够让人着迷不已。还有肥瘦相间的五花，蘸上或辣或微甜的酱汁，裹上清爽可口的生菜叶，这样在传统中寓意着把福气包在其中，满满一口，吞下的都是幸福。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center; text-indent: 18pt;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191120/20191120155140_7500.jpg\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;<strong style=\"margin: 0px; padding: 0px;\">河南许昌市纸上烤肉加盟一纸馋，消费者所追捧的热门品牌</strong><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">!</strong></span>河南许昌市纸上烤肉加盟一纸馋无烟纸上烤肉的开店优势有哪些?</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 1</span><span style=\"margin: 0px; padding: 0px;\">、传统烧烤风情，美味诱惑，平价消费，人气很高</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 2</span><span style=\"margin: 0px; padding: 0px;\">、技能杜绝模仿</span><span style=\"margin: 0px; padding: 0px;\">“</span><span style=\"margin: 0px; padding: 0px;\">一纸馋创养生烧烤技能一一</span>电烤纸上无烟加热法，使得烤品鲜嫩，唇齿留香，技术难以模仿。</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 3</span><span style=\"margin: 0px; padding: 0px;\">、制作秘籍：采取</span><span style=\"margin: 0px; padding: 0px;\">“</span><span style=\"margin: 0px; padding: 0px;\">三翻四焦五烤熟</span><span style=\"margin: 0px; padding: 0px;\">”</span><span style=\"margin: 0px; padding: 0px;\">的秘诀，烤品鲜嫩、色香俱佳。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">异国风情饮食</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 4</span><span style=\"margin: 0px; padding: 0px;\">、一纸馋养生烧烤有肉类、蔬菜、海鲜、主食，完全符合现代人营养均衡、健康饮食的理念。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191120/20191120155157_9687.png\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 河南许昌市纸上烤肉加盟一纸馋，消费者所追捧的热门品牌<span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">想要从事烧烤加盟连锁品牌市场的加盟商，赶紧联系我们吧</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 加盟热线：400-0809-517</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 相关资讯：http://www.1zhichan.com/xwc2568.html</span></p><p><br/></p>', '2019/11/20', '1', '0', '1587709191', '1588037908', '1');
INSERT INTO `dp_home_news` VALUES ('4', '29', '45', '江苏南通烤肉加盟_一纸馋养生烧烤,美食致富！', '江苏南通烤肉加盟哪家好?一纸馋养生烧烤,美食致富商机!无需基础,免费培训;包教包会,学会为止;更低成本,省时省力;江苏烤肉加盟一纸馋创业的优势?整店输出,统一配送;下店指导,当地采购;区域保护,全程服务。', '<p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp;&nbsp; &nbsp; 江苏南通烤肉加盟哪家好<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">一纸馋养生烧烤</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">美食致富商机</span><span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">无需基础</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">免费培训</span><span style=\"margin: 0px; padding: 0px;\">;</span><span style=\"margin: 0px; padding: 0px;\">包教包会</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">学会为止</span><span style=\"margin: 0px; padding: 0px;\">;</span><span style=\"margin: 0px; padding: 0px;\">更低成本</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">省时省力</span><span style=\"margin: 0px; padding: 0px;\">;</span><span style=\"margin: 0px; padding: 0px;\">江苏烤肉加盟一纸馋创业的优势</span><span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">整店输出</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">统一配送</span><span style=\"margin: 0px; padding: 0px;\">;</span><span style=\"margin: 0px; padding: 0px;\">下店指导</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">当地采购</span><span style=\"margin: 0px; padding: 0px;\">;</span><span style=\"margin: 0px; padding: 0px;\">区域保护</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">全程服务。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191120/20191120154805_0625.jpg\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;&nbsp;<strong style=\"margin: 0px; padding: 0px;\">江苏南通烤肉加盟</strong><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">_</strong></span><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">一纸馋养生烧烤</strong></span><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">,</strong></span><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">美食致富商机</strong></span><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">!</strong></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 江苏烤肉加盟一纸馋连锁店是如何经营<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">一纸馋以纸上烧烤的方式代表着美食客探索烧烤时的创新</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">简单、干净又直接。一纸馋养生烧烤餐厅对于肉质的鲜美是一种创意激发</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">在翻烤的过程中挖掘肉的</span><span style=\"margin: 0px; padding: 0px;\">&quot;</span><span style=\"margin: 0px; padding: 0px;\">养分</span><span style=\"margin: 0px; padding: 0px;\">&quot;,</span><span style=\"margin: 0px; padding: 0px;\">并把它发扬光大</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">烤出的肉既营养又环保</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">解油解腻</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">释放烤肉的原始魅力。江苏南通烧烤店精选上等五花肉</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">新鲜专送而来</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">一片片层次均匀的摆放在韩风瓷盘中</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">色泽艳丽、肥瘦均匀相间</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">烤制过程中滋滋作响、香飘四溢</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">让人忍不住想立刻放入口中咀嚼享用</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">夹给身边的朋友分享。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191120/20191120154818_2656.jpg\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;&nbsp;<strong style=\"margin: 0px; padding: 0px;\">江苏南通烤肉加盟</strong><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">_</strong></span><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">一纸馋养生烧烤</strong></span><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">,</strong></span><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">美食致富商机</strong></span><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">!</strong></span><span style=\"margin: 0px; padding: 0px;\">耐心等待五分钟后</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">我把烤架上渐渐变得蜷曲的肉卷夹起来</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">稍微晾凉后</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">沾上一口秘制韩式烤肉调料</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">放入嘴里真是惊为天人的享受。</span>江苏南通烤肉加盟一纸馋无烟烧烤的开店经营优势？烤肉本身的腌制过程由韩国大厨专业配置的酱料完成<span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">极其入味</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">搭配融入了中国本土口感的蘸料</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">是味蕾跳跃与愉悦心情的双重叠加暴击</span><span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">品尝烤肉之余</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">还可以一并体验地道韩餐。泡菜、大酱汤、石锅拌饭、炒年糕、海鲜葱饼、南瓜汤</span><span style=\"margin: 0px; padding: 0px;\">……</span><span style=\"margin: 0px; padding: 0px;\">每一款都是想象中的可口味道</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">列举一遍就忍不住想要再去吃一遍。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191120/20191120154832_8593.png\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-indent: 18pt;\">江苏南通烤肉加盟一纸馋无烟纸上烧烤的优势是？产品内容得以组合升级，同时影响着消费场景的变化。餐协打造<span style=\"margin: 0px; padding: 0px;\">“</span><span style=\"margin: 0px; padding: 0px;\">纸上烤肉</span><span style=\"margin: 0px; padding: 0px;\">+</span><span style=\"margin: 0px; padding: 0px;\">纸上火锅</span><span style=\"margin: 0px; padding: 0px;\">”</span><span style=\"margin: 0px; padding: 0px;\">的新型餐饮模式让产品更融入生活</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">同时又能满足用户在新的消费场景下的需求在性价比、用户需求、消费场景</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">都得以满足的情况下实现餐饮共赢机制</span><span style=\"margin: 0px; padding: 0px;\">.</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-indent: 18pt;\"><span style=\"margin: 0px; padding: 0px;\">加盟热线：400-0809-517</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-indent: 18pt;\"><span style=\"margin: 0px; padding: 0px;\">相关资讯：http://www.1zhichan.com/xwc2568.html</span></p><p><br/></p>', '2019/11/19', '1', '0', '1587712036', '1588037919', '1');
INSERT INTO `dp_home_news` VALUES ('5', '29', '46', '江苏省南京市烤肉加盟一纸馋，创业小白能加盟吗?', '不管你做任何创业加盟项目之前都需了解整个市场的发展情况与市场占比,在确定是否要去投资。江苏省南京市烤肉加盟一纸馋,创业小白能加盟吗?一纸馋一条龙保姆式扶持,0基础,0风险,低成本,创业好商机!', '<p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp;&nbsp; &nbsp; 不管你做任何创业加盟项目之前都需了解整个市场的发展情况与市场占比<span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">在确定是否要去投资。江苏省南京市烤肉加盟一纸馋</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">创业小白能加盟吗</span><span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">一纸馋一条龙保姆式扶持</span><span style=\"margin: 0px; padding: 0px;\">,0</span><span style=\"margin: 0px; padding: 0px;\">基础</span><span style=\"margin: 0px; padding: 0px;\">,0</span><span style=\"margin: 0px; padding: 0px;\">风险</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">低成本</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">创业好商机</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191119/20191119154757_0937.jpg\" alt=\"\" width=\"780\" height=\"579\" title=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;<strong style=\"margin: 0px; padding: 0px;\">&nbsp;江苏省南京市烤肉加盟一纸馋，创业小白能加盟吗</strong><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">?</strong></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 江苏烤肉店加盟哪个品牌好<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">只要是烤肉</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">就不得不说一纸馋特色烤肉加盟店了</span><span style=\"margin: 0px; padding: 0px;\">.</span><span style=\"margin: 0px; padding: 0px;\">传统烤肉带来的烟雾是很难忍受的</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">这样就制约着品牌的发展步调</span><span style=\"margin: 0px; padding: 0px;\">.</span><span style=\"margin: 0px; padding: 0px;\">而采用现代化烧烤设备的一纸馋韩式烤肉绝对不会让此类情况发生</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">环保烤肉</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">无油烟</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">烤制过程卫生健康</span><span style=\"margin: 0px; padding: 0px;\">.</span><span style=\"margin: 0px; padding: 0px;\">这种烤肉类的美食非常的美味</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">因此能更好的满足人们的味蕾需求</span><span style=\"margin: 0px; padding: 0px;\">.</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191119/20191119154818_3593.jpg\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;&nbsp;<strong style=\"margin: 0px; padding: 0px;\">江苏南京市烤肉加盟一纸馋，创业小白也能加盟</strong>创业开店的致富商机<span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">江苏烤肉加盟一纸馋纸上烤肉的优势</span><span style=\"margin: 0px; padding: 0px;\">?</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 1.</span><span style=\"margin: 0px; padding: 0px;\">线下加盟店多的品牌：只有当一个品牌有市场才能证明它的价值，加盟店铺数量大、遍布地区广，表明了鹿角巷店加盟品牌的成功，选择这样的项目才能保证创业者在后期经营过程中总部能及时给予多方面的扶持，降低失败率。市场是不断发展的，品牌也应该顺势而为，一直墨守成规将被市场淘汰。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 2.</span><span style=\"margin: 0px; padding: 0px;\">加盟品牌的成立年限：创业者在选择加盟品牌时要优先考虑成熟的品牌，</span><span style=\"margin: 0px; padding: 0px;\">3-5</span><span style=\"margin: 0px; padding: 0px;\">以上为佳，它的发展年限已经比较久了，说明它具备完善的经营体系以及服务体系，才是给创业者在经营过程中持续发力。</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 3.</span><span style=\"margin: 0px; padding: 0px;\">产品的味道很重要：餐饮味道为王，这一点相信不用我多说大家也有了解，不能忘却的味道才是你留住顾客的痛点。选择</span>-鹿角巷加盟品牌时一定要到实体店品一品味道，这样你才能了解更多的品牌信息以及这个味道能否留住消费者。</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 4.</span><span style=\"margin: 0px; padding: 0px;\">后续服务扶持工作：这是对于第一次选择</span>鹿角巷加盟品牌经营的新手要特别注意的点，因为在选择的时候不仅仅是老品牌的重要性，还有售后服务的重要性，因为一个品牌的好坏都会在售后服务中体现出来，比如：选址、装修、运营等不能给投资者一个好的支持，那么对于新手来说就是会导致后期的经营失败。</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191119/20191119154834_4687.png\" alt=\"\"/></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;&nbsp;<strong style=\"margin: 0px; padding: 0px;\">江苏省南京市烤肉加盟一纸馋，创业小白能加盟吗</strong><span style=\"margin: 0px; padding: 0px;\"><strong style=\"margin: 0px; padding: 0px;\">?</strong></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 江苏省南京市烤肉店加盟哪个品牌好<span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">哪个烤肉品牌更有优势</span><span style=\"margin: 0px; padding: 0px;\">?</span><span style=\"margin: 0px; padding: 0px;\">一纸馋这个烤肉店加盟项目有着非常独特的项目优势</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">以上也都为大家介绍了</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">希望能为每一位选择这个品牌项目的投资者有所帮助</span><span style=\"margin: 0px; padding: 0px;\">.</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 加盟热线：400-0809-517</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 相关资讯：http://www.1zhichan.com/xwc2598.html</span></p>', '2019/11/18', '1', '0', '1587712144', '1588037930', '1');
INSERT INTO `dp_home_news` VALUES ('6', '28', '146', '热烈祝贺贵州龙里涮烤吧正式开店营业！', '热烈祝贺贵州龙里涮烤吧正式开店营业！', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(54, 53, 53); font-family: &quot;background-color:#FFFFFF;&quot;;\">好消息！好消息！好消息！重要的事情说三遍！这不，</span><strong style=\"margin: 0px; padding: 0px;\"><a href=\"http://www.1zhichan.com/xwc2027.html\" target=\"_blank\" style=\"margin: 0px; padding: 0px; text-decoration-line: none; color: rgb(51, 51, 51);\"><span style=\"margin: 0px; padding: 0px; color: rgb(229, 51, 51);\">一纸馋纸上烤肉店</span></a></strong><span style=\"margin: 0px; padding: 0px; color: rgb(54, 53, 53); font-family: &quot;background-color:#FFFFFF;&quot;;\">加盟在贵州龙里迎来了新成员，一场别开生面的开业典礼让到场观礼的美食爱好者享受到了一场视听觉盛宴。</span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px; color: rgb(54, 53, 53); font-family: &quot;background-color:#FFFFFF;&quot;;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20180621/20180621152952_5297.jpg\" alt=\"\"/><br/></span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px; color: rgb(54, 53, 53); font-family: &quot;background-color:#FFFFFF;&quot;;\"></span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp;&nbsp; &nbsp; 联系电话：400 0809 517</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;官网查询：www.1zhichan.com</p><p><br/></p>', '2018/6/21', '0', '0', '1588038046', '1588038046', '1');
INSERT INTO `dp_home_news` VALUES ('7', '28', '147', '热烈祝贺资中球溪涮烤吧正式开店营业！', '热烈祝贺资中球溪涮烤吧正式开店营业！', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;&nbsp;<span style=\"margin: 0px; padding: 0px; color: rgb(54, 53, 53); font-family: &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">好消息！好消息！好消息！重要的事情说三遍！这不，</span><strong style=\"margin: 0px; padding: 0px;\"><a href=\"http://www.1zhichan.com/xwc2027.html\" target=\"_blank\" style=\"margin: 0px; padding: 0px; text-decoration-line: none; color: rgb(51, 51, 51);\"><span style=\"margin: 0px; padding: 0px; color: rgb(229, 51, 51);\">一纸馋纸上烤肉店</span></a></strong><span style=\"margin: 0px; padding: 0px; color: rgb(54, 53, 53); font-family: &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">加盟在资中球溪迎来了新成员，一场别开生面的开业典礼让到场观礼的美食爱好者享受到了一场视听觉盛宴。</span></p><p style=\"text-align:center\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106142044_3935.jpg\" alt=\"\"/></p><p style=\"text-align:center\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106142053_6278.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;联系电话：400 0809 517</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;官网查询：www.1zhichan.com</p><p><br/></p>', '2017/11/4', '0', '0', '1588038224', '1588038224', '1');
INSERT INTO `dp_home_news` VALUES ('8', '28', '148', '热烈祝贺达州一纸馋自助涮烤吧盛大开业！', '热烈祝贺达州一纸馋自助涮烤吧盛大开业！', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">&nbsp; &nbsp; &nbsp; &nbsp;一纸馋”达州自助涮烤吧火爆开业，新鲜挑逗味蕾！人气爆棚先不说美味，人气到底怎么样呢？不多说，请看图，有图有真相！</span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106140707_5966.jpg\" alt=\"\"/><br/></span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106140721_5341.jpg\" alt=\"\"/><br/></span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106140730_5341.jpg\" alt=\"\"/><br/></span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106140746_8778.jpg\" alt=\"\"/><br/></span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">&nbsp; &nbsp; &nbsp; 不管前面美食有多美味，往往都离不开我们在后厨工作的朋友，他们创造美食，消费者们享受美食....！看我们的老板为满足当地人饮食口味一直在</span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">和<a href=\"http://www.1zhichan.com/xwc2029.html\" target=\"_blank\" style=\"margin: 0px; padding: 0px; text-decoration-line: none; color: rgb(51, 51, 51);\"><span style=\"margin: 0px; padding: 0px; color: rgb(229, 51, 51);\">一纸馋烤肉</span></a>加盟总部派来的驻店老师调整烤肉口味和不懂地方都积极的请教改正。</span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\"></span></p><p style=\"text-align:center\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106140758_4091.jpg\" alt=\"\"/></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106140807_5497.jpg\" alt=\"\"/><br/></span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<span style=\"margin: 0px; padding: 0px;\">联系电话：400 08809 517</span><br/></span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">&nbsp; &nbsp; &nbsp; &nbsp; 官网查询：www.1zhichan.com</span></p><p><br/></p>', '2017/10/25', '0', '0', '1588038623', '1588038623', '1');
INSERT INTO `dp_home_news` VALUES ('9', '28', '149', '热烈祝贺一纸馋黑龙江伊春店盛大开业！', '热烈祝贺一纸馋黑龙江伊春店盛大开业！', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">一纸馋”黑龙江伊春店火爆开业，新鲜挑逗味蕾！人气爆棚先不说美味，人气到底怎么样呢？不多说，请看图，有图有真相！</span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106140131_4091.jpg\" alt=\"\"/><br/></span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106142835_1903.jpg\" alt=\"\"/><br/></span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106142843_5028.jpg\" alt=\"\"/><br/></span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">&nbsp; &nbsp; &nbsp; &nbsp;联系电话：400 0809 517</span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: arial, &quot;font-size:14px;background-color:#FFFFFF;&quot;;\">&nbsp; &nbsp; &nbsp; &nbsp;官网查询：www.1zhichan.com</span></p><p><br/></p>', '2017/10/17', '0', '0', '1588039671', '1588039671', '1');
INSERT INTO `dp_home_news` VALUES ('10', '28', '150', '烤肉加盟|热烈祝贺甘肃碧口店一纸馋隆重开业！', '烤肉加盟|热烈祝贺甘肃碧口店一纸馋隆重开业！', '<table width=\"930\" align=\"center\"><tbody style=\"margin: 0px; padding: 0px;\"><tr style=\"margin: 0px; padding: 0px; outline: none;\" class=\"firstRow\"><td align=\"left\" style=\"margin: 0px; padding: 10px 0px; outline: none; line-height: 28px;\"><p style=\"outline: none;\"><span style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; &nbsp;一纸馋甘肃碧口店</span><span style=\"margin: 0px; padding: 0px;\">终于在紧赶慢赶中完工开业。餐饮行业创业本身就是一个不错的选择，<a href=\"http://www.1zhichan.com/xwc2030.html\" target=\"_blank\" style=\"margin: 0px; padding: 0px; text-decoration-line: none; color: rgb(51, 51, 51);\"><strong style=\"margin: 0px; padding: 0px;\">一纸馋无烟纸上烤肉</strong></a>从消费者的口味、产品种类、制作方法新奇上取得进一步升级，让来到一纸馋的朋友们都能满意而归！！！</span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106134943_2060.jpg\" alt=\"\"/><br/></span></p><p style=\"outline: none; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106134957_7372.jpg\" alt=\"\"/></span></p><p style=\"outline: none;\"><span style=\"margin: 0px; padding: 0px;\">产品多种类多、口味多、你来一次都不定能品尝完我们的菜品！</span><img src=\"http://www.1zhichan.com/user/kindeditor/plugins/emoticons/images/0.gif\" alt=\"\"/><span style=\"margin: 0px; padding: 0px;\"></span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106135006_6435.jpg\" alt=\"\"/><br/></span></p><p style=\"text-align:center\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20171106/20171106135015_3466.jpg\" alt=\"\"/><br/></span></p><p style=\"outline: none;\"><br/></p></td></tr><tr style=\"margin: 0px; padding: 0px; outline: none;\"><td><br/></td></tr></tbody></table><p><br/></p>', '2017/10/3', '1', '0', '1588039806', '1588039806', '1');
INSERT INTO `dp_home_news` VALUES ('11', '30', '151', '成都餐协:平安夜过后就是圣诞节,你的朋友圈是否还差这张“贺卡”', '圣诞节的发由来:大家都知道,每年的12月25日是「圣诞节」它是一个传统的西方节日。人们都会提前准备好食物、礼物、装饰物等,然后全家一起吃一顿火鸡大餐来庆祝平安夜……节日气氛就像我国的「春节」一样。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">“叮叮当叮叮当铃儿响叮当……”</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">哈喽!大家好!又到了一年一度的圣诞节啦，小数在这里祝大家椭圆极限快乐!(“剩蛋”永远快乐)不知道大家有没有像小数一样，早已在床边挂好了圣诞袜，等着圣诞老人的礼物呢!</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191225/20191225141032_1547.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">圣诞节的发由来：大家都知道，每年的12月25日是「圣诞节」，它是一个传统的西方节日。每逢圣诞节，人们都会提前准备好食物、礼物、装饰物等，然后全家一起吃一顿火鸡大餐来庆祝平安夜、点亮圣诞树、交换礼物、唱圣诞颂歌……节日气氛就像我国的「春节」一样。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">也许有人会知道，圣诞节本是一个宗教节日，并且为了庆祝耶稣的出生，它又名“耶诞节”。十九世纪，圣诞卡和圣诞老人的出现，使圣诞节也渐渐流行了起来。圣诞庆祝习俗在北欧流行后，结合着北半球冬季的圣诞装饰也出现了。十九世纪初发展至中叶，整个欧洲、美洲开始过起了圣诞节，并衍生出了相应的圣诞文化。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20191225/20191225141057_4047.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">2019年即将完结，你的“圣诞祝贺卡”准备好了吗?</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">还没准备好的欢迎来这看看，成都餐协新推出几张做工精美又时尚的卡纸，看看有你满意的不!</p><p><br/></p>', '2019/12/25', '0', '0', '1588039992', '1588039992', '1');
INSERT INTO `dp_home_news` VALUES ('12', '30', '152', '成都餐协餐饮管理有限公司——备货通知!', '成都餐协餐饮管理有限公司——备货通知!尊敬的客户:您好!感谢您长期以来对我们公司的支持与信任!国庆节来临之际,因国庆70周年大阅兵隆重召开,北方物流9月22停止发货,南方物流9月25日停止发货...', '<p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\">重磅消息</span>!!</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\">根据</span>2019<span style=\"margin: 0px; padding: 0px;\">年国庆节放假时间</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190927/20190927173929_5937.png\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px;\">成都餐协餐饮管理有限公司</span>——<span style=\"margin: 0px; padding: 0px;\">备货通知</span><span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">尊敬的客户</span><span style=\"margin: 0px; padding: 0px;\">:</span><span style=\"margin: 0px; padding: 0px;\">您好</span><span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">感谢您长期以来对我们公司的支持与信任</span><span style=\"margin: 0px; padding: 0px;\">!</span><span style=\"margin: 0px; padding: 0px;\">国庆节来临之际</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">因国庆</span><span style=\"margin: 0px; padding: 0px;\">70</span><span style=\"margin: 0px; padding: 0px;\">周年大阅兵隆重召开</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">北方物流</span><span style=\"margin: 0px; padding: 0px;\">9</span><span style=\"margin: 0px; padding: 0px;\">月</span><span style=\"margin: 0px; padding: 0px;\">22</span><span style=\"margin: 0px; padding: 0px;\">停止发货</span><span style=\"margin: 0px; padding: 0px;\">,</span><span style=\"margin: 0px; padding: 0px;\">南方物流</span><span style=\"margin: 0px; padding: 0px;\">9</span><span style=\"margin: 0px; padding: 0px;\">月</span><span style=\"margin: 0px; padding: 0px;\">25</span><span style=\"margin: 0px; padding: 0px;\">日停止发货</span><span style=\"margin: 0px; padding: 0px;\">...</span><span style=\"margin: 0px; padding: 0px;\"></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190927/20190927173943_2968.jpg\" alt=\"\" width=\"780\" height=\"1104\" title=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\">9<span style=\"margin: 0px; padding: 0px;\">月来了，</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"></span>“<span style=\"margin: 0px; padding: 0px;\">十一</span><span style=\"margin: 0px; padding: 0px;\">”</span><span style=\"margin: 0px; padding: 0px;\">长假还会远吗</span><span style=\"margin: 0px; padding: 0px;\">?</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\">相信很多朋友都想趁着机会</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\">带着爱车去旅行吧</span>?</p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\">在您踏上旅途之前，</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\">小编要提前给各位新老司机们</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190927/20190927174021_8750.png\" alt=\"\"/><br/></span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\">提个醒了，</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\">从今年中秋节以后，</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><span style=\"margin: 0px; padding: 0px;\">开车上路要</span>“<span style=\"margin: 0px; padding: 0px;\">限速</span><span style=\"margin: 0px; padding: 0px;\">”</span><span style=\"margin: 0px; padding: 0px;\">了</span><span style=\"margin: 0px; padding: 0px;\">!</span></p><p class=\"p\" style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center; text-indent: 18pt;\">(<span style=\"margin: 0px; padding: 0px;\">部分地区限速，具体事宜看实际通知</span><span style=\"margin: 0px; padding: 0px;\">)</span></p><p><br/></p>', '2019/9/19', '0', '0', '1588040119', '1588040119', '1');
INSERT INTO `dp_home_news` VALUES ('13', '30', '153', '周年庆回顾 | 风雨共进十三载，同心逐梦赢未来!', '风雨共进十三载,同心逐梦赢未来。成都餐协迎来了十三周年的生日，为了庆祝这一特殊的日子，2019年7月27日，以“聚集餐饮，实务运营”为主题的十三周年庆典暨新餐饮品牌峰会在成都餐协总部举行。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 成都餐协餐饮管理有限公司(以下简称成都餐协)迎来了十三周年的生日，为了庆祝这一特殊的日子，2019年7月27日，以“聚集餐饮，实务运营”为主题的十三周年庆典暨新餐饮品牌峰会在成都餐协总部举行。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190731/20190731141934_2865.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 大屏幕上播放了成都餐协十三周年暨新餐饮品牌峰会的宣传片，十三年的拼搏与努力、十三年的成绩与收获都浓缩于此。一张张熟悉或陌生的面孔，一次次新的突破与成长，此情此景，让每个人都心潮澎湃。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190731/20190731142005_1458.png\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 现在由成都餐协市场部优秀代表余敏老师现场讲授以《餐饮新时代》为话题的经验分享会。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190731/20190731142023_6302.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 通过与现场来宾的互动，了解他们对于做餐饮前遇到的一些问题，例如项目、选址、定位等。而这些困惑，项目加盟能一站式解决。成都餐协有成熟品牌的市场影响力、开店前后的经营与支持，风险可控，最重要的是能够帮助加盟者赚到可观收入。餐饮新时代一直是个热门话题，餐饮行业只有与用户产生了链接，才能在未来的竞争中赢得市场，运用科技和媒体的手段，提供更具价值的产品和服务，利用数字化、网络化、智能化的深入发展，探索新的多元模式。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190731/20190731142051_2708.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 深耕十三载，品质赢未来。走过风雨十三年，回首往昔，热泪盈眶。根据这些年加盟商开店大数据来看，以下这几个项目不但没在更久换新快速的餐饮市场中淘汰，还越来越热门，深受消费者与创业者的关注并咨询。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><br/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 一纸馋纸包鱼：用一张神奇的纸锁住鱼的鲜香，鱼肉被汤汁包裹，送入口中，一抿即化。潮流与精致的融合，鲜味与品位的结合，让一纸馋纸包鱼深受消费者的喜爱。独家秘方的辣椒把纸包鱼衬得格外诱人，顾客夹起了一块鱼肉，闭眼品尝，接连点头，喜笑颜开。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190731/20190731142212_3958.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 爱尚 lakaola 烤肉：爱尚lakaola烤肉致力打造时尚、轻奢、小资的餐饮新理念。肉经炭火洗练，本就香气四溢，又因秘制酱料的增色，变得更加入味，满足吃货对美食的所有幻想。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190731/20190731142403_0990.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 烤肉滋滋发出声响，一滴热油顺着饱满的肉的纹路慢慢滑下，食客们早已安耐不住吃货的心，顾不得烫，一咬就是一大口，哇!爽!满口火热沸腾，满满的幸福感涌上心尖!爱尚lakaola烤肉不仅仅是一个烤肉品牌，也是一种高雅的格调，更是乐于享受生活的态度!</p><p style=\"text-align:center\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190731/20190731142517_8021.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 渔舍木桶鱼：翻滚着热气的渔舍木桶鱼，采用木煮食烹的奇式烹饪法，将鱼肉铺在高温的木鱼石上，加入熬制高汤，浓醇的鱼汤完美地保留了鱼肉本身的鲜味，激情四射，滋滋作响!新、奇、香，完美切合现代年轻人对美食的要求和味道，鲜香味美。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190731/20190731142635_6927.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 哆唻客：哆唻客采用中西式快餐相结合的产品结构，既注重了中式快餐的营养，又保留了西式快餐的快捷。不仅有国内首创粗粮系列杂粮汉堡，更有营养荤素搭配的套饭系列，是让加盟者们迅速吸引年轻消费群体的首选品牌之一。</p><p style=\"text-align:center\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190731/20190731142810_6615.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; &nbsp;小花猪：小花猪把把烧的试吃间门庭若市，聚集了一批年轻的宾客。小花猪把把烧着力打造潮流夜宵品牌，其卡通猪形象深入人心。能疯狂地撸串，大口地喝酒，畅聊人生，尽在小花猪。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 公司旗下品牌具有强大的品牌影响力，公司总部提供国际化店铺运营指导和成本集约化管理，有专业的营销策划、推广团队，有现代化的物流体系、强有力的后期保障、完善的区域保护政策、高速的产品研发实力。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 400联系热线：400-0809-517</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 相关资讯：http://www.1zhichan.com/xwc2500.html</p><p><br/></p>', '2019/7/27', '0', '0', '1588040251', '1588040251', '1');
INSERT INTO `dp_home_news` VALUES ('14', '30', '154', '创业加盟|成都餐协十三周年庆...只需万元就可开店创业!', '十三载风雨同舟,携手共赢未来!感谢加盟商对成都餐协一直以来的信任和支持,部特别在本月(7月27号)推出周年庆系列主题活动。其中一项主题活动就是“菜系繁多,意选择;元加盟,创新高”。', '<h4 style=\"margin: 0px; padding: 0px; font-weight: normal; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\">回首十三载，我们收获与成长，<br/>齐心协力赢佳绩!<br/>展望精彩未来，我们再谱新篇章，<br/>携手前进创辉煌!</h4><h4 style=\"margin: 0px; padding: 0px; font-weight: normal; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723164601_0018.jpg\" alt=\"\"/><br/>十三年来，我们砥砺前行<br/>时代不断发展<br/>消费者需求发生巨大改变<br/>互联网餐饮时代已经到来<br/>我们面对机遇，冲向未来<strong style=\"margin: 0px; padding: 0px;\"></strong><br/>2019，蜕变成长，服务共赢</h4><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><br/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">一、品牌实景</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723164734_6581.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 我们作为西南特色餐饮企业的领军者，以差异化的市场定位、标准化的操作流程、科学的管理模式、超前的营销理念，使旗下各个餐饮品牌项目，在激烈的市场竞争环境中，能抢占先机，拔得头筹。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">同时，我们的品牌自上市以来一直深受食客们的喜爱，各大品牌已在全国各个地区分布多家门店，已帮助众多创业者实现餐饮创业之梦。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723165008_1112.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\">&nbsp; 品牌店实景</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">二、专业团队</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723165119_1112.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 本次新餐饮峰会，我们将开设讲师分享会，特邀成都餐协新媒部总监蒋福齐老师现场讲授《店铺如何有效提升销售和复购》。蒋老师有知名餐饮企业11年的管理经验，曾成功运营孵化出3个大型连锁餐饮品牌，有着及其丰富的行业经验，帮助餐饮人拓展新餐饮时代营销的渠道。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723165307_5643.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">此外，我们还有招商总监带领团队现场亲自为您讲解项目情况，洽谈合作事宜。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723165333_2675.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723165350_4706.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723165400_9393.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723165413_5331.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723165427_4862.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\">7月27日，</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\">我们在成都餐协等你!</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\">与我们共话友情，</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\">展望未来发展与合作大计!</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\">携手成都餐协，共创餐饮致富美好未来。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\">您可以拨打电话13258282810咨询详细信息。期待与您的合作!</p><p><br/></p>', '2019/7/23', '0', '0', '1588040404', '1588040404', '1');
INSERT INTO `dp_home_news` VALUES ('15', '30', '155', '惊喜彩蛋：成都餐协13周年庆，定于本月27号正式与大家见面', '十三载风雨同舟，同携手共赢未来!“只需万元就可开店创业”的特大福利，十余个特色餐饮品牌任意选择，多项开店扶持，一对一技术操作步骤实习，3至7天就可轻松上手，独自开店不在话题。', '<p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 十三载风雨同舟，同携手共赢未来!为感谢加盟商对成都餐协一直以来的信任和支持，总部特别在本月(7月27号)推出周年庆系列主题活动。其中一项主题活动就是“菜系繁多，任意选择;万元加盟，在创新高”。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163448_6581.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;<strong style=\"margin: 0px; padding: 0px;\">&nbsp;十三年成长，铸造品牌，十三年努力，塑造权威。成都餐协餐饮管理有限公司在这十三年的时间里有着怎样的突破发展?</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163511_2050.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><strong style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 1、2006年，成都餐协餐饮管理有限公司携带“一纸馋”新式餐饮品牌正式成立餐饮创业总部，从而也简称为“成都餐协”</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163526_0175.png\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><strong style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 2、2009年，一纸馋荣获“特色餐饮名店”称号</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163548_5175.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><strong style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 3、2010年，一纸馋纸包鱼被授予“金字招牌”称号</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163616_4550.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><strong style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 4、2012年，成都餐协荣获“全国绿色餐饮示范企业”称号</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163639_1112.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><strong style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 5、2015年，成都餐协荣获“守合同，重信用”称号</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163745_6268.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><strong style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 6、2017年，“哆唻客”西式快餐项目正式成立</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163756_8612.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><strong style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 7、2018年，成都餐协被授予“加盟中国影响力百强企业”称号，“渔舍木桶鱼”“小花猪把把烧”品牌勇攀西南最佳餐饮投资项目一纸馋纸包鱼店铺数量超过800多家。</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163648_9081.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><strong style=\"margin: 0px; padding: 0px;\">&nbsp; &nbsp; &nbsp; 8、2019年，成都餐协被授予“立信企业”称号，“桃花燚”“飞鱼座”“小签欢”新品牌项目成立。</strong></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723163813_5643.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 人常说努力才会有收获，不努力什么你都没有。成都餐协也在13年的锤炼下，在许多菜系上都有很大的突破，例如：纸上烤肉系列、纸上火锅系列、纸包鱼系列、烧烤系列、干锅系列、龙虾小吃系列、啵啵鱼系列、木桶鱼系列、汉堡系列、蒸菜系列、炸鸡系列、披萨系列、牛排杯系列、牛排系列、凉卤菜系列、营养汤品系列、串串系列、冰淇淋系列、甜品系列及其他特色菜品系列等有吃有喝，菜系不同的美食。不但可满足消费者挑剔的胃，同时还可给加盟商带来不少的创业商机。</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal; text-align: center;\"><img src=\"http://www.1zhichan.com/user/kindeditor/attached/image/20190723/20190723164218_6112.jpg\" alt=\"\"/></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp; 携手成都餐协，共创餐饮致富美好未来。您可以拨打电话<span style=\"margin: 0px; padding: 0px; background-color: rgb(229, 51, 51);\">13258282810</span>咨询详细信息。期待与您的合作!</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;&nbsp;</p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\">&nbsp; &nbsp; &nbsp;&nbsp;<span style=\"margin: 0px; padding: 0px; color: rgb(229, 51, 51);\">回复：地区+姓名+手机号 例如(杭州+陈先生+155******88)</span></p><p style=\"margin-top: 0px; margin-bottom: 0px; padding: 0px; outline: none; font-size: 14px; font-family: 微软雅黑; white-space: normal;\"><span style=\"margin: 0px; padding: 0px; color: rgb(229, 51, 51);\">&nbsp; &nbsp; &nbsp; 我们会在24h之内和您取得联系，留言前5名可获3万创业大礼包，截止日期2019/7/27</span></p><p><span style=\"margin: 0px; padding: 0px; color: rgb(229, 51, 51);\"><br/></span></p><p><br/></p>', '2019/7/23', '0', '0', '1588040541', '1588040541', '1');

-- -----------------------------
-- Table structure for `dp_home_project`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_project`;
CREATE TABLE `dp_home_project` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `pid` int(11) NOT NULL COMMENT '所属分页id',
  `img` int(11) NOT NULL COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='项目中心';

-- -----------------------------
-- Records of `dp_home_project`
-- -----------------------------
INSERT INTO `dp_home_project` VALUES ('1', '22', '169', '1', '1', '1', '1588063768', '1588063768', '1');
INSERT INTO `dp_home_project` VALUES ('2', '22', '170', '2', '2', '2', '1588063781', '1588063781', '1');
INSERT INTO `dp_home_project` VALUES ('3', '22', '171', '3', '3', '3', '1588063794', '1588063794', '1');
INSERT INTO `dp_home_project` VALUES ('4', '22', '172', '4', '4', '4', '1588063807', '1588063807', '1');
INSERT INTO `dp_home_project` VALUES ('5', '22', '173', '5', '5', '5', '1588063823', '1588063823', '1');
INSERT INTO `dp_home_project` VALUES ('6', '22', '174', '6', '6', '6', '1588063840', '1588063840', '1');
INSERT INTO `dp_home_project` VALUES ('7', '22', '175', '7', '7', '7', '1588063854', '1588063854', '1');
INSERT INTO `dp_home_project` VALUES ('8', '22', '176', '8', '8', '8', '1588063868', '1588063868', '1');
INSERT INTO `dp_home_project` VALUES ('9', '22', '177', '9', '9', '9', '1588063881', '1588063881', '1');
INSERT INTO `dp_home_project` VALUES ('10', '22', '178', '10', '10', '10', '1588063899', '1588063899', '1');
INSERT INTO `dp_home_project` VALUES ('11', '23', '179', '1', '1', '1', '1588063954', '1588063954', '1');
INSERT INTO `dp_home_project` VALUES ('12', '23', '180', '2', '2', '2', '1588063968', '1588063968', '1');
INSERT INTO `dp_home_project` VALUES ('13', '23', '181', '3', '3', '3', '1588063981', '1588224090', '1');
INSERT INTO `dp_home_project` VALUES ('14', '23', '182', '4', '4', '4', '1588063995', '1588063995', '1');
INSERT INTO `dp_home_project` VALUES ('15', '23', '183', '5', '5', '5', '1588064009', '1588064009', '1');
INSERT INTO `dp_home_project` VALUES ('16', '23', '184', '6', '6', '6', '1588064024', '1588064024', '1');
INSERT INTO `dp_home_project` VALUES ('17', '23', '185', '7', '7', '7', '1588064038', '1588064038', '1');
INSERT INTO `dp_home_project` VALUES ('18', '23', '186', '8', '8', '8', '1588064052', '1588064052', '1');
INSERT INTO `dp_home_project` VALUES ('19', '23', '187', '9', '9', '9', '1588064065', '1588064065', '1');
INSERT INTO `dp_home_project` VALUES ('20', '23', '188', '10', '10', '10', '1588064080', '1588064080', '1');

-- -----------------------------
-- Table structure for `dp_home_roll`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_roll`;
CREATE TABLE `dp_home_roll` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `url` varchar(255) NOT NULL COMMENT '跳转链接',
  `img` varchar(11) NOT NULL DEFAULT '' COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='首页/滚动图';

-- -----------------------------
-- Records of `dp_home_roll`
-- -----------------------------
INSERT INTO `dp_home_roll` VALUES ('1', '1', '32', '成都店', '成都店', '100', '1587457777', '1587695735', '1');
INSERT INTO `dp_home_roll` VALUES ('2', '1', '33', '福建泉州店', '福建泉州店', '100', '1587695772', '1587695772', '1');
INSERT INTO `dp_home_roll` VALUES ('3', '1', '34', '福建福州店', '福建福州店', '100', '1587695802', '1587695802', '1');
INSERT INTO `dp_home_roll` VALUES ('4', '1', '35', '梅州店', '梅州店', '100', '1587695832', '1587695832', '1');
INSERT INTO `dp_home_roll` VALUES ('5', '1', '36', '浦东店', '浦东店', '100', '1587695861', '1587695861', '1');
INSERT INTO `dp_home_roll` VALUES ('6', '1', '37', '七宝店', '七宝店', '100', '1587695892', '1587695892', '1');
INSERT INTO `dp_home_roll` VALUES ('7', '1', '38', '玉环店', '玉环店', '100', '1587695919', '1587695919', '1');
INSERT INTO `dp_home_roll` VALUES ('8', '1', '39', '浙江宁波店', '浙江宁波店', '100', '1587695952', '1587695952', '1');
INSERT INTO `dp_home_roll` VALUES ('9', '1', '40', '中国区壹号店', '中国区壹号店', '100', '1587695976', '1587695976', '1');
INSERT INTO `dp_home_roll` VALUES ('10', '1', '41', '珠海店', '珠海店', '100', '1587696003', '1587696003', '1');

-- -----------------------------
-- Table structure for `dp_home_store`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_store`;
CREATE TABLE `dp_home_store` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `img` varchar(255) NOT NULL DEFAULT '' COMMENT '封面图',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文字',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '跳转链接',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='首页/店铺实拍';

-- -----------------------------
-- Records of `dp_home_store`
-- -----------------------------
INSERT INTO `dp_home_store` VALUES ('1', '47', '大咖VI设计', '大咖VI设计', '超强VI设计大师倾情设计', '/index/store/index', '0', '1587714224', '1587714224', '1');
INSERT INTO `dp_home_store` VALUES ('2', '4', '3D场景', '3D场景', '3D环境就餐，在一纸馋不仅吃得开心也玩得开心。', '/index/store/index', '0', '1587714290', '1587714290', '1');
INSERT INTO `dp_home_store` VALUES ('3', '48', '真实拍摄', '真实拍摄', '实体店真实拍摄 超高人气看得见！', '/index/store/index', '0', '1587714335', '1587714335', '1');
INSERT INTO `dp_home_store` VALUES ('4', '49', '加盟商感悟', '加盟商感悟', '在一纸馋获取成功其实并不难。', '/index/store/index', '0', '1587714377', '1587714377', '1');

-- -----------------------------
-- Table structure for `dp_home_stores`
-- -----------------------------
DROP TABLE IF EXISTS `dp_home_stores`;
CREATE TABLE `dp_home_stores` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `url` varchar(255) NOT NULL COMMENT '跳转链接',
  `img` varchar(11) NOT NULL DEFAULT '' COMMENT '图片',
  `alt` varchar(255) NOT NULL DEFAULT '' COMMENT '替代文本',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='店铺形象';

-- -----------------------------
-- Records of `dp_home_stores`
-- -----------------------------
INSERT INTO `dp_home_stores` VALUES ('1', '', '96', '店铺形象', '店铺形象', '100', '1587967819', '1587967819', '1');
INSERT INTO `dp_home_stores` VALUES ('2', '', '97', '店铺形象', '店铺形象', '100', '1587967843', '1587967843', '1');
INSERT INTO `dp_home_stores` VALUES ('3', '', '98', '店铺形象', '店铺形象', '100', '1587968024', '1587968024', '1');
INSERT INTO `dp_home_stores` VALUES ('4', '', '99', '店铺形象', '店铺形象', '100', '1587968036', '1587968036', '1');
INSERT INTO `dp_home_stores` VALUES ('5', '', '100', '店铺形象', '店铺形象', '100', '1587968048', '1587968048', '1');
INSERT INTO `dp_home_stores` VALUES ('6', '', '101', '店铺形象', '店铺形象', '100', '1587968061', '1587968061', '1');
INSERT INTO `dp_home_stores` VALUES ('7', '', '102', '店铺形象', '店铺形象', '100', '1587968221', '1587968221', '1');
INSERT INTO `dp_home_stores` VALUES ('8', '', '103', '店铺形象', '店铺形象', '100', '1587968235', '1587968235', '1');
INSERT INTO `dp_home_stores` VALUES ('9', '', '104', '店铺形象', '店铺形象', '100', '1587968250', '1587968250', '1');
INSERT INTO `dp_home_stores` VALUES ('10', '', '105', '店铺形象', '店铺形象', '100', '1587968264', '1587968264', '1');
INSERT INTO `dp_home_stores` VALUES ('11', '', '106', '店铺形象', '店铺形象', '100', '1587968278', '1587968278', '1');
INSERT INTO `dp_home_stores` VALUES ('12', '', '107', '店铺形象', '店铺形象', '100', '1587968292', '1587968292', '1');
INSERT INTO `dp_home_stores` VALUES ('13', '', '108', '店铺形象', '店铺形象', '100', '1587968304', '1587968304', '1');
INSERT INTO `dp_home_stores` VALUES ('14', '', '109', '店铺形象', '店铺形象', '100', '1587968316', '1587968316', '1');
INSERT INTO `dp_home_stores` VALUES ('15', '', '110', '店铺形象', '店铺形象', '100', '1587968328', '1587968328', '1');

-- -----------------------------
-- Table structure for `dp_message`
-- -----------------------------
DROP TABLE IF EXISTS `dp_message`;
CREATE TABLE `dp_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL DEFAULT '' COMMENT '姓名',
  `phone` varchar(255) NOT NULL DEFAULT '' COMMENT '电话',
  `content` text NOT NULL COMMENT '消息内容',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `ip` varchar(255) NOT NULL COMMENT 'IP地址',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `read_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='消息表';

-- -----------------------------
-- Records of `dp_message`
-- -----------------------------
INSERT INTO `dp_message` VALUES ('1', '黄海平', '13219294337', '', '1', '127.0.0.1', '1588521200', '1588557759');
INSERT INTO `dp_message` VALUES ('2', '黄海平', '13219294337', '', '0', '127.0.0.1', '1588521399', '0');
